# 🤝 贡献指南

感谢您对本项目的兴趣！我们欢迎所有形式的贡献。

## 贡献方式

- 报告 Bug
- 建议新功能
- 改进文档
- 提交代码

## 贡献流程

1.  **沟通 (可选但推荐)**
    - 在开始工作前，请先创建一个 [Issue](https://github.com/your-org/malicious-traffic-control/issues) 来讨论您的想法。

2.  **环境准备**
    - Fork 项目并克隆到本地。
    - 确保您已安装 Docker 和 Docker Compose。
    - 启动开发环境：`docker-compose -f docker-compose.dev.yml up --build`

3.  **编码**
    - 从 `main` 分支创建您的开发分支，例如 `feature/your-idea` 或 `bugfix/the-problem`。
    - 编写您的代码，请尽量遵循项目中现有的代码风格。
    - 在提交前，请运行相关的格式化和检查工具，例如 `cargo fmt`, `mvn checkstyle:check`, `npm run lint`。
    - 为您的改动添加必要的测试。

4.  **提交**
    - 使用 [Conventional Commits](https://www.conventionalcommits.org/) 规范来编写提交信息 (例如 `feat: ...`, `fix: ...`)。
    - 提交您的代码并推送到您的 Fork 仓库。

5.  **创建 Pull Request (PR)**
    - 创建一个 Pull Request 到主项目的 `main` 分支。
    - 在 PR 描述中清晰地说明您的改动，并关联相关的 Issue。

## 行为准则

请遵守我们的 [行为准则 (CODE_OF_CONDUCT.md)](CODE_OF_CONDUCT.md)，共同维护一个友好的社区。

---

再次感谢您的贡献！