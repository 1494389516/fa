#!/bin/bash

# 🛠️ 公共函数库
# 被 deploy.sh 和 cloud-deploy.sh 调用

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warn() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

log_step() {
    echo -e "\n${PURPLE}🚀 $1${NC}"
    echo "=================================="
}

# 检测环境类型
detect_environment() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [[ -f /proc/version ]] && grep -q "microsoft" /proc/version; then
            grep -q "WSL2" /proc/version && echo "WSL2" || echo "WSL1"
        elif curl -s --connect-timeout 3 http://100.100.100.200/latest/meta-data/instance-id >/dev/null 2>&1 || \
             curl -s --connect-timeout 3 http://metadata.tencentcloudapi.com/latest/meta-data/instance-id >/dev/null 2>&1 || \
             curl -s --connect-timeout 3 http://169.254.169.254/latest/meta-data/instance-id >/dev/null 2>&1; then
            echo "CLOUD"
        else
            echo "LINUX"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "MACOS"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
        echo "WINDOWS"
    else
        echo "UNKNOWN"
    fi
}

# 显示环境信息
show_environment_info() {
    local env=$1
    case $env in
        "CLOUD") echo "云服务器环境" ;;
        "LINUX") echo "Linux环境" ;;
        "WSL2") echo "WSL2环境" ;;
        "WSL1") echo "WSL1环境" ;;
        "MACOS") echo "macOS环境" ;;
        "WINDOWS") echo "Windows环境" ;;
        *) echo "未知环境" ;;
    esac
}