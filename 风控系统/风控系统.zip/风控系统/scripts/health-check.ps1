# 健康检查脚本 (PowerShell 版本)

param(
    [switch]$Verbose
)

Write-Host "🔍 检查服务健康状态..." -ForegroundColor Cyan

# 检查函数
function Test-ServiceHealth {
    param(
        [string]$ServiceName,
        [string]$Url,
        [int]$ExpectedStatus = 200
    )
    
    Write-Host "检查 $ServiceName... " -NoNewline
    
    try {
        $response = Invoke-WebRequest -Uri $Url -Method GET -TimeoutSec 10 -UseBasicParsing
        if ($response.StatusCode -eq $ExpectedStatus) {
            Write-Host "✓ 健康" -ForegroundColor Green
            return $true
        } else {
            Write-Host "✗ 不健康 (状态码: $($response.StatusCode))" -ForegroundColor Red
            return $false
        }
    } catch {
        Write-Host "✗ 不健康 (错误: $($_.Exception.Message))" -ForegroundColor Red
        return $false
    }
}

# 等待服务启动
function Wait-ForService {
    param(
        [string]$ServiceName,
        [string]$Url,
        [int]$MaxAttempts = 30
    )
    
    Write-Host "等待 $ServiceName 启动..."
    
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $response = Invoke-WebRequest -Uri $Url -Method GET -TimeoutSec 5 -UseBasicParsing
            Write-Host "$ServiceName 已启动" -ForegroundColor Green
            return $true
        } catch {
            Write-Host "." -NoNewline
            Start-Sleep -Seconds 2
        }
    }
    
    Write-Host "$ServiceName 启动超时" -ForegroundColor Red
    return $false
}

# 检查 Docker Compose 服务状态
Write-Host "`n📋 检查 Docker Compose 服务状态..."
try {
    docker-compose ps
} catch {
    Write-Host "无法获取 Docker Compose 状态: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🌐 检查服务端点..."

# 应用服务健康检查
$services = @(
    @{Name="边缘网关"; Url="http://localhost:8080/health"},
    @{Name="策略引擎"; Url="http://localhost:8081/api/v1/health"},
    @{Name="反爬服务"; Url="http://localhost:8082/api/v1/health"},
    @{Name="流处理服务"; Url="http://localhost:8083/health"},
    @{Name="ML推理服务"; Url="http://localhost:8084/health"},
    @{Name="ML训练服务"; Url="http://localhost:8085/health"},
    @{Name="蜜罐服务"; Url="http://localhost:8086/health"},
    @{Name="Prometheus"; Url="http://localhost:9090/-/healthy"},
    @{Name="Grafana"; Url="http://localhost:3000/api/health"},
    @{Name="Kafka UI"; Url="http://localhost:8090/actuator/health"}
)

$healthyCount = 0
foreach ($service in $services) {
    if (Test-ServiceHealth -ServiceName $service.Name -Url $service.Url) {
        $healthyCount++
    }
}

Write-Host "`n📊 系统资源使用情况..."

# 检查 Docker 资源使用
Write-Host "Docker 容器资源使用:"
try {
    docker stats --no-stream --format "table {{.Container}}`t{{.CPUPerc}}`t{{.MemUsage}}`t{{.NetIO}}"
} catch {
    Write-Host "无法获取 Docker 统计信息: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n💾 磁盘使用情况:"
Get-WmiObject -Class Win32_LogicalDisk | Select-Object DeviceID, @{Name="Size(GB)";Expression={[math]::Round($_.Size/1GB,2)}}, @{Name="FreeSpace(GB)";Expression={[math]::Round($_.FreeSpace/1GB,2)}}, @{Name="PercentFree";Expression={[math]::Round(($_.FreeSpace/$_.Size)*100,2)}} | Format-Table

Write-Host "`n🔧 服务连接测试..."

# 测试 API 端点
function Test-ApiEndpoint {
    param(
        [string]$Name,
        [string]$Url,
        [string]$Method = "GET",
        [string]$Body = $null
    )
    
    Write-Host "测试 $Name API... " -NoNewline
    
    try {
        $headers = @{"Content-Type" = "application/json"}
        
        if ($Method -eq "POST" -and $Body) {
            $response = Invoke-WebRequest -Uri $Url -Method POST -Body $Body -Headers $headers -TimeoutSec 10 -UseBasicParsing
        } else {
            $response = Invoke-WebRequest -Uri $Url -Method $Method -TimeoutSec 10 -UseBasicParsing
        }
        
        Write-Host "✓ 正常 ($($response.StatusCode))" -ForegroundColor Green
    } catch {
        $statusCode = if ($_.Exception.Response) { $_.Exception.Response.StatusCode } else { "未知" }
        Write-Host "✗ 异常 ($statusCode)" -ForegroundColor Red
    }
}

# API 端点测试
$apiTests = @(
    @{Name="策略决策"; Url="http://localhost:8081/api/v1/policy/decide"; Method="POST"; Body='{"threat_score": 0.5, "client_info": {"ip": "192.168.1.1"}}'},
    @{Name="Token验证"; Url="http://localhost:8082/api/v1/verify-token"; Method="POST"; Body='{"token": "test", "signature": "test", "timestamp": 1640995200}'},
    @{Name="ML推理"; Url="http://localhost:8084/api/v1/inference"; Method="POST"; Body='{"features": [0.1, 0.2, 0.3], "model_version": "v1.0"}'}
)

foreach ($test in $apiTests) {
    Test-ApiEndpoint -Name $test.Name -Url $test.Url -Method $test.Method -Body $test.Body
}

Write-Host "`n📈 性能指标..."

# 响应时间测试
Write-Host "响应时间测试:"
$performanceTests = @(
    @{Name="边缘网关"; Url="http://localhost:8080/health"},
    @{Name="策略引擎"; Url="http://localhost:8081/api/v1/health"},
    @{Name="反爬服务"; Url="http://localhost:8082/api/v1/health"}
)

foreach ($test in $performanceTests) {
    try {
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $response = Invoke-WebRequest -Uri $test.Url -Method GET -TimeoutSec 10 -UseBasicParsing
        $stopwatch.Stop()
        $responseTime = $stopwatch.ElapsedMilliseconds
        Write-Host "  $($test.Name): ${responseTime}ms"
    } catch {
        Write-Host "  $($test.Name): 超时或错误" -ForegroundColor Red
    }
}

Write-Host "`n🎯 总结..."

# 检查关键服务是否都在运行
$criticalServices = @("edge-gateway", "policy-engine", "anti-crawler-backend", "ml-inference")
$allHealthy = $true

foreach ($service in $criticalServices) {
    try {
        $containerStatus = docker-compose ps $service
        if ($containerStatus -notmatch "Up") {
            Write-Host "关键服务 $service 未运行" -ForegroundColor Red
            $allHealthy = $false
        }
    } catch {
        Write-Host "无法检查服务 $service 状态" -ForegroundColor Red
        $allHealthy = $false
    }
}

Write-Host "`n健康检查结果: $healthyCount/$($services.Count) 服务正常"

if ($allHealthy -and $healthyCount -ge ($services.Count * 0.8)) {
    Write-Host "✅ 系统整体运行正常" -ForegroundColor Green
    exit 0
} else {
    Write-Host "❌ 系统存在问题，请检查日志" -ForegroundColor Red
    exit 1
}