#!/bin/bash

# 📊 实时性能监控脚本
# 监控恶意流量控制系统的实时性能指标

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 配置
REFRESH_INTERVAL=2
LOG_FILE="/tmp/performance-monitor.log"

# 检测环境
detect_environment() {
    if [[ -f /proc/version ]] && grep -q "microsoft" /proc/version; then
        if grep -q "WSL2" /proc/version; then
            echo "WSL2"
        else
            echo "WSL1"
        fi
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        echo "Linux"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macOS"
    else
        echo "Unknown"
    fi
}

# 获取系统信息
get_system_info() {
    local env=$(detect_environment)
    local cpu_cores=$(nproc 2>/dev/null || echo "N/A")
    local memory_gb=$(free -g 2>/dev/null | awk '/^Mem:/{print $2}' || echo "N/A")
    local load_avg=$(uptime | awk -F'load average:' '{print $2}' | sed 's/^[ \t]*//')
    
    echo -e "${BLUE}🖥️  系统环境: ${CYAN}$env${NC}"
    echo -e "${BLUE}💻 CPU核心: ${CYAN}$cpu_cores${NC}"
    echo -e "${BLUE}🧠 内存容量: ${CYAN}${memory_gb}GB${NC}"
    echo -e "${BLUE}📊 系统负载: ${CYAN}$load_avg${NC}"
}

# 获取Docker容器状态
get_container_status() {
    echo -e "\n${PURPLE}🐳 容器状态${NC}"
    echo "=================================="
    
    if ! command -v docker >/dev/null 2>&1; then
        echo -e "${RED}❌ Docker未安装${NC}"
        return
    fi
    
    # 检查容器状态
    local containers=$(docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null)
    
    if [[ -z "$containers" ]]; then
        echo -e "${RED}❌ 没有运行的容器${NC}"
        return
    fi
    
    echo "$containers" | while IFS=$'\t' read -r name status ports; do
        if [[ "$name" == "NAMES" ]]; then
            continue
        fi
        
        if [[ "$status" == *"Up"* ]]; then
            echo -e "${GREEN}✅ $name${NC} - $status"
        else
            echo -e "${RED}❌ $name${NC} - $status"
        fi
    done
}

# 获取服务响应时间
get_response_times() {
    echo -e "\n${PURPLE}⚡ 服务响应时间${NC}"
    echo "=================================="
    
    local services=(
        "edge-gateway:80:/health"
        "admin-panel:3000:/"
        "ml-inference:8084:/health"
        "stream-processor:8083:/health"
        "prometheus:9090:/"
    )
    
    for service_info in "${services[@]}"; do
        IFS=':' read -r name port path <<< "$service_info"
        
        local url="http://localhost:$port$path"
        local response_time=$(curl -o /dev/null -s -w '%{time_total}' "$url" 2>/dev/null || echo "timeout")
        
        if [[ "$response_time" == "timeout" ]]; then
            echo -e "${RED}❌ $name${NC} - 服务不可用"
        else
            local ms=$(echo "$response_time * 1000" | bc -l 2>/dev/null || echo "0")
            local ms_int=${ms%.*}
            
            if (( ms_int < 10 )); then
                echo -e "${GREEN}✅ $name${NC} - ${ms_int}ms (优秀)"
            elif (( ms_int < 50 )); then
                echo -e "${YELLOW}⚠️  $name${NC} - ${ms_int}ms (良好)"
            else
                echo -e "${RED}❌ $name${NC} - ${ms_int}ms (需优化)"
            fi
        fi
    done
}

# 获取系统资源使用情况
get_resource_usage() {
    echo -e "\n${PURPLE}📊 系统资源使用${NC}"
    echo "=================================="
    
    # CPU使用率
    if command -v top >/dev/null 2>&1; then
        local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//' 2>/dev/null || echo "N/A")
        echo -e "${BLUE}💻 CPU使用率:${NC} $cpu_usage"
    fi
    
    # 内存使用情况
    if command -v free >/dev/null 2>&1; then
        local memory_info=$(free -h | grep "Mem:")
        local used=$(echo $memory_info | awk '{print $3}')
        local total=$(echo $memory_info | awk '{print $2}')
        local percent=$(echo $memory_info | awk '{printf "%.1f", ($3/$2)*100}')
        
        echo -e "${BLUE}🧠 内存使用:${NC} $used/$total (${percent}%)"
    fi
    
    # 磁盘使用情况
    if command -v df >/dev/null 2>&1; then
        local disk_usage=$(df -h . | tail -1 | awk '{print $5}')
        echo -e "${BLUE}💾 磁盘使用:${NC} $disk_usage"
    fi
    
    # 网络连接数
    if command -v netstat >/dev/null 2>&1; then
        local connections=$(netstat -an 2>/dev/null | grep ESTABLISHED | wc -l)
        echo -e "${BLUE}🌐 网络连接:${NC} $connections"
    fi
}

# 获取Docker容器资源使用
get_container_resources() {
    echo -e "\n${PURPLE}🐳 容器资源使用${NC}"
    echo "=================================="
    
    if ! command -v docker >/dev/null 2>&1; then
        echo -e "${RED}❌ Docker未安装${NC}"
        return
    fi
    
    # 获取容器统计信息
    local stats=$(docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}" 2>/dev/null)
    
    if [[ -z "$stats" ]]; then
        echo -e "${RED}❌ 无法获取容器统计信息${NC}"
        return
    fi
    
    echo "$stats" | while IFS=$'\t' read -r name cpu mem net; do
        if [[ "$name" == "NAME" ]]; then
            continue
        fi
        
        # 解析CPU使用率
        local cpu_num=$(echo "$cpu" | sed 's/%//' | cut -d'.' -f1)
        
        if [[ "$cpu_num" =~ ^[0-9]+$ ]]; then
            if (( cpu_num < 50 )); then
                echo -e "${GREEN}✅ $name${NC} - CPU: $cpu, 内存: $mem"
            elif (( cpu_num < 80 )); then
                echo -e "${YELLOW}⚠️  $name${NC} - CPU: $cpu, 内存: $mem"
            else
                echo -e "${RED}❌ $name${NC} - CPU: $cpu, 内存: $mem (高负载)"
            fi
        else
            echo -e "${BLUE}ℹ️  $name${NC} - CPU: $cpu, 内存: $mem"
        fi
    done
}

# 获取性能指标
get_performance_metrics() {
    echo -e "\n${PURPLE}📈 性能指标${NC}"
    echo "=================================="
    
    local env=$(detect_environment)
    
    # 根据环境显示不同的性能基准
    case $env in
        "Linux")
            echo -e "${GREEN}🐧 Linux环境 - 最佳性能${NC}"
            echo "  🎯 目标QPS: 150K+"
            echo "  ⚡ 目标延迟: <5ms"
            echo "  📊 目标错误率: <0.01%"
            ;;
        "WSL2")
            echo -e "${YELLOW}🪟 WSL2环境 - 性能受限${NC}"
            echo "  🎯 预估QPS: ~80K (约Linux的70%)"
            echo "  ⚡ 预估延迟: ~12ms"
            echo "  📊 预估错误率: <1%"
            ;;
        "WSL1")
            echo -e "${RED}🪟 WSL1环境 - 性能严重受限${NC}"
            echo "  🎯 预估QPS: ~30K (约Linux的30%)"
            echo "  ⚡ 预估延迟: ~50ms"
            echo "  📊 预估错误率: <5%"
            ;;
        *)
            echo -e "${BLUE}❓ 未知环境${NC}"
            ;;
    esac
    
    # 实时QPS估算（基于响应时间）
    local gateway_response=$(curl -o /dev/null -s -w '%{time_total}' "http://localhost:80/health" 2>/dev/null || echo "0")
    if [[ "$gateway_response" != "0" ]]; then
        local estimated_qps=$(echo "scale=0; 1 / $gateway_response" | bc -l 2>/dev/null || echo "N/A")
        echo -e "${BLUE}📊 估算QPS:${NC} ~${estimated_qps} (单线程)"
    fi
}

# 获取告警信息
get_alerts() {
    echo -e "\n${PURPLE}🚨 系统告警${NC}"
    echo "=================================="
    
    local alerts=()
    
    # 检查高CPU使用率
    if command -v top >/dev/null 2>&1; then
        local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//' | cut -d'.' -f1 2>/dev/null || echo "0")
        if [[ "$cpu_usage" =~ ^[0-9]+$ ]] && (( cpu_usage > 80 )); then
            alerts+=("🔥 CPU使用率过高: ${cpu_usage}%")
        fi
    fi
    
    # 检查高内存使用率
    if command -v free >/dev/null 2>&1; then
        local mem_percent=$(free | grep "Mem:" | awk '{printf "%.0f", ($3/$2)*100}')
        if [[ "$mem_percent" =~ ^[0-9]+$ ]] && (( mem_percent > 85 )); then
            alerts+=("🧠 内存使用率过高: ${mem_percent}%")
        fi
    fi
    
    # 检查磁盘使用率
    if command -v df >/dev/null 2>&1; then
        local disk_percent=$(df . | tail -1 | awk '{print $5}' | sed 's/%//')
        if [[ "$disk_percent" =~ ^[0-9]+$ ]] && (( disk_percent > 90 )); then
            alerts+=("💾 磁盘使用率过高: ${disk_percent}%")
        fi
    fi
    
    # 检查服务可用性
    local services=("80" "3000" "8084")
    for port in "${services[@]}"; do
        if ! curl -f -s "http://localhost:$port" >/dev/null 2>&1; then
            alerts+=("🚫 端口 $port 服务不可用")
        fi
    done
    
    if [[ ${#alerts[@]} -eq 0 ]]; then
        echo -e "${GREEN}✅ 系统运行正常，无告警${NC}"
    else
        for alert in "${alerts[@]}"; do
            echo -e "${RED}⚠️  $alert${NC}"
        done
    fi
}

# 主监控循环
monitor_loop() {
    while true; do
        # 清屏
        clear
        
        # 显示标题
        echo -e "${PURPLE}"
        echo "🛡️  恶意流量控制系统 - 实时性能监控"
        echo "========================================"
        echo -e "${NC}"
        
        # 显示时间戳
        echo -e "${CYAN}📅 监控时间: $(date '+%Y-%m-%d %H:%M:%S')${NC}"
        echo -e "${CYAN}🔄 刷新间隔: ${REFRESH_INTERVAL}秒${NC}"
        
        # 获取各项指标
        get_system_info
        get_container_status
        get_response_times
        get_resource_usage
        get_container_resources
        get_performance_metrics
        get_alerts
        
        # 显示操作提示
        echo -e "\n${BLUE}💡 操作提示:${NC}"
        echo "  Ctrl+C: 退出监控"
        echo "  k6 run tests/performance/load-test.js: 运行性能测试"
        
        # 记录日志
        echo "$(date '+%Y-%m-%d %H:%M:%S') - 监控数据已更新" >> "$LOG_FILE"
        
        # 等待下次刷新
        sleep $REFRESH_INTERVAL
    done
}

# 单次监控
monitor_once() {
    echo -e "${PURPLE}"
    echo "🛡️  恶意流量控制系统 - 性能快照"
    echo "========================================"
    echo -e "${NC}"
    
    get_system_info
    get_container_status
    get_response_times
    get_resource_usage
    get_container_resources
    get_performance_metrics
    get_alerts
}

# 显示帮助信息
show_help() {
    echo "📊 性能监控脚本使用说明"
    echo "========================"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help     显示帮助信息"
    echo "  -o, --once     执行单次监控"
    echo "  -i, --interval 设置刷新间隔(秒，默认2秒)"
    echo ""
    echo "示例:"
    echo "  $0                    # 启动实时监控"
    echo "  $0 --once            # 执行单次监控"
    echo "  $0 --interval 5      # 5秒刷新间隔"
    echo ""
    echo "快捷键:"
    echo "  Ctrl+C               # 退出监控"
}

# 主函数
main() {
    local once_mode=false
    
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -o|--once)
                once_mode=true
                shift
                ;;
            -i|--interval)
                REFRESH_INTERVAL="$2"
                shift 2
                ;;
            *)
                echo "未知选项: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # 检查依赖
    if ! command -v curl >/dev/null 2>&1; then
        echo -e "${RED}❌ 需要安装curl${NC}"
        exit 1
    fi
    
    # 执行监控
    if [[ "$once_mode" == true ]]; then
        monitor_once
    else
        echo -e "${GREEN}🚀 启动实时性能监控...${NC}"
        echo -e "${YELLOW}💡 按 Ctrl+C 退出监控${NC}"
        sleep 2
        monitor_loop
    fi
}

# 错误处理
trap 'echo -e "\n${YELLOW}📊 监控已停止${NC}"; exit 0' INT

# 运行主函数
main "$@"