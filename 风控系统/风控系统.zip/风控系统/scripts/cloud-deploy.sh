#!/bin/bash

# ☁️ 云服务器一键部署脚本
# 适用于阿里云、腾讯云、AWS等主流云服务商

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 配置变量
CLOUD_PROVIDER=""
SERVER_SPECS=""
DOMAIN_NAME=""
SSL_ENABLED=false

# 日志函数
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warn() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

log_step() {
    echo -e "\n${PURPLE}🚀 $1${NC}"
    echo "=================================="
}

# 检测云服务商
detect_cloud_provider() {
    log_step "1. 检测云服务商环境"
    
    # 检测阿里云
    if curl -s --connect-timeout 3 http://100.100.100.200/latest/meta-data/instance-id >/dev/null 2>&1; then
        CLOUD_PROVIDER="aliyun"
        log_success "检测到阿里云ECS环境"
        return
    fi
    
    # 检测腾讯云
    if curl -s --connect-timeout 3 http://metadata.tencentcloudapi.com/latest/meta-data/instance-id >/dev/null 2>&1; then
        CLOUD_PROVIDER="tencent"
        log_success "检测到腾讯云CVM环境"
        return
    fi
    
    # 检测AWS
    if curl -s --connect-timeout 3 http://169.254.169.254/latest/meta-data/instance-id >/dev/null 2>&1; then
        CLOUD_PROVIDER="aws"
        log_success "检测到AWS EC2环境"
        return
    fi
    
    # 检测Azure
    if curl -s --connect-timeout 3 -H "Metadata:true" "http://169.254.169.254/metadata/instance?api-version=2021-02-01" >/dev/null 2>&1; then
        CLOUD_PROVIDER="azure"
        log_success "检测到Azure VM环境"
        return
    fi
    
    # 检测Google Cloud
    if curl -s --connect-timeout 3 -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/id >/dev/null 2>&1; then
        CLOUD_PROVIDER="gcp"
        log_success "检测到Google Cloud环境"
        return
    fi
    
    # 未检测到特定云服务商
    CLOUD_PROVIDER="generic"
    log_warn "未检测到特定云服务商，使用通用Linux配置"
}

# 获取服务器规格信息
get_server_specs() {
    log_step "2. 获取服务器规格信息"
    
    local cpu_cores=$(nproc)
    local memory_gb=$(free -g | awk '/^Mem:/{print $2}')
    local disk_gb=$(df -BG / | awk 'NR==2 {print $2}' | sed 's/G//')
    
    SERVER_SPECS="${cpu_cores}C${memory_gb}G${disk_gb}GB"
    
    log_info "服务器规格: $SERVER_SPECS"
    log_info "CPU核心: $cpu_cores"
    log_info "内存容量: ${memory_gb}GB"
    log_info "磁盘容量: ${disk_gb}GB"
    
    # 性能等级评估
    local performance_level=""
    if [[ $cpu_cores -ge 8 && $memory_gb -ge 16 ]]; then
        performance_level="高性能 (预估150K+ QPS)"
        log_success "服务器配置: $performance_level"
    elif [[ $cpu_cores -ge 4 && $memory_gb -ge 8 ]]; then
        performance_level="标准配置 (预估80K+ QPS)"
        log_success "服务器配置: $performance_level"
    else
        performance_level="基础配置 (预估30K+ QPS)"
        log_warn "服务器配置: $performance_level"
    fi
}

# 云服务商特定优化
apply_cloud_optimizations() {
    log_step "3. 应用云服务商特定优化"
    
    case $CLOUD_PROVIDER in
        "aliyun")
            log_info "应用阿里云ECS优化..."
            # 阿里云特定优化
            echo 'net.ipv4.tcp_congestion_control = bbr' | sudo tee -a /etc/sysctl.conf
            # 阿里云内网DNS优化
            echo 'nameserver 100.100.2.136' | sudo tee /etc/resolv.conf.backup
            log_success "阿里云优化完成"
            ;;
        "tencent")
            log_info "应用腾讯云CVM优化..."
            # 腾讯云特定优化
            echo 'net.ipv4.tcp_congestion_control = bbr' | sudo tee -a /etc/sysctl.conf
            # 腾讯云内网DNS优化
            echo 'nameserver 183.60.83.19' | sudo tee /etc/resolv.conf.backup
            log_success "腾讯云优化完成"
            ;;
        "aws")
            log_info "应用AWS EC2优化..."
            # AWS特定优化
            echo 'net.ipv4.tcp_congestion_control = bbr' | sudo tee -a /etc/sysctl.conf
            # 启用增强网络
            sudo ethtool -K eth0 sg on tso on gso on gro on lro on
            log_success "AWS优化完成"
            ;;
        "azure")
            log_info "应用Azure VM优化..."
            # Azure特定优化
            echo 'net.ipv4.tcp_congestion_control = bbr' | sudo tee -a /etc/sysctl.conf
            log_success "Azure优化完成"
            ;;
        "gcp")
            log_info "应用Google Cloud优化..."
            # GCP特定优化
            echo 'net.ipv4.tcp_congestion_control = bbr' | sudo tee -a /etc/sysctl.conf
            log_success "Google Cloud优化完成"
            ;;
        *)
            log_info "应用通用Linux优化..."
            echo 'net.ipv4.tcp_congestion_control = bbr' | sudo tee -a /etc/sysctl.conf
            log_success "通用优化完成"
            ;;
    esac
    
    # 应用系统优化
    sudo sysctl -p
}

# 安装云服务商工具
install_cloud_tools() {
    log_step "4. 安装云服务商工具"
    
    case $CLOUD_PROVIDER in
        "aliyun")
            log_info "安装阿里云工具..."
            # 安装阿里云CLI (可选)
            if ! command -v aliyun >/dev/null 2>&1; then
                wget https://aliyuncli.alicdn.com/aliyun-cli-linux-latest-amd64.tgz
                tar -xzf aliyun-cli-linux-latest-amd64.tgz
                sudo mv aliyun /usr/local/bin/
                rm aliyun-cli-linux-latest-amd64.tgz
                log_success "阿里云CLI安装完成"
            fi
            ;;
        "tencent")
            log_info "安装腾讯云工具..."
            # 安装腾讯云CLI (可选)
            pip3 install tencentcloud-sdk-python >/dev/null 2>&1 || true
            log_success "腾讯云工具安装完成"
            ;;
        "aws")
            log_info "安装AWS工具..."
            # 安装AWS CLI
            if ! command -v aws >/dev/null 2>&1; then
                curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
                unzip awscliv2.zip >/dev/null
                sudo ./aws/install
                rm -rf aws awscliv2.zip
                log_success "AWS CLI安装完成"
            fi
            ;;
        *)
            log_info "跳过云服务商特定工具安装"
            ;;
    esac
}

# 配置防火墙和安全组
configure_security() {
    log_step "5. 配置防火墙和安全组"
    
    # 配置UFW防火墙
    if command -v ufw >/dev/null 2>&1; then
        log_info "配置UFW防火墙..."
        sudo ufw --force reset
        sudo ufw default deny incoming
        sudo ufw default allow outgoing
        
        # 开放必要端口
        sudo ufw allow 22/tcp    # SSH
        sudo ufw allow 80/tcp    # HTTP
        sudo ufw allow 443/tcp   # HTTPS
        sudo ufw allow 3000/tcp  # 管理面板
        sudo ufw allow 3001/tcp  # 监控面板
        sudo ufw allow 9090/tcp  # Prometheus
        
        sudo ufw --force enable
        log_success "防火墙配置完成"
    fi
    
    # 显示安全组配置建议
    log_info "安全组配置建议:"
    echo "  📋 入站规则:"
    echo "    - SSH (22): 仅允许管理IP"
    echo "    - HTTP (80): 0.0.0.0/0"
    echo "    - HTTPS (443): 0.0.0.0/0"
    echo "    - 管理面板 (3000): 仅允许管理IP"
    echo "    - 监控面板 (3001): 仅允许管理IP"
    echo "  📤 出站规则: 允许所有"
}

# 获取公网IP和域名配置
configure_domain() {
    log_step "6. 获取公网IP和域名配置"
    
    # 获取公网IP
    local public_ip=$(curl -s ifconfig.me 2>/dev/null || curl -s ipinfo.io/ip 2>/dev/null || echo "未知")
    log_info "公网IP: $public_ip"
    
    # 域名配置提示
    if [[ -n "$DOMAIN_NAME" ]]; then
        log_info "域名配置: $DOMAIN_NAME"
        log_info "请确保DNS记录指向: $public_ip"
    else
        log_warn "未配置域名，将使用IP地址访问"
        log_info "建议配置域名以获得更好的体验"
    fi
    
    # SSL证书配置
    if [[ "$SSL_ENABLED" == true && -n "$DOMAIN_NAME" ]]; then
        log_info "配置SSL证书..."
        # 这里可以集成Let's Encrypt等SSL证书服务
        log_warn "SSL配置需要手动完成，请参考文档"
    fi
}

# 部署应用
deploy_application() {
    log_step "7. 部署恶意流量控制系统"
    
    # 调用Linux部署脚本
    if [[ -f "./scripts/linux-deploy.sh" ]]; then
        log_info "调用Linux优化部署脚本..."
        chmod +x ./scripts/linux-deploy.sh
        ./scripts/linux-deploy.sh
    else
        log_error "未找到Linux部署脚本"
        exit 1
    fi
}

# 配置监控和告警
configure_monitoring() {
    log_step "8. 配置云监控和告警"
    
    case $CLOUD_PROVIDER in
        "aliyun")
            log_info "配置阿里云监控..."
            log_info "建议在阿里云控制台配置以下监控:"
            echo "  📊 CPU使用率 > 80% 告警"
            echo "  🧠 内存使用率 > 85% 告警"
            echo "  💾 磁盘使用率 > 90% 告警"
            echo "  🌐 网络带宽使用率 > 80% 告警"
            ;;
        "tencent")
            log_info "配置腾讯云监控..."
            log_info "建议在腾讯云控制台配置监控告警"
            ;;
        "aws")
            log_info "配置AWS CloudWatch..."
            log_info "建议配置CloudWatch告警和日志"
            ;;
        *)
            log_info "配置通用监控..."
            ;;
    esac
    
    # 启动性能监控脚本
    if [[ -f "./scripts/monitor-performance.sh" ]]; then
        chmod +x ./scripts/monitor-performance.sh
        log_success "性能监控脚本已准备就绪"
        log_info "运行命令: ./scripts/monitor-performance.sh"
    fi
}

# 显示部署完成信息
show_deployment_summary() {
    log_step "9. 部署完成总结"
    
    local public_ip=$(curl -s ifconfig.me 2>/dev/null || echo "未知")
    
    echo -e "${GREEN}🎉 云服务器部署成功！${NC}"
    echo ""
    echo -e "${BLUE}☁️  云服务商: ${CYAN}$CLOUD_PROVIDER${NC}"
    echo -e "${BLUE}🖥️  服务器规格: ${CYAN}$SERVER_SPECS${NC}"
    echo -e "${BLUE}🌐 公网IP: ${CYAN}$public_ip${NC}"
    
    echo ""
    echo -e "${BLUE}📊 访问地址:${NC}"
    echo "  🛡️  系统入口:    http://$public_ip:80"
    echo "  📊 管理面板:    http://$public_ip:3000"
    echo "  📈 监控面板:    http://$public_ip:3001 (admin/admin_secure_2024)"
    echo "  🔍 指标监控:    http://$public_ip:9090"
    
    if [[ -n "$DOMAIN_NAME" ]]; then
        echo ""
        echo -e "${BLUE}🌐 域名访问:${NC}"
        echo "  🛡️  系统入口:    http://$DOMAIN_NAME"
        echo "  📊 管理面板:    http://$DOMAIN_NAME:3000"
    fi
    
    echo ""
    echo -e "${BLUE}🚀 性能预估 (云服务器):${NC}"
    echo "  ⚡ QPS: 150K+ (Linux原生性能)"
    echo "  🕐 延迟: <5ms P95"
    echo "  📊 错误率: <0.01%"
    echo "  🔄 可用性: 99.99%+"
    
    echo ""
    echo -e "${BLUE}🔧 管理命令:${NC}"
    echo "  📊 性能监控:    ./scripts/monitor-performance.sh"
    echo "  📋 查看状态:    docker-compose ps"
    echo "  📝 查看日志:    docker-compose logs -f"
    echo "  🔄 重启服务:    docker-compose restart"
    
    echo ""
    echo -e "${GREEN}💡 下一步建议:${NC}"
    echo "  🔒 配置SSL证书 (Let's Encrypt)"
    echo "  📊 配置云监控告警"
    echo "  🛡️  配置CDN加速"
    echo "  📈 运行性能测试验证"
    
    echo ""
    echo -e "${YELLOW}⚠️  安全提醒:${NC}"
    echo "  🔐 修改默认密码"
    echo "  🛡️  配置安全组规则"
    echo "  📋 定期备份数据"
    echo "  🔄 保持系统更新"
}

# 主函数
main() {
    echo -e "${PURPLE}"
    echo "☁️  云服务器一键部署脚本"
    echo "=================================="
    echo "🛡️  恶意流量控制系统"
    echo "🚀 专为云环境优化"
    echo -e "${NC}"
    
    # 检查root权限
    if [[ $EUID -eq 0 ]]; then
        log_warn "检测到root用户，建议使用普通用户+sudo"
    fi
    
    # 执行部署步骤
    detect_cloud_provider
    get_server_specs
    apply_cloud_optimizations
    install_cloud_tools
    configure_security
    configure_domain
    deploy_application
    configure_monitoring
    show_deployment_summary
    
    echo ""
    echo -e "${GREEN}🎉 云服务器部署完成！享受云原生的极致性能！${NC}"
}

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --domain)
            DOMAIN_NAME="$2"
            shift 2
            ;;
        --ssl)
            SSL_ENABLED=true
            shift
            ;;
        -h|--help)
            echo "云服务器部署脚本使用说明"
            echo "========================"
            echo ""
            echo "用法: $0 [选项]"
            echo ""
            echo "选项:"
            echo "  --domain DOMAIN    配置域名"
            echo "  --ssl              启用SSL证书"
            echo "  -h, --help         显示帮助信息"
            echo ""
            echo "示例:"
            echo "  $0                              # 基础部署"
            echo "  $0 --domain example.com        # 配置域名"
            echo "  $0 --domain example.com --ssl  # 配置域名和SSL"
            exit 0
            ;;
        *)
            log_error "未知选项: $1"
            exit 1
            ;;
    esac
done

# 错误处理
trap 'log_error "部署过程中发生错误，请检查日志"' ERR

# 运行主函数
main "$@"