# 恶意流量控制系统 - Windows PowerShell 部署脚本
# 让Windows用户也能轻松部署

param(
    [string]$DeploymentMode = "medium",
    [int]$WebPort = 8080,
    [string]$InstallDir = "$env:USERPROFILE\mtcs"
)

# 颜色定义
$Colors = @{
    Red = "Red"
    Green = "Green"
    Yellow = "Yellow"
    Blue = "Blue"
    Cyan = "Cyan"
    White = "White"
}

# 打印函数
function Write-Header {
    param([string]$Message)
    Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Blue
    Write-Host "║                    $Message                    ║" -ForegroundColor Blue
    Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Blue
}

function Write-Success {
    param([string]$Message)
    Write-Host "[✓] $Message" -ForegroundColor Green
}

function Write-Warning {
    param([string]$Message)
    Write-Host "[⚠] $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "[✗] $Message" -ForegroundColor Red
}

function Write-Info {
    param([string]$Message)
    Write-Host "[ℹ] $Message" -ForegroundColor Cyan
}

function Write-Step {
    param([string]$Message)
    Write-Host "[→] $Message" -ForegroundColor Blue
}

# 显示欢迎信息
function Show-Welcome {
    Clear-Host
    Write-Host @"
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║    🛡️  恶意流量控制系统 - Windows 一键部署工具 🛡️            ║
    ║                                                              ║
    ║    🚀 3分钟快速部署，开箱即用                                 ║
    ║    🔧 智能配置检测，自动优化                                  ║
    ║    📊 可视化管理界面，简单易用                                ║
    ║    🛡️ 多层防护机制，安全可靠                                 ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
"@ -ForegroundColor Blue
    
    Write-Info "欢迎使用恶意流量控制系统 Windows 部署工具！"
    Write-Host ""
}

# 检查系统要求
function Test-SystemRequirements {
    Write-Step "检查系统要求..."
    
    # 检查Windows版本
    $osVersion = [System.Environment]::OSVersion.Version
    if ($osVersion.Major -lt 10) {
        Write-Warning "建议使用 Windows 10 或更高版本"
    } else {
        Write-Success "Windows 版本检查通过"
    }
    
    # 检查PowerShell版本
    if ($PSVersionTable.PSVersion.Major -lt 5) {
        Write-Error "需要 PowerShell 5.0 或更高版本"
        return $false
    } else {
        Write-Success "PowerShell 版本检查通过"
    }
    
    return $true
}

# 检查Docker Desktop
function Test-DockerDesktop {
    Write-Step "检查 Docker Desktop..."
    
    try {
        $dockerVersion = docker --version 2>$null
        if ($dockerVersion) {
            Write-Success "Docker Desktop 已安装: $dockerVersion"
            
            # 检查Docker是否运行
            try {
                docker info 2>$null | Out-Null
                Write-Success "Docker Desktop 运行正常"
                return $true
            } catch {
                Write-Warning "Docker Desktop 未运行，请启动 Docker Desktop"
                Write-Info "正在尝试启动 Docker Desktop..."
                Start-Process "Docker Desktop" -ErrorAction SilentlyContinue
                
                # 等待Docker启动
                $timeout = 60
                $elapsed = 0
                while ($elapsed -lt $timeout) {
                    try {
                        docker info 2>$null | Out-Null
                        Write-Success "Docker Desktop 已启动"
                        return $true
                    } catch {
                        Start-Sleep -Seconds 2
                        $elapsed += 2
                        Write-Host "." -NoNewline
                    }
                }
                Write-Host ""
                Write-Error "Docker Desktop 启动超时"
                return $false
            }
        } else {
            Write-Error "Docker Desktop 未安装"
            Write-Info "请从以下地址下载安装 Docker Desktop:"
            Write-Info "https://docs.docker.com/desktop/windows/install/"
            return $false
        }
    } catch {
        Write-Error "无法检测 Docker Desktop 状态"
        return $false
    }
}

# 检查系统资源
function Test-SystemResources {
    Write-Step "检查系统资源..."
    
    # 检查CPU核心数
    $cpuCores = (Get-WmiObject -Class Win32_ComputerSystem).NumberOfLogicalProcessors
    Write-Info "CPU核心数: $cpuCores"
    
    # 检查内存
    $totalMemory = [math]::Round((Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)
    Write-Info "总内存: ${totalMemory}GB"
    
    # 检查可用磁盘空间
    $disk = Get-WmiObject -Class Win32_LogicalDisk | Where-Object { $_.DeviceID -eq "C:" }
    $freeSpace = [math]::Round($disk.FreeSpace / 1GB, 1)
    Write-Info "C盘可用空间: ${freeSpace}GB"
    
    # 检查资源是否满足要求
    $resourceOk = $true
    
    if ($cpuCores -lt 2) {
        Write-Warning "CPU核心数不足 (当前: $cpuCores, 建议: 2+)"
        $resourceOk = $false
    }
    
    if ($totalMemory -lt 4) {
        Write-Warning "内存不足 (当前: ${totalMemory}GB, 建议: 4GB+)"
        $resourceOk = $false
    }
    
    if ($freeSpace -lt 20) {
        Write-Warning "磁盘空间不足 (当前: ${freeSpace}GB, 建议: 20GB+)"
        $resourceOk = $false
    }
    
    if (-not $resourceOk) {
        $continue = Read-Host "资源不足可能影响性能，是否继续? (y/N)"
        if ($continue -ne "y" -and $continue -ne "Y") {
            Write-Info "部署已取消"
            exit 0
        }
    } else {
        Write-Success "系统资源检查通过"
    }
    
    return $resourceOk
}

# 选择部署模式
function Select-DeploymentMode {
    if ($DeploymentMode -ne "medium") {
        Write-Success "使用指定的部署模式: $DeploymentMode"
        return $DeploymentMode
    }
    
    Write-Header "选择部署模式"
    Write-Host ""
    Write-Host "请根据您的需求选择部署模式："
    Write-Host ""
    Write-Host "1) 🏠 小型部署 (适合个人/小团队)"
    Write-Host "   • 支持 < 1万 QPS"
    Write-Host "   • 资源需求: 2核4GB"
    Write-Host "   • 适用场景: 个人网站、小型API"
    Write-Host ""
    Write-Host "2) 🏢 中型部署 (适合中小企业)"
    Write-Host "   • 支持 1万-10万 QPS"
    Write-Host "   • 资源需求: 4核8GB"
    Write-Host "   • 适用场景: 企业网站、电商平台"
    Write-Host ""
    Write-Host "3) 🏭 大型部署 (适合大型企业)"
    Write-Host "   • 支持 > 10万 QPS"
    Write-Host "   • 资源需求: 8核16GB+"
    Write-Host "   • 适用场景: 大型平台、金融机构"
    Write-Host ""
    
    do {
        $choice = Read-Host "请输入选择 (1-3)"
        switch ($choice) {
            "1" { 
                $selectedMode = "small"
                Write-Success "已选择: 小型部署模式"
                break
            }
            "2" { 
                $selectedMode = "medium"
                Write-Success "已选择: 中型部署模式"
                break
            }
            "3" { 
                $selectedMode = "large"
                Write-Success "已选择: 大型部署模式"
                break
            }
            default { 
                Write-Error "无效选择，请输入1-3"
                continue
            }
        }
        break
    } while ($true)
    
    return $selectedMode
}

# 创建目录结构
function New-DirectoryStructure {
    Write-Step "创建目录结构..."
    
    $directories = @(
        $InstallDir,
        "$InstallDir\config",
        "$InstallDir\data",
        "$InstallDir\logs",
        "$InstallDir\models",
        "$InstallDir\scripts"
    )
    
    foreach ($dir in $directories) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
    }
    
    Write-Success "目录结构创建完成"
}

# 生成配置文件
function New-ConfigFiles {
    Write-Step "生成配置文件..."
    
    # 生成随机密码
    function New-RandomPassword {
        param([int]$Length = 16)
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        $password = ""
        for ($i = 0; $i -lt $Length; $i++) {
            $password += $chars[(Get-Random -Maximum $chars.Length)]
        }
        return $password
    }
    
    # 生成.env文件
    $envContent = @"
# 恶意流量控制系统配置文件
# 部署模式: $DeploymentMode
# 生成时间: $(Get-Date)

# 基础配置
DEPLOYMENT_MODE=$DeploymentMode
WEB_PORT=$WebPort
ADMIN_PASSWORD=$(New-RandomPassword -Length 32)

# 数据库配置
DATABASE_TYPE=redis
REDIS_PASSWORD=$(New-RandomPassword -Length 16)

# 消息队列配置
MESSAGE_QUEUE=kafka

# 安全配置
JWT_SECRET=$(New-RandomPassword -Length 64)
ENCRYPTION_KEY=$(New-RandomPassword -Length 32)

# 监控配置
METRICS_ENABLED=true
PROMETHEUS_PORT=9090
GRAFANA_PORT=3000

# 日志配置
LOG_LEVEL=info
LOG_FORMAT=json
"@
    
    $envContent | Out-File -FilePath "$InstallDir\.env" -Encoding UTF8
    
    # 生成docker-compose文件
    $composeContent = @"
version: '3.8'

services:
  # 边缘网关
  edge-gateway:
    image: mtcs/edge-gateway:latest
    ports:
      - "$WebPort`:80"
      - "443:443"
    environment:
      - DEPLOYMENT_MODE=$DeploymentMode
    volumes:
      - ./config/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./logs:/var/log/nginx
    depends_on:
      - stream-processor
      - ml-inference
    restart: unless-stopped

  # 流处理服务
  stream-processor:
    image: mtcs/stream-processor:latest
    environment:
      - DEPLOYMENT_MODE=$DeploymentMode
      - KAFKA_BROKERS=kafka:9092
      - REDIS_URL=redis://redis:6379
    depends_on:
      - kafka
      - redis
    restart: unless-stopped

  # ML推理服务
  ml-inference:
    image: mtcs/ml-inference:latest
    environment:
      - DEPLOYMENT_MODE=$DeploymentMode
      - MODEL_PATH=/app/models
    volumes:
      - ./models:/app/models:ro
    restart: unless-stopped

  # Redis缓存
  redis:
    image: redis:7-alpine
    command: redis-server --requirepass `${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    restart: unless-stopped

  # Kafka消息队列
  kafka:
    image: confluentinc/cp-kafka:latest
    environment:
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    depends_on:
      - zookeeper
    volumes:
      - kafka_data:/var/lib/kafka/data
    restart: unless-stopped

  # Zookeeper
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
    volumes:
      - zookeeper_data:/var/lib/zookeeper/data
    restart: unless-stopped

  # Prometheus监控
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - prometheus_data:/prometheus
    restart: unless-stopped

  # Grafana可视化
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=`${ADMIN_PASSWORD}
    volumes:
      - grafana_data:/var/lib/grafana
    restart: unless-stopped

volumes:
  redis_data:
  kafka_data:
  zookeeper_data:
  prometheus_data:
  grafana_data:

networks:
  default:
    name: mtcs-network
"@
    
    $composeContent | Out-File -FilePath "$InstallDir\docker-compose.yml" -Encoding UTF8
    
    Write-Success "配置文件生成完成"
}

# 下载模型文件
function Get-ModelFiles {
    Write-Step "下载ML模型文件..."
    
    $modelsDir = "$InstallDir\models"
    
    # 创建示例模型文件（实际部署时应该下载真实模型）
    $lightModelPath = "$modelsDir\light_model.onnx"
    $heavyModelPath = "$modelsDir\heavy_model.onnx"
    
    if (-not (Test-Path $lightModelPath)) {
        Write-Info "创建轻量级模型占位符..."
        "# Light Model Placeholder" | Out-File -FilePath $lightModelPath -Encoding UTF8
    }
    
    if (-not (Test-Path $heavyModelPath)) {
        Write-Info "创建重型模型占位符..."
        "# Heavy Model Placeholder" | Out-File -FilePath $heavyModelPath -Encoding UTF8
    }
    
    Write-Success "模型文件准备完成"
}

# 拉取Docker镜像
function Get-DockerImages {
    Write-Step "拉取Docker镜像..."
    
    Push-Location $InstallDir
    
    try {
        Write-Info "正在拉取镜像，请稍候..."
        
        # 拉取基础镜像
        $images = @(
            "redis:7-alpine",
            "confluentinc/cp-kafka:latest",
            "confluentinc/cp-zookeeper:latest",
            "prom/prometheus:latest",
            "grafana/grafana:latest"
        )
        
        foreach ($image in $images) {
            Write-Info "拉取镜像: $image"
            docker pull $image 2>$null
        }
        
        Write-Success "Docker镜像拉取完成"
    } catch {
        Write-Error "拉取Docker镜像失败: $_"
        return $false
    } finally {
        Pop-Location
    }
    
    return $true
}

# 启动服务
function Start-Services {
    Write-Step "启动服务..."
    
    Push-Location $InstallDir
    
    try {
        docker-compose up -d
        Write-Success "服务启动完成"
        return $true
    } catch {
        Write-Error "启动服务失败: $_"
        return $false
    } finally {
        Pop-Location
    }
}

# 等待服务就绪
function Wait-ForServices {
    Write-Step "等待服务就绪..."
    
    $maxAttempts = 60
    $attempt = 0
    
    Write-Host "检查服务状态" -NoNewline
    
    while ($attempt -lt $maxAttempts) {
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:$WebPort/health" -TimeoutSec 5 -ErrorAction Stop
            if ($response.StatusCode -eq 200) {
                Write-Host ""
                Write-Success "所有服务已就绪"
                return $true
            }
        } catch {
            # 继续等待
        }
        
        Write-Host "." -NoNewline
        Start-Sleep -Seconds 5
        $attempt++
    }
    
    Write-Host ""
    Write-Warning "服务启动可能需要更多时间，请稍后检查"
    return $false
}

# 创建管理脚本
function New-ManagementScripts {
    Write-Step "创建管理脚本..."
    
    $scriptsDir = "$InstallDir\scripts"
    
    # 启动脚本
    @"
# 启动服务
Set-Location "$InstallDir"
docker-compose up -d
Write-Host "服务已启动" -ForegroundColor Green
"@ | Out-File -FilePath "$scriptsDir\start.ps1" -Encoding UTF8
    
    # 停止脚本
    @"
# 停止服务
Set-Location "$InstallDir"
docker-compose down
Write-Host "服务已停止" -ForegroundColor Green
"@ | Out-File -FilePath "$scriptsDir\stop.ps1" -Encoding UTF8
    
    # 重启脚本
    @"
# 重启服务
Set-Location "$InstallDir"
docker-compose restart
Write-Host "服务已重启" -ForegroundColor Green
"@ | Out-File -FilePath "$scriptsDir\restart.ps1" -Encoding UTF8
    
    # 状态检查脚本
    @"
# 查看服务状态
Set-Location "$InstallDir"
docker-compose ps
"@ | Out-File -FilePath "$scriptsDir\status.ps1" -Encoding UTF8
    
    # 日志查看脚本
    @"
# 查看日志
param([string]`$Service)
Set-Location "$InstallDir"
if (`$Service) {
    docker-compose logs -f `$Service
} else {
    docker-compose logs -f
}
"@ | Out-File -FilePath "$scriptsDir\logs.ps1" -Encoding UTF8
    
    Write-Success "管理脚本创建完成"
}

# 显示部署结果
function Show-DeploymentResult {
    Clear-Host
    Write-Header "部署完成"
    Write-Host ""
    
    Write-Host "🎉 恭喜！恶意流量控制系统部署成功！" -ForegroundColor Green
    Write-Host ""
    Write-Host "📊 访问地址:" -ForegroundColor Cyan
    Write-Host "  • 管理界面: http://localhost:$WebPort"
    Write-Host "  • API文档:  http://localhost:$WebPort/docs"
    Write-Host "  • 监控面板: http://localhost:9090"
    Write-Host "  • 可视化:   http://localhost:3000"
    Write-Host ""
    Write-Host "🔧 管理命令:" -ForegroundColor Cyan
    Write-Host "  • 启动服务: PowerShell $InstallDir\scripts\start.ps1"
    Write-Host "  • 停止服务: PowerShell $InstallDir\scripts\stop.ps1"
    Write-Host "  • 重启服务: PowerShell $InstallDir\scripts\restart.ps1"
    Write-Host "  • 查看状态: PowerShell $InstallDir\scripts\status.ps1"
    Write-Host "  • 查看日志: PowerShell $InstallDir\scripts\logs.ps1"
    Write-Host ""
    Write-Host "📁 重要目录:" -ForegroundColor Cyan
    Write-Host "  • 安装目录: $InstallDir"
    Write-Host "  • 配置文件: $InstallDir\config"
    Write-Host "  • 数据目录: $InstallDir\data"
    Write-Host "  • 日志目录: $InstallDir\logs"
    Write-Host ""
    Write-Host "💡 使用提示:" -ForegroundColor Yellow
    Write-Host "  • 首次登录管理界面需要设置管理员密码"
    Write-Host "  • 建议定期备份配置文件和数据"
    Write-Host "  • 可通过管理界面进行系统配置和监控"
    Write-Host ""
    Write-Host "🛡️ 享受您的恶意流量控制系统！" -ForegroundColor Green
    Write-Host ""
    
    # 自动打开浏览器
    try {
        Start-Process "http://localhost:$WebPort"
    } catch {
        Write-Info "请手动打开浏览器访问: http://localhost:$WebPort"
    }
}

# 主函数
function Main {
    try {
        Show-Welcome
        
        if (-not (Test-SystemRequirements)) {
            exit 1
        }
        
        if (-not (Test-DockerDesktop)) {
            exit 1
        }
        
        Test-SystemResources
        
        $selectedMode = Select-DeploymentMode
        $script:DeploymentMode = $selectedMode
        
        New-DirectoryStructure
        New-ConfigFiles
        Get-ModelFiles
        
        if (-not (Get-DockerImages)) {
            exit 1
        }
        
        if (-not (Start-Services)) {
            exit 1
        }
        
        Wait-ForServices
        New-ManagementScripts
        Show-DeploymentResult
        
    } catch {
        Write-Error "部署过程中发生错误: $_"
        Write-Info "请检查错误信息并重试，或联系技术支持"
        exit 1
    }
}

# 显示帮助
function Show-Help {
    Write-Host "恶意流量控制系统 - Windows PowerShell 部署工具"
    Write-Host ""
    Write-Host "用法: .\easy-deploy.ps1 [参数]"
    Write-Host ""
    Write-Host "参数:"
    Write-Host "  -DeploymentMode  部署模式 (small/medium/large, 默认: medium)"
    Write-Host "  -WebPort         Web端口 (默认: 8080)"
    Write-Host "  -InstallDir      安装目录 (默认: %USERPROFILE%\mtcs)"
    Write-Host ""
    Write-Host "示例:"
    Write-Host "  .\easy-deploy.ps1 -DeploymentMode small -WebPort 9000"
    Write-Host ""
}

# 处理命令行参数
if ($args -contains "-help" -or $args -contains "--help" -or $args -contains "-h") {
    Show-Help
    exit 0
}

# 运行主函数
Main