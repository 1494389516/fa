#!/bin/bash

# 集成测试脚本

set -e

echo "🧪 开始运行集成测试..."

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 测试计数器
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# 测试函数
run_test() {
    local test_name=$1
    local test_command=$2
    
    echo -e "${BLUE}运行测试: $test_name${NC}"
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    
    if eval "$test_command"; then
        echo -e "${GREEN}✓ $test_name 通过${NC}"
        PASSED_TESTS=$((PASSED_TESTS + 1))
        return 0
    else
        echo -e "${RED}✗ $test_name 失败${NC}"
        FAILED_TESTS=$((FAILED_TESTS + 1))
        return 1
    fi
}

# API测试函数
test_api() {
    local name=$1
    local method=$2
    local url=$3
    local expected_status=$4
    local data=$5
    
    if [ "$method" = "POST" ] && [ -n "$data" ]; then
        response=$(curl -s -w "%{http_code}" -X POST -H "Content-Type: application/json" -d "$data" "$url")
    else
        response=$(curl -s -w "%{http_code}" -X "$method" "$url")
    fi
    
    status_code="${response: -3}"
    
    if [ "$status_code" = "$expected_status" ]; then
        return 0
    else
        echo "期望状态码: $expected_status, 实际状态码: $status_code"
        return 1
    fi
}

echo "📋 等待服务启动完成..."
sleep 10

echo "🔍 1. 基础健康检查测试"
run_test "边缘网关健康检查" "test_api '边缘网关' 'GET' 'http://localhost:8080/health' '200'"
run_test "策略引擎健康检查" "test_api '策略引擎' 'GET' 'http://localhost:8081/api/v1/health' '200'"
run_test "反爬服务健康检查" "test_api '反爬服务' 'GET' 'http://localhost:8082/api/v1/health' '200'"
run_test "ML推理服务健康检查" "test_api 'ML推理服务' 'GET' 'http://localhost:8084/health' '200'"
run_test "蜜罐服务健康检查" "test_api '蜜罐服务' 'GET' 'http://localhost:8086/health' '200'"

echo ""
echo "🔗 2. 服务间通信测试"

# 策略决策API测试
policy_payload='{"threat_score": 0.8, "client_info": {"ip": "192.168.1.100", "user_agent": "test-agent", "ja3": "test-ja3"}}'
run_test "策略决策API" "test_api '策略决策' 'POST' 'http://localhost:8081/api/v1/policy/decide' '200' '$policy_payload'"

# Token验证API测试
token_payload='{"token": "test-token", "signature": "test-signature", "timestamp": 1640995200}'
run_test "Token验证API" "test_api 'Token验证' 'POST' 'http://localhost:8082/api/v1/verify-token' '200' '$token_payload'"

# ML推理API测试
inference_payload='{"features": [0.1, 0.2, 0.3, 0.4], "model_version": "v1.0"}'
run_test "ML推理API" "test_api 'ML推理' 'POST' 'http://localhost:8084/api/v1/inference' '200' '$inference_payload'"

# 蜜罐API测试
run_test "蜜罐用户API" "test_api '蜜罐用户' 'GET' 'http://localhost:8086/api/users' '200'"
run_test "蜜罐管理API" "test_api '蜜罐管理' 'GET' 'http://localhost:8086/api/admin' '200'"

echo ""
echo "📊 3. 数据流测试"

# 测试完整的威胁检测流程
test_threat_detection_flow() {
    echo "测试威胁检测流程..."
    
    # 1. 发送高威胁评分请求到策略引擎
    local high_threat_payload='{"threat_score": 0.9, "client_info": {"ip": "192.168.1.200", "user_agent": "suspicious-bot"}}'
    local response=$(curl -s -X POST -H "Content-Type: application/json" -d "$high_threat_payload" "http://localhost:8081/api/v1/policy/decide")
    
    # 2. 检查是否返回阻断动作
    if echo "$response" | grep -q '"action":"block"'; then
        return 0
    else
        echo "高威胁评分未触发阻断动作: $response"
        return 1
    fi
}

run_test "威胁检测流程" "test_threat_detection_flow"

# 测试反爬虫流程
test_anti_crawler_flow() {
    echo "测试反爬虫流程..."
    
    # 1. 生成签名URL
    local url_payload='{"resource": "/api/data", "expires_in": 3600}'
    local signed_response=$(curl -s -X POST -H "Content-Type: application/json" -d "$url_payload" "http://localhost:8082/api/v1/generate-signed-url")
    
    # 2. 检查是否返回签名URL
    if echo "$signed_response" | grep -q '"signed_url"'; then
        return 0
    else
        echo "签名URL生成失败: $signed_response"
        return 1
    fi
}

run_test "反爬虫流程" "test_anti_crawler_flow"

echo ""
echo "⚡ 4. 性能测试"

# 并发请求测试
test_concurrent_requests() {
    echo "测试并发请求处理..."
    
    local pids=()
    local success_count=0
    local total_requests=10
    
    # 并发发送10个请求
    for i in $(seq 1 $total_requests); do
        (
            response=$(curl -s -w "%{http_code}" "http://localhost:8081/api/v1/health")
            status_code="${response: -3}"
            if [ "$status_code" = "200" ]; then
                echo "success" > "/tmp/test_result_$i"
            else
                echo "failed" > "/tmp/test_result_$i"
            fi
        ) &
        pids+=($!)
    done
    
    # 等待所有请求完成
    for pid in "${pids[@]}"; do
        wait $pid
    done
    
    # 统计成功请求数
    for i in $(seq 1 $total_requests); do
        if [ -f "/tmp/test_result_$i" ] && [ "$(cat /tmp/test_result_$i)" = "success" ]; then
            success_count=$((success_count + 1))
        fi
        rm -f "/tmp/test_result_$i"
    done
    
    echo "并发请求成功率: $success_count/$total_requests"
    
    # 成功率大于80%认为通过
    if [ $success_count -ge 8 ]; then
        return 0
    else
        return 1
    fi
}

run_test "并发请求处理" "test_concurrent_requests"

echo ""
echo "🔒 5. 安全测试"

# SQL注入测试
test_sql_injection() {
    echo "测试SQL注入防护..."
    
    local malicious_payload='{"threat_score": 0.5, "client_info": {"ip": "192.168.1.1\"; DROP TABLE users; --", "user_agent": "test"}}'
    local response=$(curl -s -w "%{http_code}" -X POST -H "Content-Type: application/json" -d "$malicious_payload" "http://localhost:8081/api/v1/policy/decide")
    local status_code="${response: -3}"
    
    # 应该返回400或200，不应该返回500（服务器错误）
    if [ "$status_code" != "500" ]; then
        return 0
    else
        echo "SQL注入测试失败，服务器返回500错误"
        return 1
    fi
}

run_test "SQL注入防护" "test_sql_injection"

# XSS测试
test_xss_protection() {
    echo "测试XSS防护..."
    
    local xss_payload='{"token": "<script>alert(\"xss\")</script>", "signature": "test", "timestamp": 1640995200}'
    local response=$(curl -s -w "%{http_code}" -X POST -H "Content-Type: application/json" -d "$xss_payload" "http://localhost:8082/api/v1/verify-token")
    local status_code="${response: -3}"
    
    # 应该正常处理，不应该返回500错误
    if [ "$status_code" != "500" ]; then
        return 0
    else
        echo "XSS防护测试失败，服务器返回500错误"
        return 1
    fi
}

run_test "XSS防护" "test_xss_protection"

echo ""
echo "📈 6. 监控和日志测试"

# 检查Prometheus指标
test_prometheus_metrics() {
    echo "测试Prometheus指标收集..."
    
    local response=$(curl -s "http://localhost:9090/api/v1/query?query=up")
    
    if echo "$response" | grep -q '"status":"success"'; then
        return 0
    else
        echo "Prometheus指标查询失败: $response"
        return 1
    fi
}

run_test "Prometheus指标" "test_prometheus_metrics"

# 检查Grafana连接
test_grafana_connection() {
    echo "测试Grafana连接..."
    
    local response=$(curl -s -w "%{http_code}" "http://localhost:3000/api/health")
    local status_code="${response: -3}"
    
    if [ "$status_code" = "200" ]; then
        return 0
    else
        echo "Grafana连接失败，状态码: $status_code"
        return 1
    fi
}

run_test "Grafana连接" "test_grafana_connection"

echo ""
echo "🎯 测试结果摘要"
echo "=================================="
echo -e "总测试数: ${BLUE}$TOTAL_TESTS${NC}"
echo -e "通过测试: ${GREEN}$PASSED_TESTS${NC}"
echo -e "失败测试: ${RED}$FAILED_TESTS${NC}"
echo -e "成功率: ${YELLOW}$(( PASSED_TESTS * 100 / TOTAL_TESTS ))%${NC}"
echo "=================================="

if [ $FAILED_TESTS -eq 0 ]; then
    echo -e "${GREEN}🎉 所有集成测试通过！${NC}"
    exit 0
else
    echo -e "${RED}❌ 有 $FAILED_TESTS 个测试失败${NC}"
    exit 1
fi