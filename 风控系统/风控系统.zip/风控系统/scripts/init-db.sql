-- 初始化数据库脚本

-- 创建扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- 创建流量事件表
CREATE TABLE IF NOT EXISTS traffic_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    client_ip INET NOT NULL,
    user_agent TEXT,
    ja3_fingerprint VARCHAR(32),
    asn VARCHAR(20),
    request_path TEXT NOT NULL,
    request_method VARCHAR(10) NOT NULL,
    headers JSONB,
    features JSONB,
    threat_score DECIMAL(3,2),
    threat_categories TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建威胁评分表
CREATE TABLE IF NOT EXISTS threat_scores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id UUID REFERENCES traffic_events(id),
    score DECIMAL(3,2) NOT NULL,
    confidence DECIMAL(3,2) NOT NULL,
    categories TEXT[] NOT NULL,
    features JSONB,
    model_version VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建策略决策表
CREATE TABLE IF NOT EXISTS policy_decisions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id VARCHAR(100) NOT NULL,
    threat_score_id UUID REFERENCES threat_scores(id),
    action VARCHAR(50) NOT NULL,
    parameters JSONB,
    reason TEXT,
    ttl INTEGER,
    executed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建反爬虫会话表
CREATE TABLE IF NOT EXISTS anti_crawler_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_token VARCHAR(255) UNIQUE NOT NULL,
    client_ip INET NOT NULL,
    user_agent TEXT,
    fingerprint VARCHAR(64),
    challenge_passed BOOLEAN DEFAULT FALSE,
    behavior_score DECIMAL(3,2),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建蜜罐访问日志表
CREATE TABLE IF NOT EXISTS honeypot_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_ip INET NOT NULL,
    user_agent TEXT,
    request_path TEXT NOT NULL,
    request_method VARCHAR(10) NOT NULL,
    headers JSONB,
    payload TEXT,
    response_code INTEGER,
    attack_type VARCHAR(50),
    severity VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建规则配置表
CREATE TABLE IF NOT EXISTS policy_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    conditions JSONB NOT NULL,
    actions JSONB NOT NULL,
    priority INTEGER DEFAULT 0,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建模型配置表
CREATE TABLE IF NOT EXISTS ml_models (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    version VARCHAR(50) NOT NULL,
    model_type VARCHAR(50) NOT NULL,
    file_path TEXT NOT NULL,
    metrics JSONB,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(name, version)
);

-- 创建系统配置表
CREATE TABLE IF NOT EXISTS system_config (
    key VARCHAR(100) PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_traffic_events_timestamp ON traffic_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_traffic_events_client_ip ON traffic_events(client_ip);
CREATE INDEX IF NOT EXISTS idx_traffic_events_threat_score ON traffic_events(threat_score);
CREATE INDEX IF NOT EXISTS idx_threat_scores_score ON threat_scores(score);
CREATE INDEX IF NOT EXISTS idx_policy_decisions_action ON policy_decisions(action);
CREATE INDEX IF NOT EXISTS idx_honeypot_logs_client_ip ON honeypot_logs(client_ip);
CREATE INDEX IF NOT EXISTS idx_honeypot_logs_timestamp ON honeypot_logs(created_at);

-- 插入默认配置
INSERT INTO system_config (key, value, description) VALUES
('rate_limit_default', '{"requests_per_minute": 100, "burst": 20}', '默认速率限制配置'),
('threat_threshold', '{"high": 0.8, "medium": 0.5, "low": 0.2}', '威胁评分阈值'),
('model_config', '{"default_model": "xgboost_v1", "inference_timeout": 100}', '模型推理配置'),
('honeypot_config', '{"enabled_endpoints": ["/api/users", "/api/admin", "/api/data"], "response_delay": 500}', '蜜罐配置')
ON CONFLICT (key) DO NOTHING;

-- 插入默认规则
INSERT INTO policy_rules (name, description, conditions, actions, priority) VALUES
('high_threat_block', '高威胁评分阻断', 
 '{"threat_score": {"gte": 0.8}}', 
 '{"action": "block", "duration": 3600}', 
 100),
('medium_threat_challenge', '中等威胁评分挑战', 
 '{"threat_score": {"gte": 0.5, "lt": 0.8}}', 
 '{"action": "challenge", "type": "captcha"}', 
 50),
('suspicious_asn_limit', '可疑ASN限流', 
 '{"asn": {"in": ["AS12345", "AS67890"]}}', 
 '{"action": "rate_limit", "requests_per_minute": 10}', 
 75)
ON CONFLICT (name) DO NOTHING;

-- 创建视图
CREATE OR REPLACE VIEW threat_summary AS
SELECT 
    DATE_TRUNC('hour', created_at) as hour,
    COUNT(*) as total_events,
    AVG(threat_score) as avg_threat_score,
    COUNT(CASE WHEN threat_score >= 0.8 THEN 1 END) as high_threat_count,
    COUNT(CASE WHEN threat_score >= 0.5 AND threat_score < 0.8 THEN 1 END) as medium_threat_count,
    COUNT(CASE WHEN threat_score < 0.5 THEN 1 END) as low_threat_count
FROM traffic_events 
WHERE threat_score IS NOT NULL
GROUP BY DATE_TRUNC('hour', created_at)
ORDER BY hour DESC;

-- 创建函数
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 创建触发器
CREATE TRIGGER update_policy_rules_updated_at 
    BEFORE UPDATE ON policy_rules 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_system_config_updated_at 
    BEFORE UPDATE ON system_config 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();