# 集成测试脚本 (PowerShell 版本)

param(
    [switch]$Verbose
)

Write-Host "🧪 开始运行集成测试..." -ForegroundColor Cyan

# 测试计数器
$script:TotalTests = 0
$script:PassedTests = 0
$script:FailedTests = 0

# 测试函数
function Invoke-Test {
    param(
        [string]$TestName,
        [scriptblock]$TestCommand
    )
    
    Write-Host "运行测试: $TestName" -ForegroundColor Blue
    $script:TotalTests++
    
    try {
        $result = & $TestCommand
        if ($result) {
            Write-Host "✓ $TestName 通过" -ForegroundColor Green
            $script:PassedTests++
            return $true
        } else {
            Write-Host "✗ $TestName 失败" -ForegroundColor Red
            $script:FailedTests++
            return $false
        }
    } catch {
        Write-Host "✗ $TestName 失败: $($_.Exception.Message)" -ForegroundColor Red
        $script:FailedTests++
        return $false
    }
}

# API测试函数
function Test-Api {
    param(
        [string]$Name,
        [string]$Method = "GET",
        [string]$Url,
        [int]$ExpectedStatus = 200,
        [string]$Body = $null
    )
    
    try {
        $headers = @{"Content-Type" = "application/json"}
        
        if ($Method -eq "POST" -and $Body) {
            $response = Invoke-WebRequest -Uri $Url -Method POST -Body $Body -Headers $headers -TimeoutSec 10 -UseBasicParsing
        } else {
            $response = Invoke-WebRequest -Uri $Url -Method $Method -TimeoutSec 10 -UseBasicParsing
        }
        
        return $response.StatusCode -eq $ExpectedStatus
    } catch {
        if ($Verbose) {
            Write-Host "API测试失败: $($_.Exception.Message)" -ForegroundColor Yellow
        }
        return $false
    }
}

Write-Host "📋 等待服务启动完成..."
Start-Sleep -Seconds 10

Write-Host "`n🔍 1. 基础健康检查测试"
Invoke-Test "边缘网关健康检查" { Test-Api -Name "边缘网关" -Url "http://localhost:8080/health" }
Invoke-Test "策略引擎健康检查" { Test-Api -Name "策略引擎" -Url "http://localhost:8081/api/v1/health" }
Invoke-Test "反爬服务健康检查" { Test-Api -Name "反爬服务" -Url "http://localhost:8082/api/v1/health" }
Invoke-Test "ML推理服务健康检查" { Test-Api -Name "ML推理服务" -Url "http://localhost:8084/health" }
Invoke-Test "蜜罐服务健康检查" { Test-Api -Name "蜜罐服务" -Url "http://localhost:8086/health" }

Write-Host "`n🔗 2. 服务间通信测试"

# 策略决策API测试
$policyPayload = @{
    threat_score = 0.8
    client_info = @{
        ip = "192.168.1.100"
        user_agent = "test-agent"
        ja3 = "test-ja3"
    }
} | ConvertTo-Json -Depth 3

Invoke-Test "策略决策API" { 
    Test-Api -Name "策略决策" -Method "POST" -Url "http://localhost:8081/api/v1/policy/decide" -Body $policyPayload 
}

# Token验证API测试
$tokenPayload = @{
    token = "test-token"
    signature = "test-signature"
    timestamp = 1640995200
} | ConvertTo-Json

Invoke-Test "Token验证API" { 
    Test-Api -Name "Token验证" -Method "POST" -Url "http://localhost:8082/api/v1/verify-token" -Body $tokenPayload 
}

# ML推理API测试
$inferencePayload = @{
    features = @(0.1, 0.2, 0.3, 0.4)
    model_version = "v1.0"
} | ConvertTo-Json

Invoke-Test "ML推理API" { 
    Test-Api -Name "ML推理" -Method "POST" -Url "http://localhost:8084/api/v1/inference" -Body $inferencePayload 
}

# 蜜罐API测试
Invoke-Test "蜜罐用户API" { Test-Api -Name "蜜罐用户" -Url "http://localhost:8086/api/users" }
Invoke-Test "蜜罐管理API" { Test-Api -Name "蜜罐管理" -Url "http://localhost:8086/api/admin" }

Write-Host "`n📊 3. 数据流测试"

# 测试完整的威胁检测流程
Invoke-Test "威胁检测流程" {
    try {
        $highThreatPayload = @{
            threat_score = 0.9
            client_info = @{
                ip = "192.168.1.200"
                user_agent = "suspicious-bot"
            }
        } | ConvertTo-Json -Depth 2
        
        $response = Invoke-RestMethod -Uri "http://localhost:8081/api/v1/policy/decide" -Method POST -Body $highThreatPayload -ContentType "application/json" -TimeoutSec 10
        
        return $response.action -eq "block"
    } catch {
        return $false
    }
}

# 测试反爬虫流程
Invoke-Test "反爬虫流程" {
    try {
        $urlPayload = @{
            resource = "/api/data"
            expires_in = 3600
        } | ConvertTo-Json
        
        $response = Invoke-RestMethod -Uri "http://localhost:8082/api/v1/generate-signed-url" -Method POST -Body $urlPayload -ContentType "application/json" -TimeoutSec 10
        
        return $response.signed_url -ne $null
    } catch {
        return $false
    }
}

Write-Host "`n⚡ 4. 性能测试"

# 并发请求测试
Invoke-Test "并发请求处理" {
    $jobs = @()
    $totalRequests = 10
    
    # 并发发送请求
    for ($i = 1; $i -le $totalRequests; $i++) {
        $job = Start-Job -ScriptBlock {
            try {
                $response = Invoke-WebRequest -Uri "http://localhost:8081/api/v1/health" -TimeoutSec 10 -UseBasicParsing
                return $response.StatusCode -eq 200
            } catch {
                return $false
            }
        }
        $jobs += $job
    }
    
    # 等待所有任务完成
    $results = $jobs | Wait-Job | Receive-Job
    $jobs | Remove-Job
    
    $successCount = ($results | Where-Object { $_ -eq $true }).Count
    Write-Host "并发请求成功率: $successCount/$totalRequests"
    
    # 成功率大于80%认为通过
    return $successCount -ge 8
}

Write-Host "`n🔒 5. 安全测试"

# SQL注入测试
Invoke-Test "SQL注入防护" {
    try {
        $maliciousPayload = @{
            threat_score = 0.5
            client_info = @{
                ip = "192.168.1.1`"; DROP TABLE users; --"
                user_agent = "test"
            }
        } | ConvertTo-Json -Depth 2
        
        $response = Invoke-WebRequest -Uri "http://localhost:8081/api/v1/policy/decide" -Method POST -Body $maliciousPayload -ContentType "application/json" -TimeoutSec 10 -UseBasicParsing
        
        # 应该返回200或400，不应该返回500
        return $response.StatusCode -ne 500
    } catch {
        $statusCode = if ($_.Exception.Response) { $_.Exception.Response.StatusCode.value__ } else { 0 }
        return $statusCode -ne 500
    }
}

# XSS测试
Invoke-Test "XSS防护" {
    try {
        $xssPayload = @{
            token = "<script>alert(`"xss`")</script>"
            signature = "test"
            timestamp = 1640995200
        } | ConvertTo-Json
        
        $response = Invoke-WebRequest -Uri "http://localhost:8082/api/v1/verify-token" -Method POST -Body $xssPayload -ContentType "application/json" -TimeoutSec 10 -UseBasicParsing
        
        # 应该正常处理，不应该返回500错误
        return $response.StatusCode -ne 500
    } catch {
        $statusCode = if ($_.Exception.Response) { $_.Exception.Response.StatusCode.value__ } else { 0 }
        return $statusCode -ne 500
    }
}

Write-Host "`n📈 6. 监控和日志测试"

# 检查Prometheus指标
Invoke-Test "Prometheus指标" {
    try {
        $response = Invoke-RestMethod -Uri "http://localhost:9090/api/v1/query?query=up" -TimeoutSec 10
        return $response.status -eq "success"
    } catch {
        return $false
    }
}

# 检查Grafana连接
Invoke-Test "Grafana连接" {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:3000/api/health" -TimeoutSec 10 -UseBasicParsing
        return $response.StatusCode -eq 200
    } catch {
        return $false
    }
}

Write-Host "`n🎯 测试结果摘要"
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "总测试数: $($script:TotalTests)" -ForegroundColor Blue
Write-Host "通过测试: $($script:PassedTests)" -ForegroundColor Green
Write-Host "失败测试: $($script:FailedTests)" -ForegroundColor Red
$successRate = if ($script:TotalTests -gt 0) { [math]::Round(($script:PassedTests * 100 / $script:TotalTests), 2) } else { 0 }
Write-Host "成功率: $successRate%" -ForegroundColor Yellow
Write-Host "==================================" -ForegroundColor Cyan

if ($script:FailedTests -eq 0) {
    Write-Host "🎉 所有集成测试通过！" -ForegroundColor Green
    exit 0
} else {
    Write-Host "❌ 有 $($script:FailedTests) 个测试失败" -ForegroundColor Red
    exit 1
}