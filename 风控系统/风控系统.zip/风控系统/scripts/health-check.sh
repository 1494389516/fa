#!/bin/bash

# Health check script for malicious traffic control system

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Service endpoints
SERVICES=(
    "ml-inference:8084/api/v1/health"
    "stream-processor:8083/actuator/health"
    "ml-training:8085/api/v1/health"
    "admin-panel:3001"
    "prometheus:9090/-/healthy"
    "grafana:3000/api/health"
)

echo -e "${BLUE}🏥 Health Check - Malicious Traffic Control System${NC}"
echo "================================================"

# Function to check service health
check_service() {
    local service=$1
    local url="http://$service"
    
    echo -n "Checking $service... "
    
    # Try to connect with timeout
    if timeout 10 curl -s -f "$url" > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Healthy${NC}"
        return 0
    else
        echo -e "${RED}❌ Unhealthy${NC}"
        return 1
    fi
}

# Check Docker containers first
echo -e "${BLUE}📦 Checking Docker containers...${NC}"
if command -v docker &> /dev/null; then
    docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
    echo ""
else
    echo -e "${YELLOW}⚠️  Docker not available${NC}"
fi

# Check all services
healthy_count=0
total_count=${#SERVICES[@]}

echo -e "${BLUE}🔍 Checking service endpoints...${NC}"
for service in "${SERVICES[@]}"; do
    if check_service "$service"; then
        ((healthy_count++))
    fi
done

echo ""
echo -e "${BLUE}Health Check Summary:${NC}"
echo "===================="
echo "Healthy services: $healthy_count/$total_count"

if [ $healthy_count -eq $total_count ]; then
    echo -e "${GREEN}🎉 All services are healthy!${NC}"
    exit 0
elif [ $healthy_count -gt $((total_count / 2)) ]; then
    echo -e "${YELLOW}⚠️  Some services are unhealthy, but system is partially operational${NC}"
    exit 1
else
    echo -e "${RED}💥 System is severely degraded${NC}"
    exit 2
fi