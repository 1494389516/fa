#!/bin/bash

# 🔧 代码质量问题修复脚本
# 修复恶意流量控制系统中的代码质量问题

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warn() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

echo -e "${BLUE}"
echo "🔧 代码质量修复脚本"
echo "=================================="
echo "🛡️  恶意流量控制系统"
echo "🚀 修复重复代码和质量问题"
echo -e "${NC}"

# 修复Python配置文件重复定义
fix_python_duplicates() {
    log_info "修复Python配置文件重复定义..."
    
    local config_file="services/ml-training/src/ml_training/config.py"
    
    if [[ -f "$config_file" ]]; then
        # 备份原文件
        cp "$config_file" "$config_file.backup"
        
        # 删除重复的ML_DEBUG行
        awk '!seen[$0]++' "$config_file" > "$config_file.tmp"
        mv "$config_file.tmp" "$config_file"
        
        # 确保只有一个ML_DEBUG定义
        sed -i '/ML_DEBUG.*debug/d' "$config_file"
        sed -i '/ML_LOG_LEVEL.*log_level/a\            "ML_DEBUG": ["debug"],' "$config_file"
        
        log_success "Python配置文件重复定义已修复"
    else
        log_warn "Python配置文件不存在: $config_file"
    fi
}

# 修复JavaScript重复变量声明
fix_javascript_duplicates() {
    log_info "修复JavaScript重复变量声明..."
    
    # 修复load-test.js
    local load_test="tests/performance/load-test.js"
    if [[ -f "$load_test" ]]; then
        cp "$load_test" "$load_test.backup"
        
        # 删除重复的errorRate声明
        sed -i '/const errorRate = new Rate.*error_rate/d' "$load_test"
        sed -i '6i\const errorRate = new Rate("error_rate");' "$load_test"
        
        log_success "load-test.js 重复声明已修复"
    fi
    
    # 修复stress-test.js
    local stress_test="tests/performance/stress-test.js"
    if [[ -f "$stress_test" ]]; then
        cp "$stress_test" "$stress_test.backup"
        
        # 修复重复的errorRate声明
        sed -i '/const errorRate = new Rate.*stress_error_rate/d' "$stress_test"
        sed -i '6i\const stressErrorRate = new Rate("stress_error_rate");' "$stress_test"
        
        # 更新引用
        sed -i 's/errorRate\.add/stressErrorRate.add/g' "$stress_test"
        sed -i 's/stress_error_rate.*rate/stressErrorRate: ["rate<0.05"]/g' "$stress_test"
        
        log_success "stress-test.js 重复声明已修复"
    fi
}

# 修复Java空值检查不一致
fix_java_null_checks() {
    log_info "修复Java空值检查不一致..."
    
    # 查找Java文件
    find services/stream-processor/src -name "*.java" -type f | while read -r java_file; do
        if [[ -f "$java_file" ]]; then
            # 备份文件
            cp "$java_file" "$java_file.backup"
            
            # 统一空值检查模式 - 使用Optional
            sed -i 's/if (\([^)]*\) == null)/if (!Optional.ofNullable(\1).isPresent())/g' "$java_file"
            sed -i 's/if (\([^)]*\) != null)/if (Optional.ofNullable(\1).isPresent())/g' "$java_file"
            
            # 添加Optional导入
            if grep -q "Optional" "$java_file" && ! grep -q "import java.util.Optional" "$java_file"; then
                sed -i '/^import java.util/a import java.util.Optional;' "$java_file"
            fi
        fi
    done
    
    log_success "Java空值检查已统一"
}

# 修复Rust输入验证
fix_rust_validation() {
    log_info "修复Rust输入验证..."
    
    local models_file="services/ml-inference/src/models.rs"
    if [[ -f "$models_file" ]]; then
        cp "$models_file" "$models_file.backup"
        
        # 添加详细的验证规则
        cat >> "$models_file" <<'EOF'

// 自定义验证函数
fn validate_feature_range(features: &[f64]) -> Result<(), validator::ValidationError> {
    for (i, &feature) in features.iter().enumerate() {
        if !feature.is_finite() {
            let mut error = validator::ValidationError::new("feature_not_finite");
            error.add_param(std::borrow::Cow::from("index"), &i);
            return Err(error);
        }
        if feature < -10.0 || feature > 10.0 {
            let mut error = validator::ValidationError::new("feature_out_of_range");
            error.add_param(std::borrow::Cow::from("index"), &i);
            error.add_param(std::borrow::Cow::from("value"), &feature);
            return Err(error);
        }
    }
    Ok(())
}

fn validate_confidence_range(confidence: f64) -> Result<(), validator::ValidationError> {
    if !confidence.is_finite() || confidence < 0.0 || confidence > 1.0 {
        let mut error = validator::ValidationError::new("confidence_out_of_range");
        error.add_param(std::borrow::Cow::from("value"), &confidence);
        return Err(error);
    }
    Ok(())
}
EOF
        
        # 更新结构体定义
        sed -i 's/#\[derive(Debug, Clone, Serialize, Deserialize, Validate)\]/#[derive(Debug, Clone, Serialize, Deserialize, Validate)]/g' "$models_file"
        sed -i '/pub features: Vec<f64>,/i\    #[validate(length(min = 19, max = 19, message = "Features must be exactly 19 dimensions"))]' "$models_file"
        sed -i '/pub features: Vec<f64>,/i\    #[validate(custom = "validate_feature_range")]' "$models_file"
        
        log_success "Rust输入验证已增强"
    fi
}

# 修复内存泄漏风险
fix_memory_leaks() {
    log_info "修复潜在的内存泄漏..."
    
    local aggregation_file="services/stream-processor/src/main/java/com/malicioustraffic/streamprocessor/function/TrafficAggregationFunction.java"
    if [[ -f "$aggregation_file" ]]; then
        cp "$aggregation_file" "$aggregation_file.backup"
        
        # 添加有界集合实现
        cat > /tmp/bounded_collections.java <<'EOF'
// 有界集合实现
private static final int MAX_UNIQUE_PATHS = 1000;
private static final int MAX_UNIQUE_USER_AGENTS = 500;
private static final int MAX_UNIQUE_JA3 = 200;
private static final int MAX_UNIQUE_ASNS = 100;

private Set<String> uniquePaths = new LinkedHashSet<String>() {
    @Override
    protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
        return size() > MAX_UNIQUE_PATHS;
    }
};

private Set<String> uniqueUserAgents = new LinkedHashSet<String>() {
    @Override
    protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
        return size() > MAX_UNIQUE_USER_AGENTS;
    }
};

private Set<String> uniqueJA3 = new LinkedHashSet<String>() {
    @Override
    protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
        return size() > MAX_UNIQUE_JA3;
    }
};

private Set<String> uniqueASNs = new LinkedHashSet<String>() {
    @Override
    protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
        return size() > MAX_UNIQUE_ASNS;
    }
};
EOF
        
        # 替换无界集合定义
        sed -i '/private Set<String> uniquePaths = new HashSet<>();/r /tmp/bounded_collections.java' "$aggregation_file"
        sed -i '/private Set<String> uniquePaths = new HashSet<>();/d' "$aggregation_file"
        sed -i '/private Set<String> uniqueUserAgents = new HashSet<>();/d' "$aggregation_file"
        sed -i '/private Set<String> uniqueJA3 = new HashSet<>();/d' "$aggregation_file"
        sed -i '/private Set<String> uniqueASNs = new HashSet<>();/d' "$aggregation_file"
        
        rm /tmp/bounded_collections.java
        
        log_success "内存泄漏风险已修复"
    fi
}

# 添加数据库连接池配置
add_connection_pool_config() {
    log_info "添加数据库连接池配置..."
    
    local app_config="services/stream-processor/src/main/resources/application.conf"
    if [[ -f "$app_config" ]]; then
        cp "$app_config" "$app_config.backup"
        
        # 添加HikariCP连接池配置
        cat >> "$app_config" <<'EOF'

# 数据库连接池配置
database {
  hikari {
    maximum-pool-size = 20
    maximum-pool-size = ${?DB_MAX_POOL_SIZE}
    
    minimum-idle = 5
    minimum-idle = ${?DB_MIN_IDLE}
    
    connection-timeout = 30000
    connection-timeout = ${?DB_CONNECTION_TIMEOUT}
    
    idle-timeout = 600000
    idle-timeout = ${?DB_IDLE_TIMEOUT}
    
    max-lifetime = 1800000
    max-lifetime = ${?DB_MAX_LIFETIME}
    
    leak-detection-threshold = 60000
    leak-detection-threshold = ${?DB_LEAK_DETECTION_THRESHOLD}
  }
}
EOF
        
        log_success "数据库连接池配置已添加"
    fi
}

# 修复监控配置
fix_monitoring_config() {
    log_info "修复监控配置..."
    
    local prometheus_config="monitoring/prometheus.yml"
    if [[ -f "$prometheus_config" ]]; then
        cp "$prometheus_config" "$prometheus_config.backup"
        
        # 替换硬编码的localhost
        sed -i "s/localhost:9090/\${PROMETHEUS_HOST:-prometheus}:\${PROMETHEUS_PORT:-9090}/g" "$prometheus_config"
        sed -i "s/localhost:/\${TARGET_HOST:-localhost}:/g" "$prometheus_config"
        
        log_success "监控配置已修复"
    fi
}

# 创建代码质量检查脚本
create_quality_check_script() {
    log_info "创建代码质量检查脚本..."
    
    cat > scripts/quality-check.sh <<'EOF'
#!/bin/bash

# 🔍 代码质量检查脚本

echo "🔍 执行代码质量检查..."

# 检查重复代码
echo "1. 检查重复代码..."
if find . -name "*.py" -exec grep -l "ML_DEBUG.*debug" {} \; | xargs grep -c "ML_DEBUG.*debug" | grep -v ":1$"; then
    echo "❌ 发现重复的Python配置"
else
    echo "✅ Python配置无重复"
fi

# 检查JavaScript重复声明
echo "2. 检查JavaScript重复声明..."
if find . -name "*.js" -exec grep -l "const errorRate" {} \; | xargs grep -c "const errorRate" | grep -v ":1$"; then
    echo "❌ 发现重复的JavaScript声明"
else
    echo "✅ JavaScript声明无重复"
fi

# 检查Java空值处理
echo "3. 检查Java空值处理..."
java_null_checks=$(find . -name "*.java" -exec grep -l "== null\|!= null" {} \; | wc -l)
java_optional_checks=$(find . -name "*.java" -exec grep -l "Optional" {} \; | wc -l)

if [[ $java_null_checks -gt $java_optional_checks ]]; then
    echo "⚠️  建议使用Optional替代null检查"
else
    echo "✅ Java空值处理良好"
fi

# 检查内存泄漏风险
echo "4. 检查内存泄漏风险..."
if grep -r "new HashSet<>()" services/ --include="*.java" | grep -v ".backup"; then
    echo "⚠️  发现无界集合，可能存在内存泄漏风险"
else
    echo "✅ 未发现明显的内存泄漏风险"
fi

# 检查硬编码配置
echo "5. 检查硬编码配置..."
if grep -r "localhost" monitoring/ --include="*.yml" | grep -v "\${" | grep -v ".backup"; then
    echo "❌ 发现硬编码的localhost配置"
else
    echo "✅ 监控配置使用环境变量"
fi

echo "🔍 代码质量检查完成"
EOF

    chmod +x scripts/quality-check.sh
    log_success "代码质量检查脚本创建完成"
}

# 创建代码格式化脚本
create_format_script() {
    log_info "创建代码格式化脚本..."
    
    cat > scripts/format-code.sh <<'EOF'
#!/bin/bash

# 🎨 代码格式化脚本

echo "🎨 执行代码格式化..."

# 格式化Python代码
if command -v black >/dev/null 2>&1; then
    echo "格式化Python代码..."
    find services/ml-training -name "*.py" -exec black {} \;
    echo "✅ Python代码格式化完成"
else
    echo "⚠️  未安装black，跳过Python格式化"
fi

# 格式化Java代码
if command -v google-java-format >/dev/null 2>&1; then
    echo "格式化Java代码..."
    find services/stream-processor -name "*.java" -exec google-java-format -i {} \;
    echo "✅ Java代码格式化完成"
else
    echo "⚠️  未安装google-java-format，跳过Java格式化"
fi

# 格式化Rust代码
if command -v rustfmt >/dev/null 2>&1; then
    echo "格式化Rust代码..."
    find services/ml-inference -name "*.rs" -exec rustfmt {} \;
    echo "✅ Rust代码格式化完成"
else
    echo "⚠️  未安装rustfmt，跳过Rust格式化"
fi

# 格式化JavaScript代码
if command -v prettier >/dev/null 2>&1; then
    echo "格式化JavaScript代码..."
    find tests -name "*.js" -exec prettier --write {} \;
    echo "✅ JavaScript代码格式化完成"
else
    echo "⚠️  未安装prettier，跳过JavaScript格式化"
fi

echo "🎨 代码格式化完成"
EOF

    chmod +x scripts/format-code.sh
    log_success "代码格式化脚本创建完成"
}

# 显示修复结果
show_results() {
    echo -e "\n${GREEN}🎉 代码质量问题修复完成！${NC}"
    echo ""
    echo -e "${BLUE}📋 修复内容:${NC}"
    echo "  ✅ 修复了Python配置重复定义"
    echo "  ✅ 修复了JavaScript重复变量声明"
    echo "  ✅ 统一了Java空值检查模式"
    echo "  ✅ 增强了Rust输入验证"
    echo "  ✅ 修复了潜在内存泄漏"
    echo "  ✅ 添加了数据库连接池配置"
    echo "  ✅ 修复了监控配置"
    echo "  ✅ 创建了质量检查脚本"
    echo "  ✅ 创建了代码格式化脚本"
    
    echo ""
    echo -e "${YELLOW}⚠️  重要提醒:${NC}"
    echo "  📁 备份文件已创建 (*.backup)"
    echo "  🧪 建议运行测试验证修复效果"
    echo "  🔄 重新编译和部署服务"
    
    echo ""
    echo -e "${BLUE}🚀 下一步操作:${NC}"
    echo "  1. 运行质量检查: ./scripts/quality-check.sh"
    echo "  2. 格式化代码: ./scripts/format-code.sh"
    echo "  3. 运行测试: make test"
    echo "  4. 重新构建: docker-compose build"
    
    echo ""
    echo -e "${GREEN}📊 质量提升:${NC}"
    echo "  🔧 代码一致性提升"
    echo "  🛡️  内存安全增强"
    echo "  📈 性能优化"
    echo "  🧪 可测试性改善"
}

# 主函数
main() {
    fix_python_duplicates
    fix_javascript_duplicates
    fix_java_null_checks
    fix_rust_validation
    fix_memory_leaks
    add_connection_pool_config
    fix_monitoring_config
    create_quality_check_script
    create_format_script
    show_results
}

# 处理命令行参数
case "${1:-}" in
    --check)
        if [[ -f "scripts/quality-check.sh" ]]; then
            ./scripts/quality-check.sh
        else
            log_error "质量检查脚本不存在，请先运行主修复流程"
        fi
        ;;
    --format)
        if [[ -f "scripts/format-code.sh" ]]; then
            ./scripts/format-code.sh
        else
            log_error "格式化脚本不存在，请先运行主修复流程"
        fi
        ;;
    --help|-h)
        echo "🔧 代码质量修复脚本使用说明"
        echo "========================"
        echo ""
        echo "用法: $0 [选项]"
        echo ""
        echo "选项:"
        echo "  --check       运行质量检查"
        echo "  --format      格式化代码"
        echo "  --help        显示帮助信息"
        echo ""
        echo "示例:"
        echo "  $0                    # 执行完整修复"
        echo "  $0 --check           # 质量检查"
        echo "  $0 --format          # 格式化代码"
        ;;
    *)
        main
        ;;
esac