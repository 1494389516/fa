#!/bin/bash

# 🔐 安全问题修复脚本
# 修复恶意流量控制系统中的安全配置问题

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warn() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

echo -e "${BLUE}"
echo "🔐 安全问题修复脚本"
echo "=================================="
echo "🛡️  恶意流量控制系统"
echo "🚀 修复硬编码密码和安全配置"
echo -e "${NC}"

# 检查必要工具
check_dependencies() {
    log_info "检查必要工具..."
    
    if ! command -v openssl >/dev/null 2>&1; then
        log_error "需要安装 openssl"
        exit 1
    fi
    
    if ! command -v sed >/dev/null 2>&1; then
        log_error "需要安装 sed"
        exit 1
    fi
    
    log_success "依赖检查完成"
}

# 生成安全密码
generate_passwords() {
    log_info "生成安全密码..."
    
    # 生成强密码
    POSTGRES_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    GRAFANA_PASSWORD=$(openssl rand -base64 16 | tr -d "=+/" | cut -c1-12)
    JWT_SECRET=$(openssl rand -base64 64 | tr -d "=+/")
    ENCRYPTION_KEY=$(openssl rand -base64 32 | tr -d "=+/")
    REDIS_PASSWORD=$(openssl rand -base64 16 | tr -d "=+/" | cut -c1-12)
    
    log_success "安全密码生成完成"
}

# 创建环境变量文件
create_env_files() {
    log_info "创建环境变量文件..."
    
    # 生产环境配置
    cat > .env.production <<EOF
# 🔐 生产环境安全配置
# 生成时间: $(date)
# ⚠️  请妥善保管此文件，不要提交到版本控制

# 数据库配置
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
POSTGRES_USER=malicious_traffic_user

# 缓存配置
REDIS_PASSWORD=$REDIS_PASSWORD

# 监控配置
GRAFANA_ADMIN_PASSWORD=$GRAFANA_PASSWORD
GRAFANA_ADMIN_USER=admin

# 应用安全配置
JWT_SECRET=$JWT_SECRET
ENCRYPTION_KEY=$ENCRYPTION_KEY
SESSION_SECRET=$(openssl rand -base64 32 | tr -d "=+/")

# API密钥
API_KEY=$(openssl rand -base64 24 | tr -d "=+/")
WEBHOOK_SECRET=$(openssl rand -base64 16 | tr -d "=+/")

# 外部服务配置
SMTP_PASSWORD=\${SMTP_PASSWORD:-}
SLACK_WEBHOOK_URL=\${SLACK_WEBHOOK_URL:-}
EOF

    # 开发环境配置
    cat > .env.development <<EOF
# 🔧 开发环境配置
# 生成时间: $(date)

# 数据库配置
POSTGRES_PASSWORD=dev_password_$(openssl rand -base64 8 | tr -d "=+/" | cut -c1-6)
POSTGRES_USER=dev_user

# 缓存配置
REDIS_PASSWORD=dev_redis_$(openssl rand -base64 8 | tr -d "=+/" | cut -c1-6)

# 监控配置
GRAFANA_ADMIN_PASSWORD=dev_admin_$(openssl rand -base64 8 | tr -d "=+/" | cut -c1-6)
GRAFANA_ADMIN_USER=dev_admin

# 应用安全配置
JWT_SECRET=$(openssl rand -base64 32 | tr -d "=+/")
ENCRYPTION_KEY=$(openssl rand -base64 16 | tr -d "=+/")
SESSION_SECRET=$(openssl rand -base64 16 | tr -d "=+/")

# 开发调试
DEBUG=true
LOG_LEVEL=debug
EOF

    # 测试环境配置
    cat > .env.test <<EOF
# 🧪 测试环境配置
# 生成时间: $(date)

# 数据库配置
POSTGRES_PASSWORD=test_password
POSTGRES_USER=test_user

# 缓存配置
REDIS_PASSWORD=test_redis

# 监控配置
GRAFANA_ADMIN_PASSWORD=test_admin
GRAFANA_ADMIN_USER=test_admin

# 应用安全配置
JWT_SECRET=test_jwt_secret_for_testing_only
ENCRYPTION_KEY=test_encryption_key
SESSION_SECRET=test_session_secret

# 测试配置
TEST_MODE=true
LOG_LEVEL=warn
EOF

    log_success "环境变量文件创建完成"
}

# 更新Docker配置
update_docker_configs() {
    log_info "更新Docker配置文件..."
    
    # 备份原文件
    cp docker-compose.yml docker-compose.yml.backup
    cp docker-compose.dev.yml docker-compose.dev.yml.backup
    cp docker-compose.test.yml docker-compose.test.yml.backup
    
    # 更新生产环境配置
    sed -i 's/POSTGRES_PASSWORD: password/POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}/' docker-compose.yml
    sed -i 's/POSTGRES_USER: admin/POSTGRES_USER: ${POSTGRES_USER:-malicious_traffic_user}/' docker-compose.yml
    sed -i 's/GF_SECURITY_ADMIN_PASSWORD: admin/GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_ADMIN_PASSWORD}/' docker-compose.yml
    sed -i 's/GF_SECURITY_ADMIN_USER: admin/GF_SECURITY_ADMIN_USER: ${GRAFANA_ADMIN_USER:-admin}/' docker-compose.yml
    
    # 添加Redis密码
    sed -i '/redis:/a\    command: redis-server --requirepass ${REDIS_PASSWORD}' docker-compose.yml
    
    # 更新开发环境配置
    sed -i 's/POSTGRES_PASSWORD: dev_password/POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}/' docker-compose.dev.yml
    sed -i 's/POSTGRES_USER: dev_user/POSTGRES_USER: ${POSTGRES_USER:-dev_user}/' docker-compose.dev.yml
    
    # 更新测试环境配置
    sed -i 's/POSTGRES_PASSWORD: test_password/POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}/' docker-compose.test.yml
    sed -i 's/POSTGRES_USER: test_user/POSTGRES_USER: ${POSTGRES_USER:-test_user}/' docker-compose.test.yml
    
    log_success "Docker配置更新完成"
}

# 更新应用配置
update_app_configs() {
    log_info "更新应用配置文件..."
    
    # 更新Stream Processor配置
    if [[ -f "services/stream-processor/src/main/resources/application.conf" ]]; then
        cp "services/stream-processor/src/main/resources/application.conf" "services/stream-processor/src/main/resources/application.conf.backup"
        
        sed -i 's/password = "password"/password = ${?POSTGRES_PASSWORD}/' "services/stream-processor/src/main/resources/application.conf"
        sed -i 's/username = "admin"/username = ${?POSTGRES_USER}/' "services/stream-processor/src/main/resources/application.conf"
    fi
    
    # 更新Nginx配置
    if [[ -f "services/edge-gateway/conf/default.conf" ]]; then
        cp "services/edge-gateway/conf/default.conf" "services/edge-gateway/conf/default.conf.backup"
        
        # 添加HTTPS重定向
        cat >> "services/edge-gateway/conf/default.conf" <<EOF

# HTTPS重定向配置
server {
    listen 80;
    server_name \$host;
    return 301 https://\$server_name\$request_uri;
}

# 安全头配置
add_header X-Frame-Options DENY;
add_header X-Content-Type-Options nosniff;
add_header X-XSS-Protection "1; mode=block";
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
EOF
    fi
    
    log_success "应用配置更新完成"
}

# 创建安全配置文档
create_security_docs() {
    log_info "创建安全配置文档..."
    
    mkdir -p docs/security
    
    cat > docs/security/password-policy.md <<EOF
# 🔐 密码安全策略

## 密码要求

### 生产环境
- 最小长度: 25字符
- 包含大小写字母、数字和特殊字符
- 定期轮换 (建议90天)
- 使用密钥管理系统存储

### 开发环境
- 最小长度: 12字符
- 不得使用生产环境密码
- 定期更新

### 测试环境
- 使用固定测试密码
- 不得包含敏感信息

## 密钥管理

### 环境变量
- 生产: 使用 .env.production
- 开发: 使用 .env.development  
- 测试: 使用 .env.test

### 密钥轮换
\`\`\`bash
# 重新生成密码
./scripts/fix-security-issues.sh --regenerate

# 更新生产环境
docker-compose --env-file .env.production up -d
\`\`\`

## 安全检查清单

- [ ] 所有默认密码已更改
- [ ] 环境变量文件权限正确 (600)
- [ ] 密钥未提交到版本控制
- [ ] 启用HTTPS访问
- [ ] 配置防火墙规则
- [ ] 启用审计日志
EOF

    cat > docs/security/deployment-security.md <<EOF
# 🛡️ 部署安全指南

## 生产环境部署

### 1. 环境准备
\`\`\`bash
# 设置文件权限
chmod 600 .env.production
chown root:root .env.production

# 创建专用用户
useradd -r -s /bin/false malicious-traffic
\`\`\`

### 2. 网络安全
\`\`\`bash
# 防火墙配置
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP (重定向到HTTPS)
ufw allow 443/tcp   # HTTPS
ufw deny 3000/tcp   # 禁止直接访问管理面板
ufw enable
\`\`\`

### 3. SSL/TLS配置
\`\`\`bash
# 使用Let's Encrypt
certbot --nginx -d your-domain.com
\`\`\`

### 4. 监控和告警
- 启用失败登录告警
- 监控异常访问模式
- 配置日志聚合

## 安全检查脚本
\`\`\`bash
# 运行安全检查
./scripts/security-check.sh
\`\`\`
EOF

    log_success "安全文档创建完成"
}

# 设置文件权限
set_file_permissions() {
    log_info "设置安全文件权限..."
    
    # 设置环境变量文件权限
    chmod 600 .env.* 2>/dev/null || true
    
    # 设置脚本执行权限
    chmod +x scripts/*.sh 2>/dev/null || true
    
    # 设置配置文件权限
    find . -name "*.conf" -type f -exec chmod 644 {} \; 2>/dev/null || true
    
    log_success "文件权限设置完成"
}

# 创建安全检查脚本
create_security_check_script() {
    log_info "创建安全检查脚本..."
    
    cat > scripts/security-check.sh <<'EOF'
#!/bin/bash

# 🔍 安全检查脚本

echo "🔍 执行安全检查..."

# 检查硬编码密码
echo "1. 检查硬编码密码..."
if grep -r "password.*=" . --include="*.yml" --include="*.yaml" --include="*.conf" | grep -v "\${" | grep -v ".backup"; then
    echo "❌ 发现硬编码密码"
else
    echo "✅ 未发现硬编码密码"
fi

# 检查默认用户名
echo "2. 检查默认用户名..."
if grep -r "admin.*admin" . --include="*.yml" --include="*.yaml" | grep -v "\${" | grep -v ".backup"; then
    echo "❌ 发现默认用户名"
else
    echo "✅ 未发现默认用户名"
fi

# 检查文件权限
echo "3. 检查敏感文件权限..."
for file in .env.*; do
    if [[ -f "$file" ]]; then
        perm=$(stat -c "%a" "$file" 2>/dev/null || stat -f "%A" "$file" 2>/dev/null)
        if [[ "$perm" != "600" ]]; then
            echo "❌ $file 权限不安全: $perm"
        else
            echo "✅ $file 权限正确"
        fi
    fi
done

# 检查SSL配置
echo "4. 检查SSL配置..."
if grep -r "ssl_certificate" services/edge-gateway/conf/ 2>/dev/null; then
    echo "✅ 发现SSL配置"
else
    echo "⚠️  未配置SSL证书"
fi

echo "🔍 安全检查完成"
EOF

    chmod +x scripts/security-check.sh
    log_success "安全检查脚本创建完成"
}

# 显示修复结果
show_results() {
    echo -e "\n${GREEN}🎉 安全问题修复完成！${NC}"
    echo ""
    echo -e "${BLUE}📋 修复内容:${NC}"
    echo "  ✅ 生成了强密码和密钥"
    echo "  ✅ 创建了环境变量文件"
    echo "  ✅ 更新了Docker配置"
    echo "  ✅ 更新了应用配置"
    echo "  ✅ 创建了安全文档"
    echo "  ✅ 设置了文件权限"
    echo "  ✅ 创建了安全检查脚本"
    
    echo ""
    echo -e "${YELLOW}⚠️  重要提醒:${NC}"
    echo "  🔐 环境变量文件已创建，请妥善保管"
    echo "  📁 备份文件已创建 (*.backup)"
    echo "  🚫 不要将 .env.* 文件提交到版本控制"
    echo "  🔄 重新部署服务以应用新配置"
    
    echo ""
    echo -e "${BLUE}🚀 下一步操作:${NC}"
    echo "  1. 检查生成的密码: cat .env.production"
    echo "  2. 运行安全检查: ./scripts/security-check.sh"
    echo "  3. 重新部署服务: docker-compose --env-file .env.production up -d"
    echo "  4. 配置SSL证书: certbot --nginx -d your-domain.com"
    
    echo ""
    echo -e "${GREEN}📖 相关文档:${NC}"
    echo "  📋 密码策略: docs/security/password-policy.md"
    echo "  🛡️  部署安全: docs/security/deployment-security.md"
}

# 主函数
main() {
    check_dependencies
    generate_passwords
    create_env_files
    update_docker_configs
    update_app_configs
    create_security_docs
    set_file_permissions
    create_security_check_script
    show_results
}

# 处理命令行参数
case "${1:-}" in
    --regenerate)
        log_info "重新生成密码..."
        generate_passwords
        create_env_files
        log_success "密码重新生成完成"
        ;;
    --check)
        if [[ -f "scripts/security-check.sh" ]]; then
            ./scripts/security-check.sh
        else
            log_error "安全检查脚本不存在，请先运行主修复流程"
        fi
        ;;
    --help|-h)
        echo "🔐 安全修复脚本使用说明"
        echo "========================"
        echo ""
        echo "用法: $0 [选项]"
        echo ""
        echo "选项:"
        echo "  --regenerate  重新生成密码"
        echo "  --check       运行安全检查"
        echo "  --help        显示帮助信息"
        echo ""
        echo "示例:"
        echo "  $0                    # 执行完整修复"
        echo "  $0 --regenerate      # 重新生成密码"
        echo "  $0 --check           # 安全检查"
        ;;
    *)
        main
        ;;
esac