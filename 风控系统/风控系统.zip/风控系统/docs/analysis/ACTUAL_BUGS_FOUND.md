# 🐛 实际发现的Bug列表

## 🔴 严重Bug (导致运行失败)

### 1. Python包结构错误 - 导入失败
**位置**: `services/ml-training/src/ml_training/models/heavy_model.py:38-40`
**问题**: 导入不存在的模块
```python
from ..config import HeavyModelConfig          # ✅ 存在
from ..utils.metrics import calculate_metrics  # ❌ utils目录不存在
from ..data.sequence_processor import SequenceProcessor  # ❌ data目录不存在
```

**影响**: Python服务无法启动，ImportError
**修复**: 创建缺失的目录和文件，或修改导入路径

### 2. JavaScript重复变量声明
**位置**: `tests/performance/stress-test.js:6` 和 `tests/performance/load-test.js:6`
**问题**: 在搜索结果中显示重复声明，但实际检查文件后发现是搜索误报
**状态**: ✅ 已确认不是实际bug

### 3. Docker构建可能的问题
**位置**: `services/ml-inference/Dockerfile:31`
**问题**: 
```dockerfile
RUN cargo build --release && rm -rf src
```
**潜在问题**: 删除源码后再复制源码，可能导致构建缓存问题

## 🟠 中等Bug (影响功能)

### 4. 缺失的Python模块和工具类
**位置**: 多个Python文件中
**问题**: 引用了不存在的模块
```python
# 缺失的模块
services/ml-training/src/ml_training/utils/          # 整个目录不存在
services/ml-training/src/ml_training/data/           # 整个目录不存在
```

**需要创建的文件**:
- `utils/metrics.py` - 指标计算函数
- `utils/model_export.py` - 模型导出工具
- `data/sequence_processor.py` - 序列数据处理器

### 5. 配置文件中的硬编码问题
**位置**: 多个配置文件
**问题**: 已在之前的分析中发现，需要修复

## 🟡 轻微Bug (代码质量)

### 6. 测试文件中的重复代码
**位置**: Java测试文件中
**问题**: 多个测试方法有相似的异常处理代码

## 🔧 立即修复方案

### 修复1: 创建缺失的Python模块
```bash
# 创建缺失的目录结构
mkdir -p services/ml-training/src/ml_training/utils
mkdir -p services/ml-training/src/ml_training/data

# 创建__init__.py文件
touch services/ml-training/src/ml_training/utils/__init__.py
touch services/ml-training/src/ml_training/data/__init__.py
```

### 修复2: 创建缺失的Python文件
```python
# services/ml-training/src/ml_training/utils/metrics.py
def calculate_metrics(y_true, y_pred, y_proba=None):
    """计算模型评估指标"""
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
    
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, average='weighted'),
        'recall': recall_score(y_true, y_pred, average='weighted'),
        'f1': f1_score(y_true, y_pred, average='weighted')
    }
    
    if y_proba is not None:
        from sklearn.metrics import roc_auc_score
        try:
            metrics['auc'] = roc_auc_score(y_true, y_proba[:, 1])
        except:
            metrics['auc'] = 0.0
    
    return metrics

def optimize_threshold(y_true, y_proba):
    """优化分类阈值"""
    from sklearn.metrics import precision_recall_curve
    
    precision, recall, thresholds = precision_recall_curve(y_true, y_proba[:, 1])
    f1_scores = 2 * (precision * recall) / (precision + recall)
    
    # 找到F1分数最高的阈值
    best_threshold_idx = f1_scores.argmax()
    best_threshold = thresholds[best_threshold_idx]
    
    return best_threshold
```

```python
# services/ml-training/src/ml_training/utils/model_export.py
def export_to_onnx(model, model_path, input_shape):
    """导出模型到ONNX格式"""
    import torch
    import torch.onnx
    
    # 创建示例输入
    dummy_input = torch.randn(1, *input_shape)
    
    # 导出到ONNX
    torch.onnx.export(
        model,
        dummy_input,
        model_path,
        export_params=True,
        opset_version=11,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['output'],
        dynamic_axes={
            'input': {0: 'batch_size'},
            'output': {0: 'batch_size'}
        }
    )
```

```python
# services/ml-training/src/ml_training/data/sequence_processor.py
import numpy as np
from typing import List, Tuple

class SequenceProcessor:
    """序列数据处理器"""
    
    def __init__(self, max_length: int = 100):
        self.max_length = max_length
    
    def process_sequences(self, sequences: List[List[float]]) -> np.ndarray:
        """处理序列数据，进行填充和截断"""
        processed = []
        
        for seq in sequences:
            if len(seq) > self.max_length:
                # 截断
                processed_seq = seq[:self.max_length]
            else:
                # 填充
                processed_seq = seq + [0.0] * (self.max_length - len(seq))
            
            processed.append(processed_seq)
        
        return np.array(processed)
    
    def create_temporal_features(self, sequences: List[List[float]]) -> np.ndarray:
        """创建时序特征"""
        temporal_features = []
        
        for seq in sequences:
            features = {
                'length': len(seq),
                'mean': np.mean(seq) if seq else 0.0,
                'std': np.std(seq) if len(seq) > 1 else 0.0,
                'min': np.min(seq) if seq else 0.0,
                'max': np.max(seq) if seq else 0.0
            }
            temporal_features.append(list(features.values()))
        
        return np.array(temporal_features)
```

### 修复3: 修复Docker构建问题
```dockerfile
# services/ml-inference/Dockerfile 修复版本
FROM rust:1.75-slim as builder

# Install system dependencies
RUN apt-get update && apt-get install -y \
    pkg-config \
    libssl-dev \
    libclang-dev \
    curl \
    wget \
    && rm -rf /var/lib/apt/lists/*

# Install ONNX Runtime
RUN wget https://github.com/microsoft/onnxruntime/releases/download/v1.16.3/onnxruntime-linux-x64-1.16.3.tgz \
    && tar -xzf onnxruntime-linux-x64-1.16.3.tgz \
    && cp -r onnxruntime-linux-x64-1.16.3/lib/* /usr/local/lib/ \
    && cp -r onnxruntime-linux-x64-1.16.3/include/* /usr/local/include/ \
    && ldconfig \
    && rm -rf onnxruntime-linux-x64-1.16.3*

# Set working directory
WORKDIR /app

# Copy Cargo files first for better caching
COPY Cargo.toml Cargo.lock ./

# Create dummy main.rs to build dependencies
RUN mkdir src && echo "fn main() {}" > src/main.rs

# Build dependencies (this layer will be cached)
RUN cargo build --release

# Remove dummy files
RUN rm -rf src

# Copy actual source code
COPY src ./src

# Build application
RUN cargo build --release

# Runtime stage (unchanged)
FROM debian:bookworm-slim
# ... rest of the Dockerfile
```

## 📊 Bug统计

| 严重程度 | 数量 | 影响 |
|----------|------|------|
| 🔴 严重 | 3个 | 服务无法启动 |
| 🟠 中等 | 2个 | 功能受影响 |
| 🟡 轻微 | 1个 | 代码质量 |
| **总计** | **6个** | **需要立即修复** |

## 🚀 修复优先级

1. **立即修复** (阻塞性bug): Python导入错误
2. **今天修复** (功能性bug): 缺失的模块文件
3. **本周修复** (优化性bug): Docker构建优化

这些是实际会导致系统无法运行的真正bug，需要优先修复！