# 🏗️ 项目结构总览

## 📁 目录结构

```
malicious-traffic-control/
├── 📋 项目配置文件
│   ├── README.md                    # 项目说明文档
│   ├── LICENSE                      # MIT许可证
│   ├── .gitignore                   # Git忽略文件
│   ├── Makefile                     # 构建和运维工具
│   ├── docker-compose.yml          # 生产环境容器编排
│   ├── docker-compose.dev.yml      # 开发环境容器编排
│   ├── docker-compose.test.yml     # 测试环境容器编排
│   └── PROJECT_STRUCTURE.md        # 项目结构说明
│
├── 📚 文档目录 (docs/)
│   ├── architecture/                # 架构文档
│   │   ├── complete-system-architecture.md
│   │   └── frontend-security-architecture.md
│   ├── deployment/                  # 部署文档
│   │   └── user-friendly-deployment.md
│   └── solutions/                   # 解决方案文档
│       └── encryption-compatibility.md
│
├── 🤝 社区文件
│   ├── CONTRIBUTING.md              # 贡献指南
│   ├── SECURITY.md                  # 安全政策
│   └── CODE_OF_CONDUCT.md          # 行为准则
│
├── 🔧 脚本目录 (scripts/)
│   ├── easy-deploy.sh              # 一键部署脚本
│   ├── easy-deploy.ps1             # Windows部署脚本
│   ├── health-check.sh             # 健康检查脚本
│   ├── health-check.ps1            # Windows健康检查
│   ├── init-db.sql                 # 数据库初始化
│   └── run-integration-tests.sh    # 集成测试脚本
│
├── 🧪 测试目录 (tests/)
│   └── performance/                 # 性能测试
│       ├── load-test.js            # 负载测试
│       └── stress-test.js          # 压力测试
│
├── 📊 监控配置 (monitoring/)
│   ├── prometheus.yml              # Prometheus配置
│   └── grafana/                    # Grafana配置
│       └── provisioning/
│
├── 🔄 CI/CD配置 (.github/)
│   └── workflows/
│       └── ci.yml                  # GitHub Actions配置
│
├── 🛠️ 开发配置 (.kiro/)
│   └── specs/                      # 项目规格文档
│       └── malicious-traffic-control-system/
│
└── 🚀 服务目录 (services/)
    ├── 🧠 ML推理服务 (ml-inference/)
    │   ├── Cargo.toml              # Rust项目配置
    │   ├── Dockerfile              # 容器构建文件
    │   ├── README.md               # 服务说明
    │   ├── config/                 # 配置文件
    │   │   └── default.toml
    │   ├── src/                    # 源代码
    │   │   ├── main.rs
    │   │   ├── lib.rs
    │   │   ├── config.rs
    │   │   ├── error.rs
    │   │   ├── models.rs
    │   │   ├── metrics.rs
    │   │   ├── handlers.rs
    │   │   ├── server.rs
    │   │   ├── telemetry.rs
    │   │   ├── utils.rs
    │   │   └── inference/          # 推理引擎
    │   │       ├── mod.rs
    │   │       ├── light_engine.rs
    │   │       ├── heavy_engine.rs
    │   │       └── dual_engine.rs
    │   └── tests/                  # 测试文件
    │       └── integration_test.rs
    │
    ├── 🌊 流处理服务 (stream-processor/)
    │   ├── pom.xml                 # Maven配置
    │   ├── Dockerfile              # 容器构建文件
    │   ├── README.md               # 服务说明
    │   ├── scripts/
    │   │   └── start.sh
    │   └── src/                    # Java源代码
    │       ├── main/java/com/malicioustraffic/streamprocessor/
    │       │   ├── StreamProcessorApplication.java
    │       │   ├── config/
    │       │   ├── model/
    │       │   ├── function/
    │       │   ├── job/
    │       │   ├── sink/
    │       │   └── source/
    │       ├── main/resources/
    │       │   └── application.conf
    │       └── test/java/
    │
    ├── 🤖 ML训练服务 (ml-training/)
    │   ├── requirements.txt        # Python依赖
    │   ├── requirements-dev.txt    # 开发依赖
    │   ├── setup.py               # Python包配置
    │   ├── Dockerfile             # 容器构建文件
    │   └── src/ml_training/       # Python源代码
    │       ├── __init__.py
    │       ├── main.py            # 主程序
    │       ├── api.py             # API路由
    │       ├── config.py          # 配置管理
    │       ├── training.py        # 训练管理器
    │       ├── monitoring.py      # 监控模块
    │       └── models/            # 模型定义
    │
    ├── 🛡️ 边缘网关 (edge-gateway/)
    │   ├── Dockerfile             # 容器构建文件
    │   ├── README.md              # 服务说明
    │   ├── conf/                  # Nginx配置
    │   │   ├── nginx.conf
    │   │   └── default.conf
    │   ├── lua/                   # Lua脚本
    │   │   ├── init.lua
    │   │   ├── init_worker.lua
    │   │   ├── threat_detection.lua
    │   │   ├── ja3_fingerprint.lua
    │   │   ├── rate_limit.lua
    │   │   ├── asn_check.lua
    │   │   └── simple_check.lua
    │   ├── scripts/
    │   │   └── start.sh
    │   └── tests/                 # 测试文件
    │       └── unit/
    │
    └── 🌐 管理面板 (web/admin/)
        ├── package.json           # Node.js项目配置
        ├── vite.config.js         # Vite构建配置
        ├── Dockerfile             # 生产环境容器
        ├── Dockerfile.dev         # 开发环境容器
        ├── nginx.conf             # Nginx配置
        └── index.html             # 主页面
```

## 🎯 核心组件说明

### 🧠 ML推理服务 (Rust)
- **功能**: 双模型架构的机器学习推理
- **特性**: 轻模型(1-5ms) + 重模型(10-80ms)
- **技术栈**: Rust + ONNX Runtime + Axum
- **端口**: 8084

### 🌊 流处理服务 (Java)
- **功能**: 实时流量数据处理和分析
- **特性**: Apache Flink + Kafka + PostgreSQL
- **技术栈**: Java + Spring Boot + Flink
- **端口**: 8083

### 🤖 ML训练服务 (Python)
- **功能**: 机器学习模型训练和管理
- **特性**: XGBoost + PyTorch + MLflow
- **技术栈**: Python + FastAPI + scikit-learn
- **端口**: 8085

### 🛡️ 边缘网关 (Nginx + Lua)
- **功能**: 流量入口和初步过滤
- **特性**: 高性能 + Lua脚本 + 威胁检测
- **技术栈**: OpenResty + Lua + Redis
- **端口**: 80/443

### 🌐 管理面板 (Vue.js)
- **功能**: 系统监控和管理界面
- **特性**: 实时监控 + 配置管理 + 可视化
- **技术栈**: Vue.js + Element Plus + Chart.js
- **端口**: 3001

## 🔧 开发工具

### Makefile 命令
```bash
make help           # 显示帮助信息
make build          # 构建所有服务
make test           # 运行所有测试
make deploy         # 一键部署
make dev            # 启动开发环境
make performance    # 运行性能测试
```

### Docker Compose 环境
- `docker-compose.yml` - 生产环境
- `docker-compose.dev.yml` - 开发环境
- `docker-compose.test.yml` - 测试环境

### 脚本工具
- `scripts/easy-deploy.sh` - 智能部署脚本
- `scripts/health-check.sh` - 健康检查脚本
- `tests/performance/` - k6性能测试

## 📊 监控和可观测性

### Prometheus 指标
- 系统性能指标
- 业务指标
- 自定义指标

### Grafana 看板
- 系统概览
- 威胁检测
- 性能分析
- 资源监控
- ML推理
- 流处理

## 🚀 部署架构

### 多环境支持
- **开发环境**: 基础配置，快速迭代
- **预发布环境**: 标准配置，功能验证
- **生产环境**: 完整配置，高可用部署

### CI/CD 流水线
1. 代码质量检查 (lint, format)
2. 单元测试
3. 安全扫描
4. 构建Docker镜像
5. 集成测试
6. 性能测试
7. 自动部署

## 🔒 安全特性

### 🔧 语言分工架构
- **🔥 Java**: 中台大脑 - 安全层、计算层、存储层、管理层
- **🐍 Python**: AI专家 - 模型训练、特征提取、推理服务  
- **🚀 Go/Nginx**: 边缘战士 - 高并发网关、基础限流、负载均衡
- **🎨 React/Vue**: 界面专家 - 管理后台、监控可视化、策略配置

### 智能需求导向加密
- 🔴 军用级加密 (80% 用户, 50ms) - **默认最强保护** - Java + Python
- 🟠 企业级加密 (15% 用户, 25ms) - 高性能场景 - Java + Go
- 🟡 标准加密 (4% 用户, 15ms) - 兼容性优先 - Go + Lua
- 🟢 轻量级加密 (1% 用户, 8ms) - 资源受限场景 - Go原生

### 多层防护
- CDN + WAF + 边缘网关
- 实时威胁检测
- 行为分析
- 机器学习防护

## 📈 性能指标

### 目标性能
- 平均响应时间: < 10ms
- P95响应时间: < 25ms
- 吞吐量: > 100K QPS
- 可用性: > 99.9%
- 错误率: < 0.1%

### 智能策略选择
- 80% 用户享受军用级安全保护 (Java中台 + Python AI)
- 需求导向的策略调整 (Go网关 + Java规则引擎)
- 默认强加密，按需优化 (多语言协同)

这个项目架构提供了完整的恶意流量检测和防护解决方案，具备高性能、高可用、易维护的特点。