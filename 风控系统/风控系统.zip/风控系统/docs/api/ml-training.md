# 机器学习训练服务 API 文档

机器学习训练服务 (`ml-training`) 是一个 Python 应用，负责处理所有与机器学习模型生命周期相关的任务，包括数据处理、模型训练、超参数优化、评估和导出。

## 主要功能

- **自动化训练流水线**: 提供一个可重复、自动化的流程来训练新模型。
- **超参数优化**: 使用 Optuna 等库自动搜索最佳的模型超参数。
- **模型评估与版本控制**: 对训练好的模型进行评估，并将其与性能指标一起进行版本控制。
- **模型导出**: 将训练好的模型导出为 ONNX 格式，以便 `ml-inference` 服务可以高效地加载和运行。

## API 端点

该服务提供了一个简单的 REST API 来管理训练作业。

### `POST /train`

启动一个新的训练作业。

- **方法**: `POST`
- **路径**: `/train`
- **请求体**: `TrainRequest`
- **响应**: `TrainResponse`

### `GET /train/{job_id}`

获取一个特定训练作业的状态。

- **方法**: `GET`
- **路径**: `/train/{job_id}`
- **响应**: `JobStatus`

## 数据模型

### `TrainRequest`

```python
class TrainRequest(BaseModel):
    model_type: str  # "light" or "heavy"
    hyperparameters: Optional[Dict] = None
    run_evaluation: bool = True
```

- **`model_type`**: 指定要训练的模型类型。
- **`hyperparameters`**: （可选）一组用于覆盖默认值的超参数。
- **`run_evaluation`**: 是否在训练后运行评估。

### `TrainResponse`

```python
class TrainResponse(BaseModel):
    job_id: str
    status: str
    message: str
```

- **`job_id`**: 新创建的训练作业的唯一 ID。
- **`status`**: 作业的初始状态（例如，"queued"）。

### `JobStatus`

```python
class JobStatus(BaseModel):
    job_id: str
    status: str  # e.g., "running", "completed", "failed"
    progress: float
    metrics: Optional[Dict] = None
```

- **`status`**: 作业的当前状态。
- **`progress`**: 作业的完成进度（0.0 到 1.0）。
- **`metrics`**: （如果作业已完成）模型的性能指标，如准确率、AUC 等。

## 训练工作流程

```mermaid
graph TD
    A[API 请求 /train] --> B[启动训练作业]
    B --> C[加载和预处理数据]
    C --> D[超参数优化 (Optuna)]
    D --> E[训练模型 (scikit-learn/XGBoost)]
    E --> F{运行评估?}
    F -->|是| G[评估模型性能]
    G --> H[导出模型为 ONNX]
    F -->|否| H
    H --> I[保存模型到仓库 (S3/MinIO)]
    I --> J[更新作业状态为 'completed']
```

## 配置

服务的配置通过环境变量或 `config.py` 文件进行管理。

### 关键配置项

- **`DATABASE_URL`**: 用于获取训练数据的数据库连接字符串。
- **`MODEL_REGISTRY_PATH`**: 用于存储训练好的模型的路径（例如，`s3://my-bucket/models`）。
- **`DEFAULT_HYPERPARAMETERS`**: 每种模型类型的默认超参数。

## 与其他服务的交互

### 1. 数据库 (`PostgreSQL`)

- **关系**: 数据源。
- **交互**: 从数据库中查询和加载用于训练和评估的数据集。

### 2. 对象存储 (`S3`/`MinIO`)

- **关系**: 模型仓库。
- **交互**: 将训练、评估和导出后的 ONNX 模型文件保存到对象存储中。`ml-inference` 服务将从这里拉取最新的模型。