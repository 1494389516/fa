# 机器学习推理服务 API 文档

机器学习推理服务 (`ml-inference`) 是一个用 Rust 构建的高性能服务，旨在提供快速、可靠的机器学习模型推理。它接收来自流处理服务或其他组件的请求，并返回对流量的威胁评分。

## 主要功能

- **双推理引擎**: 同时支持轻量级和重量级模型，以在延迟和准确性之间取得平衡。
- **ONNX 运行时集成**: 使用 ONNX Runtime 来加载和运行预训练的模型，实现了与训练框架的解耦。
- **高性能**: 基于 Rust 和 `axum` 框架构建，提供了出色的性能和内存安全性。
- **可观测性**: 通过 `tracing` 和 `metrics` 提供了详细的日志和监控指标。

## API 端点

### `POST /predict`

这是核心的推理端点，用于获取对一组特征的威胁评分。

- **方法**: `POST`
- **路径**: `/predict`
- **请求体**: `PredictRequest`
- **响应**: `PredictResponse`

## 数据模型

### `PredictRequest`

请求体包含一个或多个需要评分的特征集。

```rust
pub struct PredictRequest {
    pub model_type: ModelType, // "light" or "heavy"
    pub features: Vec<Vec<f32>>,
}
```

- **`model_type`**: 指定使用哪个模型进行推理（`light` 或 `heavy`）。
- **`features`**: 一个特征向量的数组，每个内部向量代表一个需要评分的样本。

### `PredictResponse`

响应体包含每个特征集的预测分数。

```rust
pub struct PredictResponse {
    pub scores: Vec<f32>,
}
```

- **`scores`**: 一个浮点数数组，每个值对应一个输入样本的威胁评分。

## 双推理引擎

为了平衡不同场景下的性能和准确性需求，服务内部实现了双引擎系统：

1.  **轻量级引擎 (`light_engine`)**:
    - **模型**: 通常是一个较小的模型，如逻辑回归或小型决策树。
    - **特点**: 极低的延迟（通常 < 5ms），适用于需要快速响应的大规模流量筛选。
2.  **重量级引擎 (`heavy_engine`)**:
    - **模型**: 通常是一个更复杂的模型，如梯度提升树 (XGBoost) 或小型神经网络。
    - **特点**: 较高的准确性，但延迟也相对较高（10-80ms），适用于已被初步筛选为可疑的流量。

## 配置

服务的配置位于 `services/ml-inference/config/default.toml`。

### 关键配置项

- **`server.addr`**: 服务监听的地址和端口。
- **`models.light_path`**: 轻量级 ONNX 模型的路径。
- **`models.heavy_path`**: 重量级 ONNX 模型的路径。
- **`telemetry.level`**: 日志记录的级别。

## 与其他服务的交互

### 1. 流处理服务 (`stream-processor`)

- **关系**: 上游服务。
- **交互**: `stream-processor` 在识别出可疑流量后，会向 `ml-inference` 服务发起 `POST /predict` 请求，以获取更精确的威胁评分，从而做出最终的决策。