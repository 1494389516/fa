# 边缘网关 API 文档

边缘网关是系统的入口点，负责处理所有传入的流量。它基于 Nginx 和 Lua 构建，提供了高性能、灵活性和强大的安全功能。

## 主要功能

- **反向代理**: 将流量路由到后端的上游服务。
- **SSL/TLS 终端**: 处理 HTTPS 请求，确保传输安全。
- **速率限制**: 防止暴力破解和拒绝服务攻击。
- **威胁检测**: 使用 Lua 脚本在边缘执行初步的威胁分析。
- **请求路由**: 根据请求的特征将其路由到不同的处理引擎。

## 配置

边缘网关的主要配置文件位于 `services/edge-gateway/conf/nginx.conf`。该文件定义了 Nginx 服务器的行为，包括监听的端口、SSL 证书和上游服务的路由。

### 关键配置块

- **`upstream`**: 定义了后端服务的地址，如 `stream-processor` 和 `ml-inference`。
- **`server`**: 配置了虚拟主机，包括监听端口、服务器名称和 SSL 设置。
- **`location`**: 定义了如何处理不同路径的请求。

### Lua 脚本

Lua 脚本是边缘网关的核心，它们在请求处理的不同阶段执行。

- **`init_worker_by_lua_file`**: 在 Nginx worker 进程启动时加载，用于初始化共享数据和定时任务。
- **`access_by_lua_file`**: 在访问阶段执行，用于实现大部分安全逻辑，如速率限制、威胁检测和请求路由。

## 与其他服务的交互

### 1. 流处理服务 (`stream-processor`)

- **目的**: 将经过初步处理的请求发送到流处理服务进行更深入的分析。
- **方式**: 通过 `proxy_pass` 指令将请求代理到 `stream-processor` 的上游地址。
- **数据**: 完整的 HTTP 请求，包括头部和主体。

### 2. 机器学习推理服务 (`ml-inference`)

- **目的**: 在某些情况下，边缘网关可能会直接调用机器学习模型进行快速评分。
- **方式**: 使用 `ngx.location.capture` 从 Lua 脚本内部发起一个子请求到 `ml-inference` 服务。
- **场景**: 当需要一个即时的、低延迟的威胁评分时，例如在处理高风险 IP 的请求时。

## 监控

边缘网关通过 Prometheus Exporter 暴露了一系列指标，用于监控其性能和健康状况。

- **`nginx_http_requests_total`**: 处理的 HTTP 请求总数。
- **`nginx_http_latency_seconds`**: 请求处理延迟的直方图。
- **`lua_threat_detected_total`**: Lua 脚本检测到的威胁总数。

这些指标由 `monitoring/prometheus.yml` 中的 Prometheus 实例进行抓取，并可以在 Grafana 仪表盘中进行可视化。