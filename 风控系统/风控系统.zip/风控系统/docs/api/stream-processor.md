# 流处理服务 API 文档

流处理服务是系统的核心分析引擎，负责对来自边缘网关的实时流量进行处理、分析和评分。它使用 **Apache Flink** 构建，以实现高吞吐量和低延迟的数据处理。

## 主要功能

- **实时数据摄取**: 从 Kafka 或其他消息队列中消费流量数据。
- **特征工程**: 从原始请求中提取有意义的特征，如 IP 地址、用户代理、请求频率等。
- **异常检测**: 实时识别异常行为模式，如流量突增、扫描行为等。
- **机器学习模型集成**: 调用 `ml-inference` 服务获取威胁评分。
- **数据聚合**: 按时间窗口聚合流量数据，用于趋势分析和报告。

## 数据模型

流处理服务主要处理两种数据模型：

### 1. `TrafficEvent`

这是输入的数据模型，代表一个从边缘网关传入的请求。

```java
public class TrafficEvent {
    private String requestId;
    private String ipAddress;
    private String userAgent;
    private String requestPath;
    private long timestamp;
    // ... 其他字段
}
```

### 2. `ThreatScore`

这是输出的数据模型，代表对一个请求或一个聚合窗口的威胁评分。

```java
public class ThreatScore {
    private String entityId; // e.g., IP address or user ID
    private double score;
    private long timestamp;
    private String details;
    // ... 其他字段
}
```

## Flink 作业

核心逻辑在 `TrafficAnalysisJob.java` 中实现，这是一个 Flink 作业，定义了数据处理的流水线。

```mermaid
graph TD
    A[数据源 (Kafka)] --> B[解析 TrafficEvent]
    B --> C[特征提取]
    C --> D{异常检测}
    D -->|正常流量| E[聚合统计]
    D -->|可疑流量| F[调用 ML 推理]
    F --> G[生成 ThreatScore]
    G --> H[数据汇 (Kafka/DB)]
    E --> H
```

## 配置

服务的配置位于 `services/stream-processor/src/main/resources/application.conf`。

### 关键配置项

- **`kafka.bootstrap.servers`**: Kafka 集群的地址。
- **`flink.parallelism`**: Flink 作业的并行度。
- **`ml.inference.endpoint`**: 机器学习推理服务的地址。
- **`window.size.minutes`**: 用于聚合的时间窗口大小。

## 与其他服务的交互

### 1. 边缘网关 (`edge-gateway`)

- **关系**: 上游服务。
- **交互**: 从边缘网关接收原始流量数据，通常是通过一个共享的 Kafka 主题。

### 2. 机器学习推理服务 (`ml-inference`)

- **关系**: 下游服务。
- **交互**: 当检测到可疑流量时，通过 HTTP/gRPC 调用 `ml-inference` 服务，以获取更精确的威胁评分。

### 3. 数据库 (`PostgreSQL` / `Redis`)

- **关系**: 数据存储。
- **交互**: 将处理结果（如 `ThreatScore`）和聚合统计数据存储到数据库中，以供管理面板查询和长期分析。