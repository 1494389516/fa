# 🛡️ 恶意流量控制系统 - 语言与框架分工架构

## 🎯 语言职责分工说明

### 🔥 Java - 中台大脑 (核心业务逻辑)
- **安全层**: 流控引擎、风险评估、策略编排
- **计算层**: 分控逻辑、异步调度、业务规则引擎
- **存储层**: 数据持久化、搜索服务、缓存管理
- **监控管理层**: 管理后台、系统监控、配置管理

### 🐍 Python - 实验室助手 (AI/ML专家)
- **AI/ML模型训练**: 特征工程、模型训练、超参数调优
- **推理服务**: 独立微服务，提供REST API供Java调用
- **数据科学**: 数据分析、可视化、实验验证

### 🚀 Go/Nginx - 边缘战士 (高性能网关)
- **边缘接入层**: 高并发请求处理、基础限流
- **网关服务**: 请求路由、负载均衡、协议转换
- **性能优化**: 内存管理、并发处理、网络I/O

### 🎨 React/Vue - 界面专家 (用户体验)
- **管理后台UI**: 策略配置、监控面板、数据可视化
- **安全策略可视化**: 威胁态势感知、实时监控大屏

## 🎯 语言分工概览图

```mermaid
graph TB
    subgraph "🌐 用户请求"
        U[用户流量<br/>100K+ QPS]
    end
    
    subgraph "🚀 Go/Nginx - 边缘战士"
        G[高并发网关<br/>Gin + OpenResty<br/>基础限流 + 负载均衡]
    end
    
    subgraph "🔥 Java - 中台大脑"
        J[安全 + 计算 + 存储 + 管理<br/>Spring Boot + Flink + Drools<br/>业务逻辑 + 策略编排]
    end
    
    subgraph "🐍 Python - AI专家"
        P[模型训练 + 推理服务<br/>PyTorch + FastAPI + ONNX<br/>特征提取 + 行为分析]
    end
    
    subgraph "🎨 React/Vue - 界面专家"
        R[管理后台 + 监控可视化<br/>React + Ant Design + ECharts<br/>策略配置 + 数据展示]
    end
    
    U -->|"HTTP/HTTPS<br/>高并发请求"| G
    G -->|"安全检查<br/>流量分发"| J
    J -->|"AI推理调用<br/>特征数据"| P
    P -->|"推理结果<br/>威胁评分"| J
    J -->|"管理API<br/>监控数据"| R
    R -->|"配置更新<br/>策略调整"| J
    
    classDef goStyle fill:#00ADD8,stroke:#00ADD8,stroke-width:3px,color:#fff
    classDef javaStyle fill:#ED8B00,stroke:#ED8B00,stroke-width:3px,color:#fff
    classDef pythonStyle fill:#3776AB,stroke:#3776AB,stroke-width:3px,color:#fff
    classDef reactStyle fill:#61DAFB,stroke:#61DAFB,stroke-width:3px,color:#000
    
    class G goStyle
    class J javaStyle
    class P pythonStyle
    class R reactStyle
```

## 🏗️ 语言与框架分工架构图

```mermaid
graph TB
    subgraph "🌐 用户请求层"
        U1[正常用户]
        U2[爬虫/机器人] 
        U3[恶意攻击者]
        U4[API调用者]
    end
    
    subgraph "🚀 边缘接入层 - Go/Nginx"
        subgraph "Go微服务集群"
            GW1[Go Gateway<br/>gin/fiber框架<br/>高并发处理]
            GW2[Go Load Balancer<br/>负载均衡<br/>健康检查]
        end
        subgraph "Nginx集群"
            NG1[Nginx + OpenResty<br/>Lua脚本<br/>基础限流]
            NG2[Nginx Upstream<br/>反向代理<br/>SSL终结]
        end
    end
    
    subgraph "🛡️ 安全防护层 - Java中台"
        subgraph "Spring Boot微服务"
            SC1[Security Controller<br/>Spring Security<br/>访问控制]
            RC1[Rate Controller<br/>Redis + Lua<br/>智能限流]
            FC1[Flow Controller<br/>Sentinel<br/>流量控制]
        end
        subgraph "规则引擎"
            RE1[Risk Engine<br/>Drools规则引擎<br/>风险评估]
            PE1[Policy Engine<br/>策略编排<br/>决策树]
        end
    end
    
    subgraph "🧠 智能计算层 - Java + Python"
        subgraph "Java计算服务"
            SP1[Stream Processor<br/>Apache Flink<br/>实时流处理]
            AS1[Async Scheduler<br/>Spring Async<br/>异步调度]
            BL1[Business Logic<br/>Spring Boot<br/>业务逻辑]
        end
        subgraph "Python AI服务"
            ML1[ML Inference<br/>FastAPI + ONNX<br/>模型推理]
            FE1[Feature Extractor<br/>Pandas + NumPy<br/>特征提取]
            BA1[Behavior Analyzer<br/>Scikit-learn<br/>行为分析]
        end
    end
    
    subgraph "💾 数据存储层 - Java管理"
        subgraph "缓存层"
            RD1[Redis Cluster<br/>Spring Data Redis<br/>热数据缓存]
            MC1[MemCache<br/>分布式缓存<br/>会话存储]
        end
        subgraph "持久化层"
            PG1[PostgreSQL<br/>Spring Data JPA<br/>结构化数据]
            ES1[Elasticsearch<br/>Spring Data ES<br/>日志搜索]
        end
        subgraph "对象存储"
            S31[MinIO/S3<br/>模型文件<br/>日志归档]
        end
    end
    
    subgraph "🤖 AI训练层 - Python专区"
        subgraph "模型训练"
            TR1[Model Trainer<br/>PyTorch/TensorFlow<br/>深度学习训练]
            FE2[Feature Engineering<br/>Pandas + Dask<br/>大数据特征工程]
        end
        subgraph "实验平台"
            EX1[Experiment Platform<br/>MLflow + Jupyter<br/>实验管理]
            MR1[Model Registry<br/>模型版本管理<br/>A/B测试]
        end
    end
    
    subgraph "📊 监控运维层 - Java + Go"
        subgraph "监控服务"
            PR1[Prometheus<br/>Go原生<br/>指标收集]
            GR1[Grafana<br/>Go + React<br/>可视化面板]
        end
        subgraph "日志服务"
            LG1[Log Aggregator<br/>Logstash + Java<br/>日志聚合]
            AL1[Alert Manager<br/>Go服务<br/>告警系统]
        end
    end
    
    subgraph "⚙️ 管理控制层 - Java + React"
        subgraph "后台管理"
            AD1[Admin Backend<br/>Spring Boot<br/>管理API]
            CF1[Config Center<br/>Spring Cloud Config<br/>配置中心]
        end
        subgraph "前端界面"
            UI1[Admin UI<br/>React + Ant Design<br/>管理界面]
            DS1[Dashboard<br/>Vue + ECharts<br/>监控大屏]
        end
    end
    
    %% 🎯 主要数据流向
    U1 -->|"HTTP/HTTPS"| NG1
    U2 -->|"API请求"| GW1
    U3 -->|"攻击流量"| NG2
    U4 -->|"合法API"| GW2
    
    %% 边缘层处理
    NG1 -->|"基础过滤"| SC1
    NG2 -->|"SSL终结"| RC1
    GW1 -->|"负载均衡"| FC1
    GW2 -->|"健康检查"| RE1
    
    %% 安全层决策
    SC1 -->|"访问控制"| SP1
    RC1 -->|"限流决策"| ML1
    FC1 -->|"流控策略"| FE1
    RE1 -->|"风险评估"| BA1
    PE1 -->|"策略执行"| AS1
    
    %% AI推理流程
    ML1 -->|"推理结果"| BL1
    FE1 -->|"特征数据"| ML1
    BA1 -->|"行为分析"| PE1
    
    %% 数据存储
    BL1 -->|"业务数据"| PG1
    AS1 -->|"缓存数据"| RD1
    SP1 -->|"流数据"| ES1
    
    %% AI训练反馈
    ES1 -->|"训练数据"| TR1
    TR1 -->|"新模型"| MR1
    MR1 -->|"模型更新"| ML1
    FE2 -->|"特征优化"| FE1
    
    %% 监控告警
    SP1 -->|"指标上报"| PR1
    ML1 -->|"性能指标"| PR1
    PR1 -->|"监控数据"| GR1
    BL1 -->|"业务日志"| LG1
    LG1 -->|"告警触发"| AL1
    
    %% 管理控制
    AD1 -->|"配置管理"| CF1
    CF1 -->|"配置下发"| SC1
    CF1 -->|"策略更新"| PE1
    UI1 -->|"管理操作"| AD1
    DS1 -->|"数据展示"| GR1
    
    %% 样式定义
    classDef goService fill:#00ADD8,stroke:#00ADD8,stroke-width:2px,color:#fff
    classDef javaService fill:#ED8B00,stroke:#ED8B00,stroke-width:2px,color:#fff
    classDef pythonService fill:#3776AB,stroke:#3776AB,stroke-width:2px,color:#fff
    classDef frontendService fill:#61DAFB,stroke:#61DAFB,stroke-width:2px,color:#000
    classDef storageService fill:#336791,stroke:#336791,stroke-width:2px,color:#fff
    classDef nginxService fill:#009639,stroke:#009639,stroke-width:2px,color:#fff
    
    %% 应用样式
    class GW1,GW2,PR1,AL1 goService
    class SC1,RC1,FC1,RE1,PE1,SP1,AS1,BL1,AD1,CF1,LG1 javaService
    class ML1,FE1,BA1,TR1,FE2,EX1,MR1 pythonService
    class UI1,DS1,GR1 frontendService
    class RD1,MC1,PG1,ES1,S31 storageService
    class NG1,NG2 nginxService
```

## 🔄 数据流向说明

### 1. 🚀 请求处理流程
```
用户请求 → Go/Nginx网关 → Java安全层 → Java计算层 → Python AI推理 → Java业务逻辑 → 响应返回
```

### 2. 🧠 AI推理流程
```
特征提取(Python) → 模型推理(Python) → 结果返回(Java) → 策略执行(Java)
```

### 3. 📊 监控流程
```
各服务指标 → Prometheus(Go) → Grafana(React) → 告警(Go) → 管理界面(React)
```

### 4. 🔄 配置管理流程
```
管理界面(React) → 管理API(Java) → 配置中心(Java) → 各微服务配置更新
```

## 🎯 技术栈选择理由

### Java - 企业级中台首选
- **成熟生态**: Spring全家桶、丰富的中间件
- **高并发**: 成熟的并发编程模型、JVM优化
- **企业级**: 完善的监控、治理、运维工具链
- **团队技能**: 企业开发团队技能匹配度高

### Python - AI/ML领域王者
- **AI生态**: PyTorch、TensorFlow、Scikit-learn
- **数据处理**: Pandas、NumPy、Dask
- **快速迭代**: 适合算法实验和模型训练
- **独立部署**: 微服务架构，与Java解耦

### Go - 高性能网关利器
- **高并发**: 原生协程、优秀的并发性能
- **低延迟**: 编译型语言、内存管理高效
- **云原生**: Kubernetes、Docker生态完善
- **运维友好**: 单二进制部署、资源占用少

### React/Vue - 现代前端标准
- **组件化**: 可复用组件、维护性好
- **生态丰富**: UI库、图表库、工具链完善
- **开发效率**: 热重载、TypeScript支持
- **用户体验**: 响应式设计、交互友好

## 📈 性能优化策略

### 🚀 Go网关层优化
- 连接池复用、内存池管理
- 协程并发、非阻塞I/O
- 热点数据缓存、智能路由

### ☕ Java中台优化
- JVM参数调优、GC优化
- 连接池配置、线程池管理
- Redis缓存、数据库索引优化

### 🐍 Python AI优化
- 模型量化、推理加速
- 批量处理、异步调用
- GPU加速、模型缓存

### 🎨 前端优化
- 代码分割、懒加载
- CDN加速、资源压缩
- 虚拟滚动、防抖节流

## 🔧 部署架构建议

### 🐳 容器化部署
```yaml
# Go服务: 轻量级Alpine镜像
# Java服务: OpenJDK官方镜像
# Python服务: Python官方镜像 + 科学计算库
# 前端: Nginx + 静态资源
```

### ☁️ 云原生架构
```yaml
# Kubernetes集群部署
# Istio服务网格
# Prometheus + Grafana监控
# ELK日志聚合
```

这个架构图完整展示了各语言在系统中的职责分工，保持了原有的7层架构逻辑，同时明确了技术栈选择和数据流向。