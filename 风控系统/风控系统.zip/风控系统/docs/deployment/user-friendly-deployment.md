# 部署指南

本指南将引导您完成恶意流量控制系统的部署过程。我们采用 **Docker Compose** 进行服务编排，以实现快速、可靠和可重复的部署。

## 部署架构

我们的部署策略基于容器化技术，具有以下优势：

- **环境一致性**: 在开发、测试和生产环境中使用相同的镜像。
- **快速部署**: 通过 `docker-compose` 命令一键启动整个系统。
- **优化性能**: 每个服务都使用多阶段构建的 Dockerfile，以减小镜像体积并提高安全性。
- **易于扩展**: 可以轻松地扩展单个服务以应对高流量。

```mermaid
graph TD
    subgraph "部署流程"
        A[1. 准备环境] --> B[2. 配置 .env 文件]
        B --> C[3. 构建并启动服务]
        C --> D[4. 验证系统状态]
    end

    subgraph "核心组件"
        E[Docker Engine]
        F[Docker Compose]
        G[预构建的 Docker 镜像]
        H[.env 配置文件]
    end

    subgraph "部署产物"
        I[运行中的服务容器]
        J[持久化数据卷]
        K[网络]
    end

    D --> I
    C --> G
    B --> H
    A --> E
    A --> F
```

## 部署步骤

### 1. 环境准备

在开始之前，请确保您的系统已安装以下软件：

- **Docker**: [https://get.docker.com/](https://get.docker.com/)
- **Docker Compose**: 通常随 Docker Desktop 一起安装。如果未安装，请参阅 [官方文档](https://docs.docker.com/compose/install/)。

您可以使用项目根目录下的 `scripts/check-environment.sh` 脚本来验证您的环境：

```bash
./scripts/check-environment.sh
```

### 2. 配置 `.env` 文件

系统的大部分配置都通过根目录下的 `.env` 文件进行管理。我们提供了一个智能配置脚本 `scripts/generate-config.sh`，它可以根据您的系统资源自动生成一个优化过的 `.env` 文件。

```bash
./scripts/generate-config.sh
```

该脚本将自动检测您的 CPU 和内存，并设置适当的工作线程数和批处理大小。它还会生成安全的随机密码和密钥。

**手动配置**:

如果您想手动调整配置，可以直接编辑 `.env` 文件。以下是一些关键的配置项：

- `EDGE_GATEWAY_PORT`: 边缘网关的端口。
- `POSTGRES_PASSWORD`: PostgreSQL 数据库的密码。
- `JWT_SECRET`: 用于身份验证的 JWT 密钥。

### 3. 构建并启动服务

完成配置后，您可以使用 `docker-compose` 来构建和启动所有服务。

```bash
docker-compose up --build -d
```

- `--build`: 强制重新构建镜像，以确保应用最新的代码和 Dockerfile 更改。
- `-d`: 在后台（分离模式）运行容器。

这个过程可能需要一些时间，因为它会下载基础镜像、构建每个服务的 Docker 镜像并启动容器。

### 4. 验证系统状态

服务启动后，等待大约一分钟，然后运行健康检查脚本来验证所有服务是否正常运行：

```bash
./scripts/health-check.sh
```

您应该会看到所有核心服务都处于 `Up` 状态。

### 5. 访问管理面板

部署成功后，您可以通过浏览器访问管理面板：

- **URL**: `http://localhost:8080` (或您在 `.env` 文件中配置的 `ADMIN_PANEL_PORT`)

首次部署时，`scripts/setup-admin.sh` 脚本会自动创建一个管理员账户，并将凭据保存在 `admin_credentials.txt` 文件中。

## 常用命令

以下是一些在日常运维中可能会用到的 `docker-compose` 命令：

- **查看服务状态**: `docker-compose ps`
- **查看实时日志**: `docker-compose logs -f`
- **停止所有服务**: `docker-compose down`
- **重启服务**: `docker-compose restart <service_name>`

## 多阶段 Docker 构建

为了优化性能和安全性，我们为每个服务都采用了 **多阶段构建** 的 Dockerfile。这种方法带来了以下好处：

- **更小的生产镜像**: 最终的生产镜像只包含运行应用所需的最小依赖，不包含任何构建工具或中间文件。
- **更高的安全性**: 减少了攻击面，因为生产镜像中不存在不必要的工具（如编译器、包管理器等）。
- **更快的部署**: 更小的镜像可以更快地被拉取和部署。

您可以在每个服务的目录中找到 `Dockerfile`，以了解其具体的构建过程。

<function_calls>
<invoke name="fsWrite">
<parameter name="path">web/admin/index.htmlPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>恶意流量控制系统 - 管理面板</title>
    <script src="https://cdn.jsdelivr.net/npm/vue@3/dist/vue.global.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            transition: transform 0.2s ease;
        }
        
        .card:hover { transform: translateY(-2px); }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #333;
        }
        
        .metric {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
            border-bottom: 1px solid #eee;
        }
        
        .metric:last-child { border-bottom: none; }
        
        .metric-value {
            font-weight: 600;
            color: #667eea;
        }
        
        .status-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 8px;
        }
        
        .status-healthy { background: #10b981; }
        .status-warning { background: #f59e0b; }
        .status-error { background: #ef4444; }
        
        .btn {
            background: #667eea;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            transition: background 0.2s ease;
        }
        
        .btn:hover { background: #5a67d8; }
        
        .btn-secondary {
            background: #6b7280;
        }
        
        .btn-secondary:hover { background: #4b5563; }
        
        .encryption-level {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin: 1rem 0;
        }
        
        .level-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .level-basic { background: #dbeafe; color: #1e40af; }
        .level-standard { background: #fef3c7; color: #92400e; }
        .level-advanced { background: #fecaca; color: #991b1b; }
        .level-vmp { background: #e5e7eb; color: #374151; }
        
        .chart-container {
            position: relative;
            height: 300px;
            margin-top: 1rem;
        }
        
        .config-section {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            margin-top: 2rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #374151;
        }
        
        .form-input {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 1rem;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fca5a5;
        }
    </style>
</head>
<body>
    <div id="app">
        <header class="header">
            <h1>🛡️ 恶意流量控制系统</h1>
            <p>智能防护 · 用户友好 · 一键部署</p>
        </header>
        
        <div class="container">
            <!-- 系统状态概览 -->
            <div class="dashboard-grid">
                <div class="card">
                    <h3 class="card-title">🚀 系统状态</h3>
                    <div class="metric">
                        <span><span class="status-indicator" :class="systemStatus.overall"></span>整体状态</span>
                        <span class="metric-value">{{ systemStatus.text }}</span>
                    </div>
                    <div class="metric">
                        <span>运行时间</span>
                        <span class="metric-value">{{ uptime }}</span>
                    </div>
                    <div class="metric">
                        <span>处理请求</span>
                        <span class="metric-value">{{ formatNumber(totalRequests) }}</span>
                    </div>
                    <div class="metric">
                        <span>拦截攻击</span>
                        <span class="metric-value">{{ formatNumber(blockedAttacks) }}</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3 class="card-title">🔐 加密策略分布</h3>
                    <div class="encryption-level">
                        <span class="level-badge level-basic">基础 {{ encryptionStats.basic }}%</span>
                        <span class="level-badge level-standard">标准 {{ encryptionStats.standard }}%</span>
                    </div>
                    <div class="encryption-level">
                        <span class="level-badge level-advanced">高级 {{ encryptionStats.advanced }}%</span>
                        <span class="level-badge level-vmp">VMP {{ encryptionStats.vmp }}%</span>
                    </div>
                    <div class="chart-container">
                        <canvas id="encryptionChart"></canvas>
                    </div>
                </div>
                
                <div class="card">
                    <h3 class="card-title">⚡ 性能指标</h3>
                    <div class="metric">
                        <span>平均响应时间</span>
                        <span class="metric-value">{{ avgResponseTime }}ms</span>
                    </div>
                    <div class="metric">
                        <span>签名验证成功率</span>
                        <span class="metric-value">{{ signatureSuccessRate }}%</span>
                    </div>
                    <div class="metric">
                        <span>误报率</span>
                        <span class="metric-value">{{ falsePositiveRate }}%</span>
                    </div>
                    <div class="metric">
                        <span>CPU使用率</span>
                        <span class="metric-value">{{ cpuUsage }}%</span>
                    </div>
                </div>
                
                <div class="card">
                    <h3 class="card-title">🎯 威胁检测</h3>
                    <div class="metric">
                        <span>实时威胁</span>
                        <span class="metric-value" style="color: #ef4444;">{{ activeThreat }}</span>
                    </div>
                    <div class="metric">
                        <span>今日拦截</span>
                        <span class="metric-value">{{ todayBlocked }}</span>
                    </div>
                    <div class="metric">
                        <span>高风险IP</span>
                        <span class="metric-value">{{ highRiskIPs }}</span>
                    </div>
                    <div class="metric">
                        <span>异常设备</span>
                        <span class="metric-value">{{ anomalousDevices }}</span>
                    </div>
                </div>
            </div>
            
            <!-- 实时流量图表 -->
            <div class="card">
                <h3 class="card-title">📊 实时流量监控</h3>
                <div class="chart-container">
                    <canvas id="trafficChart"></canvas>
                </div>
            </div>
            
            <!-- 智能配置面板 -->
            <div class="config-section">
                <h3 class="card-title">⚙️ 智能配置</h3>
                
                <div v-if="configMessage" :class="'alert alert-' + configMessage.type">
                    {{ configMessage.text }}
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div>
                        <div class="form-group">
                            <label class="form-label">加密策略</label>
                            <select v-model="config.encryptionStrategy" class="form-input">
                                <option value="auto">🤖 智能自适应</option>
                                <option value="performance">⚡ 性能优先</option>
                                <option value="security">🔒 安全优先</option>
                                <option value="balanced">⚖️ 平衡模式</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">威胁阈值</label>
                            <input v-model="config.threatThreshold" type="range" min="0.1" max="0.9" step="0.1" class="form-input">
                            <small>当前值: {{ config.threatThreshold }}</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">密钥轮换间隔 (分钟)</label>
                            <input v-model="config.keyRotationInterval" type="number" min="1" max="60" class="form-input">
                        </div>
                    </div>
                    
                    <div>
                        <div class="form-group">
                            <label class="form-label">性能模式</label>
                            <select v-model="config.performanceMode" class="form-input">
                                <option value="eco">🌱 节能模式</option>
                                <option value="balanced">⚖️ 平衡模式</option>
                                <option value="performance">🚀 性能模式</option>
                                <option value="turbo">⚡ 极速模式</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">日志级别</label>
                            <select v-model="config.logLevel" class="form-input">
                                <option value="error">ERROR</option>
                                <option value="warn">WARN</option>
                                <option value="info">INFO</option>
                                <option value="debug">DEBUG</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">监控采样率 (%)</label>
                            <input v-model="config.monitoringSampleRate" type="number" min="1" max="100" class="form-input">
                        </div>
                    </div>
                </div>
                
                <div style="margin-top: 2rem;">
                    <button @click="saveConfig" class="btn">💾 保存配置</button>
                    <button @click="resetConfig" class="btn btn-secondary" style="margin-left: 1rem;">🔄 重置默认</button>
                    <button @click="exportConfig" class="btn btn-secondary" style="margin-left: 1rem;">📤 导出配置</button>
                </div>
            </div>
            
            <!-- 快速操作 -->
            <div class="config-section">
                <h3 class="card-title">🚀 快速操作</h3>
                <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                    <button @click="restartServices" class="btn">🔄 重启服务</button>
                    <button @click="updateModels" class="btn">🤖 更新模型</button>
                    <button @click="clearCache" class="btn">🗑️ 清理缓存</button>
                    <button @click="exportLogs" class="btn btn-secondary">📋 导出日志</button>
                    <button @click="runDiagnostics" class="btn btn-secondary">🔍 系统诊断</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const { createApp } = Vue;
        
        createApp({
            data() {
                return {
                    systemStatus: { overall: 'status-healthy', text: '运行正常' },
                    uptime: '2天 14小时',
                    totalRequests: 1234567,
                    blockedAttacks: 8901,
                    encryptionStats: { basic: 89.2, standard: 8.1, advanced: 2.6, vmp: 0.1 },
                    avgResponseTime: 12,
                    signatureSuccessRate: 99.94,
                    falsePositiveRate: 0.02,
                    cpuUsage: 23,
                    activeThreat: 3,
                    todayBlocked: 234,
                    highRiskIPs: 12,
                    anomalousDevices: 5,
                    config: {
                        encryptionStrategy: 'auto',
                        threatThreshold: 0.5,
                        keyRotationInterval: 10,
                        performanceMode: 'balanced',
                        logLevel: 'info',
                        monitoringSampleRate: 10
                    },
                    configMessage: null
                }
            },
            
            mounted() {
                this.initCharts();
                this.startRealTimeUpdates();
            },
            
            methods: {
                formatNumber(num) {
                    return num.toLocaleString();
                },
                
                initCharts() {
                    // 加密策略分布图
                    const encCtx = document.getElementById('encryptionChart').getContext('2d');
                    new Chart(encCtx, {
                        type: 'doughnut',
                        data: {
                            labels: ['基础加密', '标准加密', '高级加密', 'VMP混淆'],
                            datasets: [{
                                data: [89.2, 8.1, 2.6, 0.1],
                                backgroundColor: ['#3b82f6', '#f59e0b', '#ef4444', '#6b7280']
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: { legend: { position: 'bottom' } }
                        }
                    });
                    
                    // 实时流量图
                    const trafficCtx = document.getElementById('trafficChart').getContext('2d');
                    new Chart(trafficCtx, {
                        type: 'line',
                        data: {
                            labels: Array.from({length: 20}, (_, i) => `${i}:00`),
                            datasets: [{
                                label: '正常流量',
                                data: Array.from({length: 20}, () => Math.random() * 100 + 50),
                                borderColor: '#10b981',
                                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                                fill: true
                            }, {
                                label: '恶意流量',
                                data: Array.from({length: 20}, () => Math.random() * 20),
                                borderColor: '#ef4444',
                                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: { beginAtZero: true }
                            }
                        }
                    });
                },
                
                startRealTimeUpdates() {
                    setInterval(() => {
                        // 模拟实时数据更新
                        this.totalRequests += Math.floor(Math.random() * 10);
                        this.avgResponseTime = Math.floor(Math.random() * 5) + 10;
                        this.cpuUsage = Math.floor(Math.random() * 20) + 15;
                    }, 5000);
                },
                
                saveConfig() {
                    // 模拟保存配置
                    this.configMessage = { type: 'success', text: '配置保存成功！系统将在30秒内生效。' };
                    setTimeout(() => this.configMessage = null, 3000);
                },
                
                resetConfig() {
                    this.config = {
                        encryptionStrategy: 'auto',
                        threatThreshold: 0.5,
                        keyRotationInterval: 10,
                        performanceMode: 'balanced',
                        logLevel: 'info',
                        monitoringSampleRate: 10
                    };
                    this.configMessage = { type: 'success', text: '配置已重置为默认值。' };
                    setTimeout(() => this.configMessage = null, 3000);
                },
                
                exportConfig() {
                    const configJson = JSON.stringify(this.config, null, 2);
                    const blob = new Blob([configJson], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'malicious-traffic-control-config.json';
                    a.click();
                },
                
                restartServices() {
                    this.configMessage = { type: 'success', text: '正在重启服务，预计需要30秒...' };
                    setTimeout(() => {
                        this.configMessage = { type: 'success', text: '服务重启完成！' };
                        setTimeout(() => this.configMessage = null, 3000);
                    }, 2000);
                },
                
                updateModels() {
                    this.configMessage = { type: 'success', text: '正在更新ML模型，请稍候...' };
                    setTimeout(() => {
                        this.configMessage = { type: 'success', text: '模型更新完成！新模型已生效。' };
                        setTimeout(() => this.configMessage = null, 3000);
                    }, 3000);
                },
                
                clearCache() {
                    this.configMessage = { type: 'success', text: '缓存清理完成！' };
                    setTimeout(() => this.configMessage = null, 3000);
                },
                
                exportLogs() {
                    this.configMessage = { type: 'success', text: '日志导出中，请稍候...' };
                    setTimeout(() => {
                        this.configMessage = { type: 'success', text: '日志已导出到 logs/export.zip' };
                        setTimeout(() => this.configMessage = null, 3000);
                    }, 2000);
                },
                
                runDiagnostics() {
                    this.configMessage = { type: 'success', text: '系统诊断中...' };
                    setTimeout(() => {
                        this.configMessage = { type: 'success', text: '诊断完成！系统运行正常，无异常发现。' };
                        setTimeout(() => this.configMessage = null, 5000);
                    }, 3000);
                }
            }
        }).mount('#app');
    </script>
</body>
</html>