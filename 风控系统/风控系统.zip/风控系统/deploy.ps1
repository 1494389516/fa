# 实时流量风控系统 - PowerShell 部署脚本

# --- 颜色定义 ---
$GREEN = "`e[32m"
$YELLOW = "`e[33m"
$RED = "`e[31m"
$NC = "`e[0m"

# --- 函数定义 ---
function Write-Info {
    param([string]$Message)
    Write-Host "${GREEN}[信息] $Message${NC}"
}

function Write-Warn {
    param([string]$Message)
    Write-Host "${YELLOW}[警告] $Message${NC}"
}

function Write-Error {
    param([string]$Message)
    Write-Host "${RED}[错误] $Message${NC}"
    exit 1
}

function Check-Command {
    param([string]$Command)
    if (-not (Get-Command $Command -ErrorAction SilentlyContinue)) {
        Write-Error "'$Command' 命令未找到。请先安装 '$Command' 再运行此脚本。"
    }
}

# --- 主逻辑开始 ---

# 1. 检查核心依赖
Write-Info "正在检查环境依赖 (Docker)..."
Check-Command "docker"

# 兼容 docker-compose (v1) 和 docker compose (v2)
$COMPOSE_CMD = ""
if (Get-Command "docker-compose" -ErrorAction SilentlyContinue) {
    $COMPOSE_CMD = "docker-compose"
} elseif ((docker compose version) -match "Docker Compose version") {
    $COMPOSE_CMD = "docker compose"
} else {
    Write-Error "Docker Compose 未安装。请安装 Docker Desktop 或 Docker Compose 插件。"
}
Write-Info "依赖检查通过。使用 '$COMPOSE_CMD' 命令。"

# 2. 检查并加载配置文件
Write-Info "正在检查配置文件 (.env)..."
if (-not (Test-Path ".env")) {
    Write-Warn "配置文件 .env 不存在，将从 .env.example 创建。"
    if (-not (Test-Path ".env.example")) {
        Write-Error "模板文件 .env.example 也不存在，无法继续。请从代码仓库恢复该文件。"
    }
    Copy-Item ".env.example" ".env"
    Write-Error "已根据模板创建 .env 文件。请打开并修改其中的配置项（如 DB_PASSWORD），然后重新运行此脚本。"
} else {
    Write-Info "配置文件 .env 已存在。"
}

# 校验关键变量是否已设置
$envContent = Get-Content ".env"
$dbPasswordLine = $envContent | Select-String -Pattern "DB_PASSWORD"
if (-not $dbPasswordLine -or $dbPasswordLine -match "your_super_secret_password") {
    Write-Error "数据库密码 'DB_PASSWORD' 未在 .env 文件中设置或仍为默认值。请更新密码后重试。"
}

# 3. 构建并启动服务
Write-Info "准备使用 '$COMPOSE_CMD' 构建并启动所有服务..."
Write-Info "这可能需要一些时间，具体取决于您的网络速度和机器性能。"

Invoke-Expression "$COMPOSE_CMD up --build -d"

# 检查 Docker Compose 命令是否成功执行
if ($LASTEXITCODE -ne 0) {
    Write-Error "Docker Compose 启动失败。请检查上方的错误日志以定位问题。"
}

# 4. 显示部署成功信息
Write-Info "部署成功！"
Write-Host ""
Write-Host "--------------------------------------------------"
Write-Host "${GREEN}所有服务已在后台成功启动。${NC}"
Write-Host ""
Write-Host "您现在可以通过以下地址访问各个服务："
Write-Host "  - 监控面板:    `e[1;34mhttp://localhost:3000`e[0m (用户: admin, 密码: admin)"
Write-Host "  - 管理后台:    `e[1;34mhttp://localhost:3001`e[0m"
Write-Host "  - Kafka UI:    `e[1;34mhttp://localhost:9090`e[0m"
Write-Host ""
Write-Host "常用命令:"
Write-Host "  - 查看所有服务状态: `e[1;33m$COMPOSE_CMD ps`e[0m"
Write-Host "  - 查看所有服务日志: `e[1;33m$COMPOSE_CMD logs -f`e[0m"
Write-Host "  - 查看单个服务日志: `e[1;33m$COMPOSE_CMD logs -f <service_name>`e[0m (例如: ml-training)"
Write-Host "  - 停止所有服务:     `e[1;33m$COMPOSE_CMD down`e[0m"
Write-Host "--------------------------------------------------"
Write-Host ""

exit 0