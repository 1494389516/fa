# 机器学习推理服务 (ML Inference)

本服务是一个用 Rust 编写的高性能 Web 服务，专用于执行机器学习模型的实时推理。它加载通过 `ml-training` 服务训练并导出的 ONNX 模型，提供一个快速、低延迟的预测 API。

## 核心功能

-   **高性能推理**: 基于 Rust 和 `tch-rs` (LibTorch) / `onnxruntime-rs` 库，为低延迟场景优化。
-   **模型加载**: 动态加载 ONNX 格式的模型文件。
-   **RESTful API**: 提供一个简单的 `/predict` 端点，接收特征数据并返回预测结果。
-   **并发处理**: 利用 Rust 的 `async/await` 和 `tokio` 运行时，能够高效处理大量并发请求。

## 技术栈

-   **语言**: Rust (2021 Edition)
-   **Web 框架**: Actix Web
-   **机器学习**: `onnxruntime-rs`
-   **异步运行时**: Tokio

## API 端点

### `/predict` (POST)

接收一个包含特征向量的 JSON 对象，返回模型的预测结果。

**请求示例**:
```json
{
  "features": [0.1, 0.2, 0.3, ..., 0.9]
}
```

**响应示例**:
```json
{
  "prediction": 1,
  "score": 0.95
}
```

### `/health` (GET)

健康检查端点，用于监控服务状态。

**响应示例**:
```json
{
  "status": "ok"
}
```

## 本地开发与运行

### 先决条件

-   安装 Rust: `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`
-   安装 `libonnxruntime`。具体步骤请参考 [onnxruntime-rs 文档](https.github.com/nbigaouette/onnxruntime-rs)。

### 运行

1.  **编译并运行项目**:
    ```bash
    # 从 services/ml-inference/ 目录运行
    cargo run --release
    ```

2.  **测试服务**:
    ```bash
    curl -X POST http://127.0.0.1:8084/predict \
         -H "Content-Type: application/json" \
         -d '{"features": [0.1, 0.2, ...]}'
    ```

## 配置

服务的配置通过 `config/default.toml` 文件管理。主要配置项包括：

-   `server_addr`: 服务监听的地址和端口。
-   `model_path`: 存放 ONNX 模型的目录路径。

在 `docker-compose.yml` 中，这些配置可以通过环境变量覆盖。