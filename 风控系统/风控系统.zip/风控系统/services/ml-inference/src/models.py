import os
import json
import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

import xgboost as xgb
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.preprocessing import StandardScaler
import redis.asyncio as redis

from .config import Settings


class EnsemblePredictor:
    """Ensemble模型预测器"""

    def __init__(self, model_path: str):
        self.model_path = model_path
        self.ensemble_model = None
        self.feature_names = None

    async def load_model(self):
        """加载Ensemble模型"""
        try:
            model_file = os.path.join(self.model_path, "ensemble_model.pkl")
            if os.path.exists(model_file):
                import joblib
                self.ensemble_model = joblib.load(model_file)
                self.feature_names = self.ensemble_model.feature_names
                logging.info(f"Ensemble模型加载成功: {model_file}")
                if self.feature_names:
                    logging.info(f"特征名称加载成功，共{len(self.feature_names)}个特征")
            else:
                logging.warning(f"Ensemble模型文件不存在: {model_file}")

        except Exception as e:
            logging.error(f"Ensemble模型加载失败: {e}")
            raise

    def predict(self, features: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """预测流量风险"""
        if self.ensemble_model is None:
            raise ValueError("模型未加载")

        try:
            features_df = pd.DataFrame(features, columns=self.feature_names)
            probabilities = self.ensemble_model.predict_proba(features_df)

            if len(probabilities.shape) == 1:
                proba_malicious = probabilities
                proba_normal = 1 - probabilities
                probabilities = np.column_stack([proba_normal, proba_malicious])

            predictions = np.argmax(probabilities, axis=1)
            return predictions, probabilities

        except Exception as e:
            logging.error(f"Ensemble预测失败: {e}")
            raise


class TransformerPredictor:
    """Transformer模型预测器"""
    
    def __init__(self, model_path: str):
        self.model_path = model_path
        self.tokenizer = None
        self.model = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
    async def load_model(self):
        """加载Transformer模型"""
        try:
            transformer_path = os.path.join(self.model_path, "transformer_model")
            
            if os.path.exists(transformer_path):
                # 加载tokenizer和模型
                self.tokenizer = AutoTokenizer.from_pretrained(transformer_path)
                self.model = AutoModel.from_pretrained(transformer_path)
                self.model.to(self.device)
                self.model.eval()
                
                logging.info(f"Transformer模型加载成功: {transformer_path}")
            else:
                logging.warning(f"Transformer模型路径不存在: {transformer_path}")
                
        except Exception as e:
            logging.error(f"Transformer模型加载失败: {e}")
            raise
            
    def predict(self, texts: List[str], max_length: int = 512) -> np.ndarray:
        """预测文本特征"""
        if self.model is None or self.tokenizer is None:
            raise ValueError("Transformer模型未加载")
            
        try:
            # 文本编码
            encoded = self.tokenizer(
                texts,
                padding=True,
                truncation=True,
                max_length=max_length,
                return_tensors="pt"
            )
            
            # 移动到设备
            encoded = {k: v.to(self.device) for k, v in encoded.items()}
            
            # 推理
            with torch.no_grad():
                outputs = self.model(**encoded)
                # 使用[CLS]标记的隐藏状态作为文本表示
                embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
                
            return embeddings
            
        except Exception as e:
            logging.error(f"Transformer预测失败: {e}")
            raise


class ModelManager:
    """模型管理器"""
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.ensemble_predictor = EnsemblePredictor(settings.model_path)
        self.transformer_predictor = TransformerPredictor(settings.model_path)
        self.redis_client = None
        
    async def initialize(self):
        """初始化模型管理器"""
        try:
            if self.settings.enable_cache:
                self.redis_client = redis.from_url(
                    self.settings.redis_url,
                    db=self.settings.redis_db,
                    max_connections=self.settings.redis_max_connections
                )
                await self.redis_client.ping()
                logging.info("Redis连接成功")
            
            await self.ensemble_predictor.load_model()
            await self.transformer_predictor.load_model()
            
            logging.info("模型管理器初始化完成")
            
        except Exception as e:
            logging.error(f"模型管理器初始化失败: {e}")
            raise
            
    async def cleanup(self):
        """清理资源"""
        if self.redis_client:
            await self.redis_client.close()
            
    async def predict_traffic(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """预测流量风险"""
        try:
            features_dict = request_data.get("features", {})
            numerical_features = self._extract_numerical_features(features_dict)
            text_features = self._extract_text_features(features_dict)
            
            predictions, probabilities = self.ensemble_predictor.predict(
                numerical_features.reshape(1, -1)
            )
            
            result = {
                "is_malicious": bool(predictions[0]),
                "risk_score": float(probabilities[0][1]),
                "confidence": float(np.max(probabilities[0])),
                "model_version": "ensemble_v1.0",
                "features": {
                    "numerical_count": len(numerical_features),
                    "text_processed": len(text_features) > 0
                }
            }
            
            if len(text_features) > 0 and self.transformer_predictor.model is not None:
                text_embeddings = self.transformer_predictor.predict(text_features)
                result["features"]["text_embedding_dim"] = text_embeddings.shape[1]
                
            return result
            
        except Exception as e:
            logging.error(f"流量预测失败: {e}")
            raise
            
    def _extract_numerical_features(self, features_dict: Dict[str, Any]) -> np.ndarray:
        """从特征字典中提取数值特征"""
        if not self.xgboost_predictor.feature_names:
            logging.error("模型特征名称列表 (feature_names) 未加载。无法进行预测。")
            raise ValueError("模型特征名称未加载")

        ordered_features = []
        for feature_name in self.xgboost_predictor.feature_names:
            value = features_dict.get(feature_name, 0.0)
            ordered_features.append(float(value))
            
        return np.array(ordered_features)
        
    def _extract_text_features(self, features_dict: Dict[str, Any]) -> List[str]:
        """提取文本特征"""
        text_fields = ["url", "user_agent", "referer", "query_string"]
        texts = []
        
        for field in text_fields:
            if field in features_dict and features_dict[field]:
                texts.append(str(features_dict[field]))
                
        return texts
        
    async def get_cached_prediction(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """获取缓存的预测结果"""
        if not self.settings.enable_cache or not self.redis_client:
            return None
            
        try:
            cached = await self.redis_client.get(cache_key)
            if cached:
                return json.loads(cached)
        except Exception as e:
            logging.warning(f"获取缓存失败: {e}")
            
        return None
        
    async def cache_prediction(self, cache_key: str, result: Dict[str, Any]):
        """缓存预测结果"""
        if not self.settings.enable_cache or not self.redis_client:
            return
            
        try:
            await self.redis_client.setex(
                cache_key,
                self.settings.cache_ttl,
                json.dumps(result, ensure_ascii=False)
            )
        except Exception as e:
            logging.warning(f"缓存预测结果失败: {e}")