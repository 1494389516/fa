import hashlib
import json
import time
from typing import Dict, Any

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from .models import ModelManager
from .metrics import (
    PREDICTION_COUNTER, PREDICTION_DURATION, 
    CACHE_HIT_COUNTER, ERROR_COUNTER
)


router = APIRouter()


class PredictionRequest(BaseModel):
    """
    预测请求模型
    与 edge-gateway/lua/threat_detection.lua 中的 'factors' 对应
    """
    features: Dict[str, Any] = Field(description="从edge-gateway收集的特征")


class PredictionResponse(BaseModel):
    """预测响应模型"""
    is_malicious: bool = Field(description="是否为恶意流量")
    risk_score: float = Field(description="风险评分 (0-1)")
    confidence: float = Field(description="预测置信度")
    model_version: str = Field(description="模型版本")
    processing_time_ms: float = Field(description="处理时间(毫秒)")
    cached: bool = Field(default=False, description="是否来自缓存")
    features: Dict[str, Any] = Field(description="特征信息")


def get_model_manager() -> ModelManager:
    """获取模型管理器实例"""
    from .main import model_manager
    if model_manager is None:
        raise HTTPException(status_code=503, detail="模型管理器未初始化")
    return model_manager


@router.post("/predict", response_model=PredictionResponse)
async def predict_traffic(
    request: PredictionRequest,
    model_manager: ModelManager = Depends(get_model_manager)
):
    """预测流量风险"""
    start_time = time.time()
    
    try:
        # 生成缓存键
        cache_key = _generate_cache_key(request.dict())
        
        # 尝试从缓存获取结果
        cached_result = await model_manager.get_cached_prediction(cache_key)
        if cached_result:
            CACHE_HIT_COUNTER.inc()
            cached_result["cached"] = True
            cached_result["processing_time_ms"] = (time.time() - start_time) * 1000
            return PredictionResponse(**cached_result)
        
        # 执行预测
        result = await model_manager.predict_traffic(request.dict())
        
        # 添加处理时间
        processing_time = (time.time() - start_time) * 1000
        result["processing_time_ms"] = processing_time
        result["cached"] = False
        
        # 缓存结果
        await model_manager.cache_prediction(cache_key, result)
        
        # 更新指标
        PREDICTION_COUNTER.labels(
            model="xgboost",
            result="malicious" if result["is_malicious"] else "normal"
        ).inc()
        PREDICTION_DURATION.observe(processing_time / 1000)
        
        return PredictionResponse(**result)
        
    except Exception as e:
        ERROR_COUNTER.labels(endpoint="predict", error_type=type(e).__name__).inc()
        raise HTTPException(status_code=500, detail=f"预测失败: {str(e)}")


@router.post("/batch_predict")
async def batch_predict(
    requests: list[PredictionRequest],
    model_manager: ModelManager = Depends(get_model_manager)
):
    """批量预测流量风险"""
    if len(requests) > 100:
        raise HTTPException(status_code=400, detail="批量请求数量不能超过100")
    
    start_time = time.time()
    results = []
    
    try:
        for req in requests:
            result = await model_manager.predict_traffic(req.dict())
            results.append(result)
        
        processing_time = (time.time() - start_time) * 1000
        
        return {
            "results": results,
            "total_count": len(results),
            "processing_time_ms": processing_time
        }
        
    except Exception as e:
        ERROR_COUNTER.labels(endpoint="batch_predict", error_type=type(e).__name__).inc()
        raise HTTPException(status_code=500, detail=f"批量预测失败: {str(e)}")


@router.get("/health")
async def health_check(model_manager: ModelManager = Depends(get_model_manager)):
    """健康检查"""
    try:
        # 检查模型状态
        xgb_loaded = model_manager.xgboost_predictor.model is not None
        transformer_loaded = model_manager.transformer_predictor.model is not None
        
        # 检查Redis连接
        redis_connected = False
        if model_manager.redis_client:
            try:
                await model_manager.redis_client.ping()
                redis_connected = True
            except:
                pass
        
        return {
            "status": "healthy",
            "models": {
                "xgboost": "loaded" if xgb_loaded else "not_loaded",
                "transformer": "loaded" if transformer_loaded else "not_loaded"
            },
            "cache": {
                "redis": "connected" if redis_connected else "disconnected"
            },
            "timestamp": time.time()
        }
        
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"健康检查失败: {str(e)}")


@router.get("/models/info")
async def get_model_info(model_manager: ModelManager = Depends(get_model_manager)):
    """获取模型信息"""
    try:
        info = {
            "xgboost": {
                "loaded": model_manager.xgboost_predictor.model is not None,
                "feature_count": len(model_manager.xgboost_predictor.feature_names) 
                    if model_manager.xgboost_predictor.feature_names else 0,
                "scaler_loaded": model_manager.xgboost_predictor.scaler is not None
            },
            "transformer": {
                "loaded": model_manager.transformer_predictor.model is not None,
                "device": str(model_manager.transformer_predictor.device)
            }
        }
        
        return info
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取模型信息失败: {str(e)}")


def _generate_cache_key(request_data: Dict[str, Any]) -> str:
    """生成缓存键"""
    # 移除时间戳等变化字段
    cache_data = {k: v for k, v in request_data.items() if k != "timestamp"}
    
    # 生成MD5哈希
    data_str = json.dumps(cache_data, sort_keys=True, ensure_ascii=False)
    return f"prediction:{hashlib.md5(data_str.encode()).hexdigest()}"