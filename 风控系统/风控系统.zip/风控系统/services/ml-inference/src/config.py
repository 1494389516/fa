from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """应用配置"""
    
    # 服务配置
    host: str = "0.0.0.0"
    port: int = 8084
    workers: int = 1
    
    # 模型配置
    model_path: str = "/app/models"
    xgboost_model_file: str = "xgboost_model.json"
    transformer_model_path: str = "transformer_model"
    
    # Redis配置
    redis_url: str = "redis://redis:6379"
    redis_db: int = 0
    redis_max_connections: int = 10
    
    # 推理配置
    batch_size: int = 32
    max_sequence_length: int = 512
    confidence_threshold: float = 0.7
    
    # 缓存配置
    cache_ttl: int = 300  # 5分钟
    enable_cache: bool = True
    
    # 监控配置
    enable_metrics: bool = True
    metrics_port: int = 9090
    
    class Config:
        env_file = ".env"
        case_sensitive = False