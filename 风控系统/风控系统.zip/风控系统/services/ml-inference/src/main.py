import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Dict, Any

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app

from .config import Settings
from .models import ModelManager
from .handlers import router
from .metrics import setup_metrics


# 全局模型管理器
model_manager = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    global model_manager
    
    # 启动时初始化
    settings = Settings()
    model_manager = ModelManager(settings)
    await model_manager.initialize()
    
    # 设置监控指标
    setup_metrics()
    
    logging.info("ML推理服务启动完成")
    
    yield
    
    # 关闭时清理
    if model_manager:
        await model_manager.cleanup()
    logging.info("ML推理服务已关闭")


def create_app() -> FastAPI:
    """创建FastAPI应用"""
    app = FastAPI(
        title="恶意流量检测推理服务",
        description="基于XGBoost和Transformer的实时流量风险评估",
        version="1.0.0",
        lifespan=lifespan
    )
    
    # CORS中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # 注册路由
    app.include_router(router, prefix="/api/v1")
    
    # Prometheus监控端点
    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)
    
    return app


app = create_app()


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8084,
        reload=False,
        log_level="info"
    )