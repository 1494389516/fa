-- 速率控制模块
-- 实现基于滑动窗口的速率限制算法

local cjson = require "cjson"
local rate_limit_cache = ngx.shared.rate_limit_cache

-- 速率限制检查函数
local function check_rate_limit(key, limit, window, burst)
    local current_time = ngx.time()
    local window_start = current_time - (current_time % window)
    local cache_key = key .. ":" .. window_start
    
    -- 获取当前窗口的请求计数
    local current_requests, err = rate_limit_cache:get(cache_key)
    if not current_requests then
        current_requests = 0
    else
        current_requests = tonumber(current_requests) or 0
    end
    
    -- 检查是否超过限制
    if current_requests >= limit + burst then
        return false, current_requests, limit
    end
    
    -- 增加计数
    local new_count, err = rate_limit_cache:incr(cache_key, 1, 0, window)
    if not new_count then
        log_error("Failed to increment rate limit counter: " .. (err or "unknown error"))
        return true, current_requests, limit  -- 出错时允许通过
    end
    
    return true, new_count, limit
end

-- 获取客户端标识
local function get_client_key()
    local client_ip = get_client_ip()
    local user_agent = get_user_agent()
    
    -- 基于IP和User-Agent生成唯一标识
    return "rate_limit:" .. client_ip .. ":" .. ngx.md5(user_agent)
end

-- 获取API路径的速率限制配置
local function get_api_rate_limit(uri)
    local api_limits = {
        ["/api/login"] = {limit = 5, window = 300, burst = 2},    -- 5次/5分钟
        ["/api/register"] = {limit = 3, window = 3600, burst = 1}, -- 3次/小时
        ["/api/password/reset"] = {limit = 2, window = 3600, burst = 0}, -- 2次/小时
        ["/api/admin"] = {limit = 10, window = 60, burst = 5},     -- 10次/分钟
        ["/api/data"] = {limit = 100, window = 60, burst = 20},    -- 100次/分钟
    }
    
    -- 精确匹配
    if api_limits[uri] then
        return api_limits[uri]
    end
    
    -- 前缀匹配
    for pattern, limit_config in pairs(api_limits) do
        if string.find(uri, "^" .. pattern) then
            return limit_config
        end
    end
    
    -- 默认限制
    return {
        limit = config.rate_limit.default_rate,
        window = config.rate_limit.window,
        burst = config.rate_limit.burst
    }
end

-- 检查IP是否在白名单中
local function is_whitelisted_ip(ip)
    local whitelist = {
        "127.0.0.1",
        "::1",
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16"
    }
    
    for _, allowed_ip in ipairs(whitelist) do
        if ip == allowed_ip then
            return true
        end
        
        -- 简单的CIDR检查（仅支持常见的私有网络）
        if string.find(allowed_ip, "/") then
            local network, prefix = allowed_ip:match("([^/]+)/(%d+)")
            if network and prefix then
                -- 简化的网络匹配（实际应该使用更精确的CIDR计算）
                if string.find(ip, "^" .. network:gsub("%.", "%%."):gsub("0+$", "")) then
                    return true
                end
            end
        end
    end
    
    return false
end

-- 检查是否为搜索引擎爬虫
local function is_search_engine_bot(user_agent)
    local bot_patterns = {
        "Googlebot",
        "Bingbot", 
        "Slurp",
        "DuckDuckBot",
        "Baiduspider",
        "YandexBot",
        "facebookexternalhit"
    }
    
    if not user_agent then
        return false
    end
    
    for _, pattern in ipairs(bot_patterns) do
        if string.find(user_agent, pattern, 1, true) then
            return true
        end
    end
    
    return false
end

-- 自适应速率限制
local function get_adaptive_rate_limit(client_key, base_limit)
    local red = get_redis_connection()
    if not red then
        return base_limit
    end
    
    -- 获取客户端的历史行为评分
    local behavior_score, err = red:get("behavior_score:" .. client_key)
    if behavior_score and behavior_score ~= ngx.null then
        behavior_score = tonumber(behavior_score) or 1.0
        
        -- 根据行为评分调整速率限制
        if behavior_score > 0.8 then
            -- 良好行为，放宽限制
            base_limit.limit = math.floor(base_limit.limit * 1.5)
            base_limit.burst = math.floor(base_limit.burst * 1.2)
        elseif behavior_score < 0.3 then
            -- 可疑行为，收紧限制
            base_limit.limit = math.floor(base_limit.limit * 0.5)
            base_limit.burst = math.floor(base_limit.burst * 0.5)
        end
    end
    
    close_redis_connection(red)
    return base_limit
end

-- 记录速率限制事件
local function log_rate_limit_event(client_ip, uri, action, current_count, limit)
    local event = {
        timestamp = ngx.time(),
        client_ip = client_ip,
        user_agent = get_user_agent(),
        uri = uri,
        action = action,
        current_count = current_count,
        limit = limit,
        headers = ngx.req.get_headers()
    }
    
    -- 发送到Kafka进行进一步分析
    send_to_kafka("rate-limit-events", event)
    
    -- 记录到Nginx日志
    ngx.log(ngx.WARN, "[RateLimit] " .. action .. " for " .. client_ip .. 
            " on " .. uri .. " (" .. current_count .. "/" .. limit .. ")")
end

-- 主要的速率限制检查函数
local function perform_rate_limit_check()
    local client_ip = get_client_ip()
    local uri = ngx.var.uri
    local user_agent = get_user_agent()
    
    -- 白名单检查
    if is_whitelisted_ip(client_ip) then
        return true
    end
    
    -- 搜索引擎爬虫检查
    if is_search_engine_bot(user_agent) then
        -- 对搜索引擎爬虫使用更宽松的限制
        local bot_limit = {limit = 60, window = 60, burst = 10}
        local client_key = get_client_key()
        local allowed, current_count, limit = check_rate_limit(
            client_key, bot_limit.limit, bot_limit.window, bot_limit.burst
        )
        
        if not allowed then
            log_rate_limit_event(client_ip, uri, "rate_limited_bot", current_count, limit)
            ngx.status = 429
            ngx.header["Retry-After"] = bot_limit.window
            ngx.say('{"error":"Rate limit exceeded for bot","retry_after":' .. bot_limit.window .. '}')
            ngx.exit(429)
        end
        
        return true
    end
    
    -- 获取API特定的速率限制配置
    local rate_limit_config = get_api_rate_limit(uri)
    
    -- 自适应速率限制
    local client_key = get_client_key()
    rate_limit_config = get_adaptive_rate_limit(client_key, rate_limit_config)
    
    -- 执行速率限制检查
    local allowed, current_count, limit = check_rate_limit(
        client_key, 
        rate_limit_config.limit, 
        rate_limit_config.window, 
        rate_limit_config.burst
    )
    
    if not allowed then
        -- 记录速率限制事件
        log_rate_limit_event(client_ip, uri, "rate_limited", current_count, limit)
        
        -- 增加被限制请求的计数器
        local counter_key = "counter:rate_limited_requests"
        rate_limit_cache:incr(counter_key, 1, 0)
        
        -- 返回429状态码
        ngx.status = 429
        ngx.header["Retry-After"] = rate_limit_config.window
        ngx.header["X-RateLimit-Limit"] = rate_limit_config.limit
        ngx.header["X-RateLimit-Remaining"] = math.max(0, limit - current_count)
        ngx.header["X-RateLimit-Reset"] = ngx.time() + rate_limit_config.window
        
        ngx.say('{"error":"Rate limit exceeded","retry_after":' .. rate_limit_config.window .. 
                ',"limit":' .. rate_limit_config.limit .. 
                ',"remaining":' .. math.max(0, limit - current_count) .. '}')
        ngx.exit(429)
    end
    
    -- 添加速率限制头部信息
    ngx.header["X-RateLimit-Limit"] = rate_limit_config.limit
    ngx.header["X-RateLimit-Remaining"] = math.max(0, limit - current_count)
    ngx.header["X-RateLimit-Reset"] = ngx.time() + rate_limit_config.window
    
    return true
end

-- 导出函数
return {
    check = perform_rate_limit_check,
    check_rate_limit = check_rate_limit,
    get_client_key = get_client_key,
    is_whitelisted_ip = is_whitelisted_ip,
    is_search_engine_bot = is_search_engine_bot
}