-- 初始化脚本
-- 在 Nginx master 进程启动时执行一次

local cjson = require "cjson"

-- 全局配置
_G.config = {
    redis = {
        host = os.getenv("REDIS_HOST") or "redis",
        port = tonumber(os.getenv("REDIS_PORT")) or 6379,
        timeout = 1000,
        pool_size = 100,
        backlog = 100
    },
    kafka = {
        brokers = os.getenv("KAFKA_BROKERS") or "kafka:29092",
        topic = "traffic-events"
    },
    threat = {
        high_threshold = 0.8,
        medium_threshold = 0.5,
        low_threshold = 0.2,
        weights = {
            ml_score = 0.7, -- ML模型评分占主要权重
            asn_score = 0.05,
            ja3_suspicion = 0.1,
            user_agent_score = 0.05,
            behavior_score = 0.05,
            ip_reputation = 0.05,
            request_pattern = 0.05
        }
    },
    rate_limit = {
        default_rate = 100,  -- requests per minute
        burst = 20,
        window = 60  -- seconds
    },
    asn = {
        blocked_asns = {
            "AS12345",  -- 示例被封锁的ASN
            "AS67890"
        }
    }
}

-- 日志函数
function log_info(msg)
    ngx.log(ngx.INFO, "[EdgeGateway] " .. msg)
end

function log_error(msg)
    ngx.log(ngx.ERR, "[EdgeGateway] " .. msg)
end

function log_warn(msg)
    ngx.log(ngx.WARN, "[EdgeGateway] " .. msg)
end

-- 工具函数
function table_contains(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

function get_client_ip()
    local client_ip = ngx.var.http_x_forwarded_for
    if client_ip then
        -- 取第一个IP（如果有多个代理）
        client_ip = string.match(client_ip, "([^,]+)")
    else
        client_ip = ngx.var.remote_addr
    end
    return client_ip
end

function get_user_agent()
    return ngx.var.http_user_agent or ""
end

function get_ja3_fingerprint()
    -- 简化的JA3指纹提取（实际实现需要更复杂的SSL握手分析）
    local ssl_cipher = ngx.var.ssl_cipher
    local ssl_protocol = ngx.var.ssl_protocol
    
    if ssl_cipher and ssl_protocol then
        return ssl_protocol .. "-" .. ssl_cipher
    end
    
    return nil
end

-- Redis 连接池
function get_redis_connection()
    local redis = require "resty.redis"
    local red = redis:new()
    
    red:set_timeout(config.redis.timeout)
    
    local ok, err = red:connect(config.redis.host, config.redis.port)
    if not ok then
        log_error("Failed to connect to Redis: " .. err)
        return nil
    end
    
    return red
end

function close_redis_connection(red)
    if red then
        local ok, err = red:set_keepalive(10000, config.redis.pool_size)
        if not ok then
            log_error("Failed to set Redis keepalive: " .. err)
        end
    end
end

-- Kafka 生产者
function send_to_kafka(topic, message)
    -- 简化的Kafka发送（实际实现需要使用lua-resty-kafka）
    local red = get_redis_connection()
    if red then
        -- 使用Redis作为消息队列的临时方案
        local ok, err = red:lpush("kafka:" .. topic, cjson.encode(message))
        if not ok then
            log_error("Failed to send message to Kafka queue: " .. err)
        end
        close_redis_connection(red)
    end
end

-- 初始化完成日志
log_info("Edge Gateway initialized successfully")