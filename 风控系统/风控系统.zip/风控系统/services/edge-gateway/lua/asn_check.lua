-- ASN检查模块
-- 实现基于自治系统号(ASN)的流量封锁功能

local cjson = require "cjson"
local asn_cache = ngx.shared.asn_cache

-- IP到ASN的映射缓存时间（秒）
local ASN_CACHE_TTL = 3600

-- 获取IP的ASN信息
local function get_ip_asn(ip)
    -- 首先检查本地缓存
    local cache_key = "asn:" .. ip
    local cached_asn = asn_cache:get(cache_key)
    
    if cached_asn then
        return cached_asn
    end
    
    -- 从Redis获取ASN信息
    local red = get_redis_connection()
    if not red then
        return nil
    end
    
    local asn_info, err = red:get("ip_asn:" .. ip)
    if asn_info and asn_info ~= ngx.null then
        local asn_data = cjson.decode(asn_info)
        if asn_data and asn_data.asn then
            -- 缓存到本地
            asn_cache:set(cache_key, asn_data.asn, ASN_CACHE_TTL)
            close_redis_connection(red)
            return asn_data.asn
        end
    end
    
    -- 如果Redis中没有，尝试查询外部ASN数据库
    local asn = query_external_asn_database(ip, red)
    close_redis_connection(red)
    
    return asn
end

-- 查询外部ASN数据库（模拟实现）
local function query_external_asn_database(ip, red)
    -- 这里应该调用真实的ASN查询服务，如MaxMind GeoIP2或类似服务
    -- 为了演示，我们使用一些预定义的映射
    
    local ip_asn_mapping = {
        -- 示例映射（实际应该从真实的ASN数据库获取）
        ["192.168.1.0/24"] = "AS65001",
        ["10.0.0.0/8"] = "AS65002",
        ["172.16.0.0/12"] = "AS65003",
        ["203.0.113.0/24"] = "AS12345",  -- 示例恶意ASN
        ["198.51.100.0/24"] = "AS67890", -- 示例恶意ASN
    }
    
    -- 简化的IP网段匹配
    for network, asn in pairs(ip_asn_mapping) do
        local network_ip, prefix = network:match("([^/]+)/(%d+)")
        if network_ip and prefix then
            -- 简化的网络匹配（实际应该使用更精确的CIDR计算）
            local network_parts = {}
            for part in network_ip:gmatch("(%d+)") do
                table.insert(network_parts, tonumber(part))
            end
            
            local ip_parts = {}
            for part in ip:gmatch("(%d+)") do
                table.insert(ip_parts, tonumber(part))
            end
            
            -- 简单的前缀匹配
            local prefix_bytes = math.floor(tonumber(prefix) / 8)
            local match = true
            for i = 1, prefix_bytes do
                if network_parts[i] ~= ip_parts[i] then
                    match = false
                    break
                end
            end
            
            if match then
                -- 缓存结果到Redis
                if red then
                    local asn_data = {
                        asn = asn,
                        network = network,
                        timestamp = ngx.time()
                    }
                    red:setex("ip_asn:" .. ip, ASN_CACHE_TTL, cjson.encode(asn_data))
                end
                
                -- 缓存到本地
                asn_cache:set("asn:" .. ip, asn, ASN_CACHE_TTL)
                
                return asn
            end
        end
    end
    
    -- 如果没有找到匹配的ASN，返回未知
    local unknown_asn = "AS0"
    asn_cache:set("asn:" .. ip, unknown_asn, ASN_CACHE_TTL)
    return unknown_asn
end

-- 检查ASN是否被封锁
local function is_asn_blocked(asn)
    if not asn or asn == "AS0" then
        return false
    end
    
    -- 检查静态封锁列表
    if table_contains(config.asn.blocked_asns, asn) then
        return true
    end
    
    -- 检查动态封锁列表（从Redis获取）
    local red = get_redis_connection()
    if red then
        local is_blocked, err = red:sismember("blocked_asns", asn)
        close_redis_connection(red)
        
        if is_blocked and is_blocked == 1 then
            return true
        end
    end
    
    return false
end

-- 获取ASN的威胁评分
local function get_asn_threat_score(asn)
    if not asn or asn == "AS0" then
        return 0.0
    end
    
    local red = get_redis_connection()
    if not red then
        return 0.0
    end
    
    local threat_score, err = red:get("asn_threat_score:" .. asn)
    close_redis_connection(red)
    
    if threat_score and threat_score ~= ngx.null then
        return tonumber(threat_score) or 0.0
    end
    
    return 0.0
end

-- 记录ASN相关事件
local function log_asn_event(client_ip, asn, action, threat_score)
    local event = {
        timestamp = ngx.time(),
        client_ip = client_ip,
        asn = asn,
        action = action,
        threat_score = threat_score,
        user_agent = get_user_agent(),
        uri = ngx.var.uri,
        headers = ngx.req.get_headers()
    }
    
    -- 发送到Kafka进行进一步分析
    send_to_kafka("asn-events", event)
    
    -- 记录到Nginx日志
    ngx.log(ngx.WARN, "[ASN] " .. action .. " for IP " .. client_ip .. 
            " (ASN: " .. asn .. ", Score: " .. threat_score .. ")")
end

-- 更新ASN统计信息
local function update_asn_stats(asn, action)
    local red = get_redis_connection()
    if not red then
        return
    end
    
    local stats_key = "asn_stats:" .. asn
    local current_time = ngx.time()
    local hour_key = stats_key .. ":" .. math.floor(current_time / 3600)
    
    -- 更新小时统计
    red:hincrby(hour_key, "total_requests", 1)
    red:hincrby(hour_key, action .. "_requests", 1)
    red:expire(hour_key, 86400) -- 24小时过期
    
    -- 更新总体统计
    red:hincrby(stats_key, "total_requests", 1)
    red:hincrby(stats_key, action .. "_requests", 1)
    
    close_redis_connection(red)
end

-- 检查ASN是否需要临时封锁
local function check_asn_auto_block(asn)
    local red = get_redis_connection()
    if not red then
        return false
    end
    
    local stats_key = "asn_stats:" .. asn
    local current_time = ngx.time()
    local hour_key = stats_key .. ":" .. math.floor(current_time / 3600)
    
    -- 获取最近一小时的统计
    local stats = red:hmget(hour_key, "total_requests", "blocked_requests", "challenged_requests")
    close_redis_connection(red)
    
    if stats and #stats >= 3 then
        local total = tonumber(stats[1]) or 0
        local blocked = tonumber(stats[2]) or 0
        local challenged = tonumber(stats[3]) or 0
        
        -- 如果总请求数超过阈值且恶意请求比例过高，则临时封锁
        if total > 100 and (blocked + challenged) / total > 0.8 then
            -- 添加到临时封锁列表
            local red2 = get_redis_connection()
            if red2 then
                red2:sadd("temp_blocked_asns", asn)
                red2:expire("temp_blocked_asns", 3600) -- 1小时临时封锁
                close_redis_connection(red2)
                
                log_info("ASN " .. asn .. " temporarily blocked due to high malicious activity")
                return true
            end
        end
    end
    
    return false
end

-- 主要的ASN检查函数
local function perform_asn_check()
    local client_ip = get_client_ip()
    
    -- 跳过内网IP
    if string.find(client_ip, "^192%.168%.") or 
       string.find(client_ip, "^10%.") or 
       string.find(client_ip, "^172%.1[6-9]%.") or
       string.find(client_ip, "^172%.2[0-9]%.") or
       string.find(client_ip, "^172%.3[0-1]%.") or
       client_ip == "127.0.0.1" then
        return true
    end
    
    -- 获取IP的ASN
    local asn = get_ip_asn(client_ip)
    if not asn then
        log_warn("Failed to get ASN for IP: " .. client_ip)
        return true -- 获取失败时允许通过
    end
    
    -- 设置ASN变量供日志使用
    ngx.var.asn = asn
    
    -- 检查是否被封锁
    if is_asn_blocked(asn) then
        log_asn_event(client_ip, asn, "blocked", 1.0)
        update_asn_stats(asn, "blocked")
        
        -- 增加被封锁请求的计数器
        local counter_key = "counter:asn_blocked_requests"
        asn_cache:incr(counter_key, 1, 0)
        
        ngx.status = 403
        ngx.header["X-Block-Reason"] = "ASN blocked"
        ngx.say('{"error":"Access denied","reason":"ASN blocked","asn":"' .. asn .. '"}')
        ngx.exit(403)
    end
    
    -- 检查临时封锁
    local red = get_redis_connection()
    if red then
        local is_temp_blocked, err = red:sismember("temp_blocked_asns", asn)
        close_redis_connection(red)
        
        if is_temp_blocked and is_temp_blocked == 1 then
            log_asn_event(client_ip, asn, "temp_blocked", 0.9)
            update_asn_stats(asn, "temp_blocked")
            
            ngx.status = 403
            ngx.header["X-Block-Reason"] = "ASN temporarily blocked"
            ngx.say('{"error":"Access temporarily denied","reason":"ASN temporarily blocked","asn":"' .. asn .. '"}')
            ngx.exit(403)
        end
    end
    
    -- 获取ASN威胁评分
    local threat_score = get_asn_threat_score(asn)
    if threat_score > 0.5 then
        -- 高威胁ASN，记录但不阻断（由后续威胁检测处理）
        log_asn_event(client_ip, asn, "high_threat", threat_score)
        ngx.var.asn_threat_score = threat_score
    end
    
    -- 检查是否需要自动封锁
    check_asn_auto_block(asn)
    
    -- 更新统计
    update_asn_stats(asn, "allowed")
    
    return true
end

-- 导出函数
return {
    check = perform_asn_check,
    get_ip_asn = get_ip_asn,
    is_asn_blocked = is_asn_blocked,
    get_asn_threat_score = get_asn_threat_score
}