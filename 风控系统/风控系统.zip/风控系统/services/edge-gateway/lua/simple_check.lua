-- 简单检查模块
-- 用于静态资源等低风险路径的轻量级检查

local rate_limit = require "rate_limit"

-- 简单的恶意User-Agent检查
local function check_malicious_user_agent()
    local user_agent = get_user_agent()
    
    if not user_agent or user_agent == "" then
        -- 缺少User-Agent，可疑但不阻断
        ngx.log(ngx.WARN, "[SimpleCheck] Missing User-Agent from " .. get_client_ip())
        return true
    end
    
    -- 明显恶意的User-Agent模式
    local malicious_patterns = {
        "sqlmap",
        "nikto",
        "nmap",
        "masscan",
        "nessus",
        "openvas",
        "w3af",
        "havij",
        "pangolin",
        "jsunpack",
        "python%-urllib",
        "python%-requests/[0-9]",
        "curl/[0-9]",
        "wget/[0-9]",
        "libwww",
        "lwp%-trivial",
        "^Mozilla/[0-9]%.[0-9]$",  -- 过于简单的Mozilla标识
        "test",
        "scanner",
        "bot.*bot",
        "crawler.*crawler"
    }
    
    for _, pattern in ipairs(malicious_patterns) do
        if ngx.re.match(user_agent, pattern, "joi") then
            ngx.log(ngx.WARN, "[SimpleCheck] Malicious User-Agent detected: " .. user_agent)
            
            -- 记录事件
            local event = {
                timestamp = ngx.time(),
                client_ip = get_client_ip(),
                user_agent = user_agent,
                uri = ngx.var.uri,
                action = "blocked_malicious_ua",
                pattern = pattern
            }
            send_to_kafka("simple-check-events", event)
            
            ngx.status = 403
            ngx.header["X-Block-Reason"] = "Malicious User-Agent"
            ngx.say('{"error":"Access denied","reason":"Malicious User-Agent detected"}')
            ngx.exit(403)
        end
    end
    
    return true
end

-- 检查请求方法
local function check_request_method()
    local method = ngx.req.get_method()
    local uri = ngx.var.uri
    
    -- 静态资源只允许GET和HEAD方法
    if string.find(uri, "^/static/") then
        if method ~= "GET" and method ~= "HEAD" then
            ngx.log(ngx.WARN, "[SimpleCheck] Invalid method " .. method .. " for static resource")
            
            ngx.status = 405
            ngx.header["Allow"] = "GET, HEAD"
            ngx.say('{"error":"Method not allowed","allowed_methods":["GET","HEAD"]}')
            ngx.exit(405)
        end
    end
    
    -- 检查危险的HTTP方法
    local dangerous_methods = {"TRACE", "TRACK", "DEBUG", "CONNECT"}
    for _, dangerous_method in ipairs(dangerous_methods) do
        if method == dangerous_method then
            ngx.log(ngx.WARN, "[SimpleCheck] Dangerous HTTP method: " .. method)
            
            ngx.status = 405
            ngx.header["Allow"] = "GET, POST, PUT, DELETE, HEAD, OPTIONS"
            ngx.say('{"error":"Method not allowed"}')
            ngx.exit(405)
        end
    end
    
    return true
end

-- 检查请求头
local function check_request_headers()
    local headers = ngx.req.get_headers()
    
    -- 检查Host头
    local host = headers["host"]
    if not host then
        ngx.log(ngx.WARN, "[SimpleCheck] Missing Host header")
        ngx.status = 400
        ngx.say('{"error":"Bad request","reason":"Missing Host header"}')
        ngx.exit(400)
    end
    
    -- 检查异常的Content-Length
    local content_length = headers["content-length"]
    if content_length then
        local length = tonumber(content_length)
        if length and length > 10 * 1024 * 1024 then -- 10MB
            ngx.log(ngx.WARN, "[SimpleCheck] Excessive Content-Length: " .. content_length)
            ngx.status = 413
            ngx.say('{"error":"Payload too large"}')
            ngx.exit(413)
        end
    end
    
    -- 检查可疑的头部
    local suspicious_headers = {
        "x-forwarded-host",
        "x-original-url", 
        "x-rewrite-url",
        "x-real-ip"
    }
    
    for _, header_name in ipairs(suspicious_headers) do
        if headers[header_name] then
            local header_value = headers[header_name]
            -- 检查头部值是否包含可疑内容
            if string.find(header_value, "%.%.") or  -- 路径遍历
               string.find(header_value, "<script") or -- XSS
               string.find(header_value, "javascript:") then
                
                ngx.log(ngx.WARN, "[SimpleCheck] Suspicious header " .. header_name .. ": " .. header_value)
                
                ngx.status = 400
                ngx.say('{"error":"Bad request","reason":"Suspicious header detected"}')
                ngx.exit(400)
            end
        end
    end
    
    return true
end

-- 检查URI
local function check_request_uri()
    local uri = ngx.var.uri
    local args = ngx.var.args
    
    -- 检查路径遍历攻击
    if string.find(uri, "%.%.") or string.find(uri, "%%2e%%2e") then
        ngx.log(ngx.WARN, "[SimpleCheck] Path traversal attempt: " .. uri)
        
        ngx.status = 400
        ngx.say('{"error":"Bad request","reason":"Path traversal detected"}')
        ngx.exit(400)
    end
    
    -- 检查SQL注入模式
    local sql_patterns = {
        "union.*select",
        "select.*from",
        "insert.*into",
        "delete.*from",
        "update.*set",
        "drop.*table",
        "exec.*xp_",
        "sp_.*password"
    }
    
    local full_uri = uri
    if args then
        full_uri = uri .. "?" .. args
    end
    
    for _, pattern in ipairs(sql_patterns) do
        if ngx.re.match(full_uri, pattern, "joi") then
            ngx.log(ngx.WARN, "[SimpleCheck] SQL injection attempt: " .. full_uri)
            
            ngx.status = 400
            ngx.say('{"error":"Bad request","reason":"SQL injection detected"}')
            ngx.exit(400)
        end
    end
    
    -- 检查XSS模式
    local xss_patterns = {
        "<script",
        "javascript:",
        "vbscript:",
        "onload=",
        "onerror=",
        "onclick="
    }
    
    for _, pattern in ipairs(xss_patterns) do
        if string.find(full_uri:lower(), pattern) then
            ngx.log(ngx.WARN, "[SimpleCheck] XSS attempt: " .. full_uri)
            
            ngx.status = 400
            ngx.say('{"error":"Bad request","reason":"XSS detected"}')
            ngx.exit(400)
        end
    end
    
    return true
end

-- 简单的频率检查
local function check_simple_rate_limit()
    local client_ip = get_client_ip()
    
    -- 对静态资源使用更宽松的限制
    local uri = ngx.var.uri
    if string.find(uri, "^/static/") then
        local limit_config = {limit = 200, window = 60, burst = 50}
        local client_key = "simple_rate:" .. client_ip
        
        local allowed, current_count, limit = rate_limit.check_rate_limit(
            client_key, limit_config.limit, limit_config.window, limit_config.burst
        )
        
        if not allowed then
            ngx.log(ngx.WARN, "[SimpleCheck] Rate limit exceeded for static resources: " .. client_ip)
            
            ngx.status = 429
            ngx.header["Retry-After"] = limit_config.window
            ngx.say('{"error":"Rate limit exceeded"}')
            ngx.exit(429)
        end
    end
    
    return true
end

-- 主要的简单检查函数
local function perform_simple_check()
    -- 执行各项检查
    check_malicious_user_agent()
    check_request_method()
    check_request_headers()
    check_request_uri()
    check_simple_rate_limit()
    
    -- 记录正常访问
    local event = {
        timestamp = ngx.time(),
        client_ip = get_client_ip(),
        user_agent = get_user_agent(),
        uri = ngx.var.uri,
        method = ngx.req.get_method(),
        action = "allowed"
    }
    
    -- 只记录部分正常访问（避免日志过多）
    if math.random() < 0.01 then -- 1%的采样率
        send_to_kafka("simple-check-events", event)
    end
    
    return true
end

-- 导出函数
return {
    check = perform_simple_check,
    check_malicious_user_agent = check_malicious_user_agent,
    check_request_method = check_request_method,
    check_request_headers = check_request_headers,
    check_request_uri = check_request_uri
}