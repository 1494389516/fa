-- 请求行为分析模块
-- 用于检测客户端的异常行为模式，如扫描、机器人等

local cjson = require "cjson"

local M = {}

-- 分析请求行为模式
function M.analyze(client_key)
    local red = get_redis_connection()
    if not red then
        return 0.0, {}
    end
    
    local behavior_score = 0.0
    local patterns = {}
    
    -- 获取最近的请求历史
    local history_key = "request_history:" .. client_key
    local recent_requests = red:lrange(history_key, 0, 99) -- 最近100个请求
    
    if recent_requests and #recent_requests > 10 then
        local request_intervals = {}
        local uri_patterns = {}
        local method_counts = {}
        
        -- 分析请求间隔
        local prev_timestamp = nil
        for _, request_data in ipairs(recent_requests) do
            local success, request = pcall(cjson.decode, request_data)
            if success and request and request.timestamp then
                if prev_timestamp then
                    local interval = request.timestamp - prev_timestamp
                    table.insert(request_intervals, interval)
                end
                prev_timestamp = request.timestamp
                
                -- 统计URI模式
                if request.uri then
                    uri_patterns[request.uri] = (uri_patterns[request.uri] or 0) + 1
                end
                
                -- 统计请求方法
                if request.method then
                    method_counts[request.method] = (method_counts[request.method] or 0) + 1
                end
            end
        end
        
        -- 检查请求间隔是否过于规律（机器人行为）
        if #request_intervals > 5 then
            local avg_interval = 0
            for _, interval in ipairs(request_intervals) do
                avg_interval = avg_interval + interval
            end
            avg_interval = avg_interval / #request_intervals
            
            local variance = 0
            for _, interval in ipairs(request_intervals) do
                variance = variance + (interval - avg_interval) ^ 2
            end
            variance = variance / #request_intervals
            
            -- 如果方差很小，说明请求间隔很规律
            if variance < 1 and avg_interval < 10 then
                behavior_score = math.max(behavior_score, 0.6)
                table.insert(patterns, "请求间隔过于规律 (机器人行为)")
            end
        end
        
        -- 检查URI访问模式
        local unique_uris = 0
        local max_uri_count = 0
        for uri, count in pairs(uri_patterns) do
            unique_uris = unique_uris + 1
            max_uri_count = math.max(max_uri_count, count)
        end
        
        -- 如果重复访问同一URI过多
        if max_uri_count > #recent_requests * 0.8 then
            behavior_score = math.max(behavior_score, 0.4)
            table.insert(patterns, "重复访问同一URI")
        end
        
        -- 如果访问的URI过于分散（扫描行为）
        if unique_uris > #recent_requests * 0.9 and unique_uris > 20 then
            behavior_score = math.max(behavior_score, 0.5)
            table.insert(patterns, "访问URI过于分散 (扫描行为)")
        end
        
        -- 检查HTTP方法分布
        local post_ratio = (method_counts["POST"] or 0) / #recent_requests
        local get_ratio = (method_counts["GET"] or 0) / #recent_requests
        
        if post_ratio > 0.8 then
            behavior_score = math.max(behavior_score, 0.3)
            table.insert(patterns, "POST请求比例过高")
        end
        
        -- 检查是否有异常的HTTP方法
        for method, count in pairs(method_counts) do
            if method ~= "GET" and method ~= "POST" and method ~= "PUT" and method ~= "DELETE" and method ~= "HEAD" and method ~= "OPTIONS" then
                behavior_score = math.max(behavior_score, 0.4)
                table.insert(patterns, "使用异常HTTP方法: " .. method)
            end
        end
    end
    
    close_redis_connection(red)
    return behavior_score, patterns
end

return M