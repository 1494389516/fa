-- JA3指纹识别模块
-- 实现SSL/TLS客户端指纹识别和分析

local cjson = require "cjson"
local ja3_cache = ngx.shared.ja3_cache

-- JA3指纹缓存时间（秒）
local JA3_CACHE_TTL = 3600

-- 提取JA3指纹
local function extract_ja3_fingerprint()
    -- 获取SSL相关信息
    local ssl_protocol = ngx.var.ssl_protocol
    local ssl_cipher = ngx.var.ssl_cipher
    local ssl_curves = ngx.var.ssl_curves
    local ssl_point_formats = ngx.var.ssl_point_formats
    
    -- 如果不是HTTPS连接，返回nil
    if not ssl_protocol or not ssl_cipher then
        return nil
    end
    
    -- 简化的JA3指纹生成（实际实现需要更复杂的SSL握手分析）
    -- 真实的JA3需要解析ClientHello消息中的具体字段
    local ja3_string = ssl_protocol .. "," .. ssl_cipher
    
    if ssl_curves then
        ja3_string = ja3_string .. "," .. ssl_curves
    end
    
    if ssl_point_formats then
        ja3_string = ja3_string .. "," .. ssl_point_formats
    end
    
    -- 生成MD5哈希作为JA3指纹
    local ja3_hash = ngx.md5(ja3_string)
    
    return {
        hash = ja3_hash,
        raw = ja3_string,
        protocol = ssl_protocol,
        cipher = ssl_cipher,
        curves = ssl_curves,
        point_formats = ssl_point_formats
    }
end

-- 获取已知的恶意JA3指纹库
local function get_malicious_ja3_database()
    -- 这里应该从外部威胁情报源获取最新的恶意JA3指纹
    -- 为了演示，使用一些已知的恶意工具JA3指纹
    return {
        -- Metasploit
        ["769,47-53-5-10-49161-49162-49171-49172-50-56-19-4,0-10-11,23-24-25,0"] = {
            name = "Metasploit",
            category = "penetration_testing",
            threat_level = "high",
            description = "Metasploit framework SSL fingerprint"
        },
        
        -- Nmap
        ["771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-21,29-23-24,0"] = {
            name = "Nmap",
            category = "network_scanner",
            threat_level = "medium",
            description = "Nmap network scanner SSL fingerprint"
        },
        
        -- Burp Suite
        ["772,4865-4867-4866-49195-49199-52393-52392-49196-49200-49162-49161-49171-49172-51-57-47-53,0-23-65281-10-11-35-16-5-51-43-13-45-28-21,29-23-24,0"] = {
            name = "Burp Suite",
            category = "web_scanner",
            threat_level = "high",
            description = "Burp Suite web application scanner"
        },
        
        -- Python requests (常见的自动化工具)
        ["771,4866-4867-4865-49196-49200-159-52393-52392-52394-49195-49199-158-49188-49192-107-49187-49191-103-49162-49172-57-49161-49171-51-157-156-61-60-53-47-255,0-11-10-35-22-23-13-43-45-51,29-23-30-25-24,0"] = {
            name = "Python requests",
            category = "automation_tool",
            threat_level = "medium",
            description = "Python requests library default SSL configuration"
        }
    }
end

-- 检查JA3指纹是否为已知恶意指纹
local function is_malicious_ja3(ja3_hash, ja3_raw)
    local malicious_db = get_malicious_ja3_database()
    
    -- 检查哈希匹配
    if malicious_db[ja3_hash] then
        return true, malicious_db[ja3_hash]
    end
    
    -- 检查原始字符串匹配
    if malicious_db[ja3_raw] then
        return true, malicious_db[ja3_raw]
    end
    
    -- 从Redis获取动态更新的恶意JA3库
    local red = get_redis_connection()
    if red then
        local is_malicious, err = red:sismember("malicious_ja3", ja3_hash)
        if is_malicious and is_malicious == 1 then
            -- 获取详细信息
            local info_str, err = red:get("ja3_info:" .. ja3_hash)
            local info = {}
            if info_str and info_str ~= ngx.null then
                info = cjson.decode(info_str) or {}
            end
            close_redis_connection(red)
            return true, info
        end
        close_redis_connection(red)
    end
    
    return false, nil
end

-- 分析JA3指纹的可疑程度
local function analyze_ja3_suspicion(ja3_info)
    local suspicion_score = 0.0
    local reasons = {}
    
    if not ja3_info then
        return suspicion_score, reasons
    end
    
    -- 检查SSL协议版本
    if ja3_info.protocol then
        if ja3_info.protocol == "SSLv2" or ja3_info.protocol == "SSLv3" then
            suspicion_score = suspicion_score + 0.3
            table.insert(reasons, "使用过时的SSL协议: " .. ja3_info.protocol)
        elseif ja3_info.protocol == "TLSv1" or ja3_info.protocol == "TLSv1.1" then
            suspicion_score = suspicion_score + 0.1
            table.insert(reasons, "使用较旧的TLS协议: " .. ja3_info.protocol)
        end
    end
    
    -- 检查加密套件
    if ja3_info.cipher then
        -- 弱加密套件
        local weak_ciphers = {
            "RC4", "DES", "3DES", "MD5", "NULL"
        }
        
        for _, weak_cipher in ipairs(weak_ciphers) do
            if string.find(ja3_info.cipher, weak_cipher) then
                suspicion_score = suspicion_score + 0.2
                table.insert(reasons, "使用弱加密套件: " .. weak_cipher)
            end
        end
    end
    
    -- 检查是否为常见的自动化工具指纹
    local automation_patterns = {
        "python", "curl", "wget", "libwww", "java", "go-http-client"
    }
    
    local user_agent = get_user_agent():lower()
    for _, pattern in ipairs(automation_patterns) do
        if string.find(user_agent, pattern) then
            suspicion_score = suspicion_score + 0.15
            table.insert(reasons, "自动化工具User-Agent: " .. pattern)
            break
        end
    end
    
    -- 检查JA3指纹的稀有程度
    local red = get_redis_connection()
    if red then
        local count, err = red:get("ja3_count:" .. ja3_info.hash)
        if count and count ~= ngx.null then
            count = tonumber(count) or 0
            if count < 10 then
                suspicion_score = suspicion_score + 0.1
                table.insert(reasons, "罕见的JA3指纹 (出现次数: " .. count .. ")")
            end
        else
            suspicion_score = suspicion_score + 0.05
            table.insert(reasons, "首次出现的JA3指纹")
        end
        close_redis_connection(red)
    end
    
    return math.min(suspicion_score, 1.0), reasons
end

-- 更新JA3指纹统计
local function update_ja3_stats(ja3_hash)
    local red = get_redis_connection()
    if not red then
        return
    end
    
    -- 增加JA3指纹出现次数
    red:incr("ja3_count:" .. ja3_hash)
    red:expire("ja3_count:" .. ja3_hash, 86400 * 30) -- 30天过期
    
    -- 记录最近出现时间
    red:set("ja3_last_seen:" .. ja3_hash, ngx.time())
    red:expire("ja3_last_seen:" .. ja3_hash, 86400 * 30)
    
    -- 更新小时统计
    local hour_key = "ja3_hourly:" .. math.floor(ngx.time() / 3600)
    red:sadd(hour_key, ja3_hash)
    red:expire(hour_key, 86400) -- 24小时过期
    
    close_redis_connection(red)
end

-- 记录JA3相关事件
local function log_ja3_event(client_ip, ja3_info, action, threat_info, suspicion_score)
    local event = {
        timestamp = ngx.time(),
        client_ip = client_ip,
        user_agent = get_user_agent(),
        uri = ngx.var.uri,
        ja3_hash = ja3_info.hash,
        ja3_raw = ja3_info.raw,
        ssl_protocol = ja3_info.protocol,
        ssl_cipher = ja3_info.cipher,
        action = action,
        threat_info = threat_info,
        suspicion_score = suspicion_score
    }
    
    -- 发送到Kafka进行进一步分析
    send_to_kafka("ja3-events", event)
    
    -- 记录到Nginx日志
    ngx.log(ngx.WARN, "[JA3] " .. action .. " for IP " .. client_ip .. 
            " (JA3: " .. ja3_info.hash .. ", Score: " .. suspicion_score .. ")")
end

-- 协议异常检测
local function detect_protocol_anomalies()
    local anomalies = {}
    local headers = ngx.req.get_headers()
    
    -- 检查HTTP版本异常
    local http_version = ngx.var.server_protocol
    if http_version == "HTTP/0.9" then
        table.insert(anomalies, {
            type = "http_version",
            severity = "medium",
            description = "使用过时的HTTP/0.9协议"
        })
    end
    
    -- 检查请求头异常
    local header_anomalies = {
        -- 缺少常见头部
        {header = "accept", severity = "low", desc = "缺少Accept头部"},
        {header = "accept-language", severity = "low", desc = "缺少Accept-Language头部"},
        {header = "accept-encoding", severity = "low", desc = "缺少Accept-Encoding头部"},
    }
    
    for _, check in ipairs(header_anomalies) do
        if not headers[check.header] then
            table.insert(anomalies, {
                type = "missing_header",
                severity = check.severity,
                description = check.desc
            })
        end
    end
    
    -- 检查异常的头部顺序（简化实现）
    local expected_order = {"host", "user-agent", "accept", "accept-language", "accept-encoding", "connection"}
    local actual_headers = {}
    for name, _ in pairs(headers) do
        table.insert(actual_headers, name:lower())
    end
    
    -- 检查是否有异常的头部组合
    if headers["x-forwarded-for"] and not headers["x-real-ip"] then
        table.insert(anomalies, {
            type = "header_combination",
            severity = "low",
            description = "存在X-Forwarded-For但缺少X-Real-IP"
        })
    end
    
    -- 检查Content-Type与请求方法的匹配
    local method = ngx.req.get_method()
    local content_type = headers["content-type"]
    
    if method == "GET" and content_type then
        table.insert(anomalies, {
            type = "method_content_type",
            severity = "medium",
            description = "GET请求包含Content-Type头部"
        })
    end
    
    if (method == "POST" or method == "PUT") and not content_type then
        table.insert(anomalies, {
            type = "method_content_type",
            severity = "low",
            description = method .. "请求缺少Content-Type头部"
        })
    end
    
    return anomalies
end

-- 主要的JA3检查函数
local function perform_ja3_check()
    local client_ip = get_client_ip()
    
    -- 提取JA3指纹
    local ja3_info = extract_ja3_fingerprint()
    
    -- 如果不是HTTPS连接，跳过JA3检查但仍进行协议检测
    if not ja3_info then
        -- 进行HTTP协议异常检测
        local anomalies = detect_protocol_anomalies()
        if #anomalies > 0 then
            local high_severity_count = 0
            for _, anomaly in ipairs(anomalies) do
                if anomaly.severity == "high" then
                    high_severity_count = high_severity_count + 1
                end
            end
            
            -- 如果有高严重性异常，记录事件
            if high_severity_count > 0 then
                local event = {
                    timestamp = ngx.time(),
                    client_ip = client_ip,
                    user_agent = get_user_agent(),
                    uri = ngx.var.uri,
                    anomalies = anomalies,
                    action = "protocol_anomaly_detected"
                }
                send_to_kafka("protocol-anomaly-events", event)
            end
        end
        
        return true
    end
    
    -- 设置JA3变量供日志使用
    ngx.var.ssl_ja3 = ja3_info.hash
    
    -- 检查是否为已知恶意JA3指纹
    local is_malicious, threat_info = is_malicious_ja3(ja3_info.hash, ja3_info.raw)
    
    if is_malicious then
        log_ja3_event(client_ip, ja3_info, "blocked_malicious_ja3", threat_info, 1.0)
        
        -- 增加被阻断请求的计数器
        local counter_key = "counter:ja3_blocked_requests"
        ja3_cache:incr(counter_key, 1, 0)
        
        ngx.status = 403
        ngx.header["X-Block-Reason"] = "Malicious JA3 fingerprint"
        ngx.say('{"error":"Access denied","reason":"Malicious SSL fingerprint detected","ja3":"' .. ja3_info.hash .. '"}')
        ngx.exit(403)
    end
    
    -- 分析JA3指纹的可疑程度
    local suspicion_score, reasons = analyze_ja3_suspicion(ja3_info)
    
    -- 如果可疑程度较高，记录但不阻断（由后续威胁检测处理）
    if suspicion_score > 0.5 then
        log_ja3_event(client_ip, ja3_info, "suspicious_ja3", {reasons = reasons}, suspicion_score)
        ngx.var.ja3_suspicion_score = suspicion_score
    end
    
    -- 更新JA3统计
    update_ja3_stats(ja3_info.hash)
    
    -- 进行协议异常检测
    local anomalies = detect_protocol_anomalies()
    if #anomalies > 0 then
        local event = {
            timestamp = ngx.time(),
            client_ip = client_ip,
            user_agent = get_user_agent(),
            uri = ngx.var.uri,
            ja3_hash = ja3_info.hash,
            anomalies = anomalies,
            action = "protocol_anomaly_with_ja3"
        }
        send_to_kafka("protocol-anomaly-events", event)
    end
    
    return true
end

-- 导出函数
return {
    check = perform_ja3_check,
    extract_ja3_fingerprint = extract_ja3_fingerprint,
    is_malicious_ja3 = is_malicious_ja3,
    analyze_ja3_suspicion = analyze_ja3_suspicion,
    detect_protocol_anomalies = detect_protocol_anomalies
}