-- User-Agent 分析模块
-- 用于检测 User-Agent 中的异常和恶意模式

local M = {}

-- 分析User-Agent异常
function M.analyze(user_agent)
    local anomaly_score = 0.0
    local anomalies = {}
    
    if not user_agent or user_agent == "" then
        anomaly_score = 0.3
        table.insert(anomalies, "缺少User-Agent")
        return anomaly_score, anomalies
    end
    
    -- 检查明显的恶意模式
    local malicious_patterns = {
        {pattern = "sqlmap", score = 0.9, desc = "SQL注入工具"},
        {pattern = "nikto", score = 0.9, desc = "Web漏洞扫描器"},
        {pattern = "nmap", score = 0.8, desc = "网络扫描器"},
        {pattern = "masscan", score = 0.8, desc = "端口扫描器"},
        {pattern = "nessus", score = 0.7, desc = "漏洞扫描器"},
        {pattern = "openvas", score = 0.7, desc = "漏洞扫描器"},
        {pattern = "w3af", score = 0.8, desc = "Web应用攻击框架"},
        {pattern = "burp", score = 0.6, desc = "Web安全测试工具"},
        {pattern = "owasp", score = 0.5, desc = "安全测试工具"}
    }
    
    for _, check in ipairs(malicious_patterns) do
        if string.find(user_agent:lower(), check.pattern) then
            anomaly_score = math.max(anomaly_score, check.score)
            table.insert(anomalies, check.desc .. ": " .. check.pattern)
        end
    end
    
    -- 检查可疑的自动化工具
    local automation_patterns = {
        {pattern = "python%-requests", score = 0.3, desc = "Python自动化脚本"},
        {pattern = "python%-urllib", score = 0.3, desc = "Python URL库"},
        {pattern = "curl/", score = 0.2, desc = "命令行工具"},
        {pattern = "wget/", score = 0.2, desc = "下载工具"},
        {pattern = "libwww", score = 0.3, desc = "编程库"},
        {pattern = "go%-http%-client", score = 0.2, desc = "Go HTTP客户端"},
        {pattern = "java/", score = 0.2, desc = "Java应用"}
    }
    
    for _, check in ipairs(automation_patterns) do
        if string.find(user_agent:lower(), check.pattern) then
            anomaly_score = math.max(anomaly_score, check.score)
            table.insert(anomalies, check.desc)
        end
    end
    
    -- 检查User-Agent格式异常
    if string.len(user_agent) < 10 then
        anomaly_score = math.max(anomaly_score, 0.4)
        table.insert(anomalies, "User-Agent过短")
    elseif string.len(user_agent) > 1000 then
        anomaly_score = math.max(anomaly_score, 0.3)
        table.insert(anomalies, "User-Agent过长")
    end
    
    -- 检查是否包含常见浏览器标识
    local browser_indicators = {"Mozilla", "Chrome", "Safari", "Firefox", "Edge", "Opera"}
    local has_browser_indicator = false
    for _, indicator in ipairs(browser_indicators) do
        if string.find(user_agent, indicator) then
            has_browser_indicator = true
            break
        end
    end
    
    if not has_browser_indicator then
        anomaly_score = math.max(anomaly_score, 0.2)
        table.insert(anomalies, "缺少常见浏览器标识")
    end
    
    return anomaly_score, anomalies
end

return M