-- 威胁检测主模块
-- 整合各种检测机制，进行综合威胁评估

-- 加载全局配置和辅助函数
require "init"

local cjson = require "cjson"
local rate_limit = require "rate_limit"
local asn_check = require "asn_check"
local ja3_fingerprint = require "ja3_fingerprint"
local user_agent_analyzer = require "user_agent_analyzer"
local behavior_analyzer = require "behavior_analyzer"

local threat_cache = ngx.shared.threat_cache

-- 威胁检测缓存时间（秒）
local THREAT_CACHE_TTL = 300

-- 调用ML推理服务获取模型评分
local function get_ml_score(factors)
    local request_body = cjson.encode({ features = factors })
    
    -- 使用ngx.location.capture进行内部请求
    local res = ngx.location.capture(
        '/ml_inference_internal',
        {
            method = ngx.HTTP_POST,
            body = request_body,
            args = { model_type = "light" } 
        }
    )
    
    if res and res.status == 200 then
        local response_body = cjson.decode(res.body)
        if response_body and response_body.risk_score then
            return response_body.risk_score
        end
    end
    
    ngx.log(ngx.ERR, "[ThreatDetection] Failed to get score from ML inference service. Status: ", res.status)
    return nil
end

-- 计算综合威胁评分
local function calculate_threat_score(factors)
    -- 从ML服务获取基础评分
    local ml_score = get_ml_score(factors)
    
    -- 如果ML服务调用失败，则退回到基于规则的评分
    if not ml_score then
        local base_score = 0.0
        local weight_sum = 0.0
        local weights = config.threat.weights
        
        for factor, score in pairs(factors) do
            if weights[factor] and score then
                base_score = base_score + (score * weights[factor])
                weight_sum = weight_sum + weights[factor]
            end
        end
        
        if weight_sum > 0 then
            return math.min(math.max(base_score / weight_sum, 0.0), 1.0)
        end
        return 0.0
    end
    
    -- 将ML评分作为主要因素，并结合其他因素进行微调
    local final_score = ml_score * config.threat.weights.ml_score
    
    -- 增加IP信誉的权重
    if factors.ip_reputation then
        final_score = final_score + (factors.ip_reputation * config.threat.weights.ip_reputation)
    end
    
    return math.min(math.max(final_score, 0.0), 1.0)
end



-- 获取IP声誉评分
local function get_ip_reputation_score(client_ip)
    local red = get_redis_connection()
    if not red then
        return 0.0
    end
    
    -- 从威胁情报数据库获取IP声誉
    local reputation_score, err = red:get("ip_reputation:" .. client_ip)
    close_redis_connection(red)
    
    if reputation_score and reputation_score ~= ngx.null then
        return tonumber(reputation_score) or 0.0
    end
    
    return 0.0
end

-- 记录当前请求到历史
local function record_request_history(client_key)
    local red = get_redis_connection()
    if not red then
        return
    end
    
    local request_data = {
        timestamp = ngx.time(),
        uri = ngx.var.uri,
        method = ngx.req.get_method(),
        user_agent = get_user_agent(),
        args = ngx.var.args
    }
    
    local history_key = "request_history:" .. client_key
    red:lpush(history_key, cjson.encode(request_data))
    red:ltrim(history_key, 0, 99) -- 只保留最近100个请求
    red:expire(history_key, 3600) -- 1小时过期
    
    close_redis_connection(red)
end

-- 执行威胁检测决策
local function make_threat_decision(threat_score, factors)
    local action = "allow"
    local reason = ""
    
    if threat_score >= config.threat.high_threshold then
        action = "block"
        reason = "高威胁评分: " .. string.format("%.2f", threat_score)
    elseif threat_score >= config.threat.medium_threshold then
        action = "challenge"
        reason = "中等威胁评分: " .. string.format("%.2f", threat_score)
    else
        action = "allow"
        reason = "低威胁评分: " .. string.format("%.2f", threat_score)
    end
    
    return {
        action = action,
        reason = reason,
        threat_score = threat_score,
        factors = factors,
        timestamp = ngx.time()
    }
end

-- 记录威胁检测事件
local function log_threat_event(client_ip, decision)
    -- 生成一个UUID作为事件ID
    local uuid = require "resty.jit-uuid"
    local event_id = uuid()

    -- 格式化时间戳为ISO 8601
    local timestamp = ngx.localtime()
    local iso_timestamp = string.format("%04d-%02d-%02dT%02d:%02d:%02d.%03dZ",
        timestamp:sub(1,4), timestamp:sub(6,7), timestamp:sub(9,10),
        timestamp:sub(12,13), timestamp:sub(15,16), timestamp:sub(18,19),
        (ngx.now() * 1000) % 1000)

    local event = {
        id = event_id,
        timestamp = iso_timestamp,
        client_ip = client_ip,
        user_agent = get_user_agent(),
        ja3 = ngx.var.ssl_ja3 or nil,
        asn = ngx.var.asn or nil,
        request_path = ngx.var.uri,
        request_method = ngx.req.get_method(),
        headers = ngx.req.get_headers(),
        features = decision.factors,
        threat_score = decision.threat_score,
        threat_categories = { decision.action },
        response_code = ngx.status,
        response_size = ngx.var.body_bytes_sent,
        processing_time = (ngx.now() - ngx.req.start_time()) * 1000,
        geo_country = ngx.var.geoip2_country_code or nil,
        geo_city = ngx.var.geoip2_city_name or nil
    }
    
    -- 发送到Kafka进行进一步分析
    send_to_kafka("threat-detection-events", event)
    
    -- 记录到Nginx日志
    ngx.log(ngx.WARN, "[ThreatDetection] " .. decision.action .. " for IP " .. client_ip .. 
            " (Score: " .. decision.threat_score .. ", Reason: " .. decision.reason .. ")")
end

-- 主要的威胁检测函数
local function perform_threat_detection()
    local client_ip = get_client_ip()
    local client_key = rate_limit.get_client_key()
    
    -- 检查缓存中是否有最近的威胁评估结果
    local cache_key = "threat:" .. client_key
    local cached_result = threat_cache:get(cache_key)
    
    if cached_result then
        local result = cjson.decode(cached_result)
        if result and result.timestamp and (ngx.time() - result.timestamp) < THREAT_CACHE_TTL then
            -- 使用缓存的结果，但仍需要执行决策
            local decision = make_threat_decision(result.threat_score, result.factors)
            
            if decision.action == "block" then
                ngx.status = 403
                ngx.header["X-Block-Reason"] = "Threat detected"
                ngx.say('{"error":"Access denied","reason":"' .. decision.reason .. '","threat_score":' .. decision.threat_score .. '}')
                ngx.exit(403)
            elseif decision.action == "challenge" then
                -- 这里应该实现挑战机制（如验证码、PoW等）
                ngx.header["X-Challenge-Required"] = "true"
                ngx.header["X-Threat-Score"] = decision.threat_score
            end
            
            return true
        end
    end
    
    -- 收集各种威胁因素
    local factors = {}
    
    -- ASN威胁评分
    local asn = ngx.var.asn
    if asn then
        factors.asn_score = asn_check.get_asn_threat_score(asn)
    end
    
    -- JA3可疑程度评分
    local ja3_suspicion = ngx.var.ja3_suspicion_score
    if ja3_suspicion then
        factors.ja3_suspicion = tonumber(ja3_suspicion) or 0.0
    end
    
    -- User-Agent异常评分
    local ua_score, ua_anomalies = user_agent_analyzer.analyze(get_user_agent())
    factors.user_agent_score = ua_score
    
    -- 行为模式评分
    local behavior_score, behavior_patterns = behavior_analyzer.analyze(client_key)
    factors.behavior_score = behavior_score
    
    -- IP声誉评分
    factors.ip_reputation = get_ip_reputation_score(client_ip)
    
    -- 请求模式评分（基于当前请求的特征）
    local request_score = 0.0
    local uri = ngx.var.uri
    local method = ngx.req.get_method()
    
    -- 检查敏感路径访问
    local sensitive_paths = {"/admin", "/config", "/debug", "/.env", "/backup"}
    for _, path in ipairs(sensitive_paths) do
        if string.find(uri, path) then
            request_score = math.max(request_score, 0.3)
            break
        end
    end
    
    factors.request_pattern = request_score
    
    -- 计算综合威胁评分
    local threat_score = calculate_threat_score(factors)
    
    -- 缓存威胁评估结果
    local cache_data = {
        threat_score = threat_score,
        factors = factors,
        timestamp = ngx.time()
    }
    threat_cache:set(cache_key, cjson.encode(cache_data), THREAT_CACHE_TTL)
    
    -- 记录请求历史
    record_request_history(client_key)
    
    -- 做出威胁决策
    local decision = make_threat_decision(threat_score, factors)
    
    -- 记录威胁检测事件
    log_threat_event(client_ip, decision)
    
    -- 设置威胁评分变量供日志使用
    ngx.var.threat_score = threat_score
    ngx.var.action = decision.action
    
    -- 执行决策
    if decision.action == "block" then
        -- 增加被阻断请求的计数器
        local counter_key = "counter:threat_blocked_requests"
        threat_cache:incr(counter_key, 1, 0)
        
        ngx.status = 403
        ngx.header["X-Block-Reason"] = "Threat detected"
        ngx.say('{"error":"Access denied","reason":"' .. decision.reason .. '","threat_score":' .. threat_score .. '}')
        ngx.exit(403)
    elseif decision.action == "challenge" then
        -- 增加被挑战请求的计数器
        local counter_key = "counter:threat_challenged_requests"
        threat_cache:incr(counter_key, 1, 0)
        
        -- 设置挑战头部
        ngx.header["X-Challenge-Required"] = "true"
        ngx.header["X-Threat-Score"] = threat_score
        ngx.header["X-Challenge-Type"] = "captcha" -- 或其他挑战类型
        
        -- 这里可以重定向到挑战页面或返回挑战响应
        -- 为了演示，我们只是添加头部信息
    end
    
    return true
end

-- 导出函数
return {
    check = perform_threat_detection,
    calculate_threat_score = calculate_threat_score,
    analyze_user_agent_anomalies = analyze_user_agent_anomalies,
    analyze_request_behavior = analyze_request_behavior,
    get_ip_reputation_score = get_ip_reputation_score
}