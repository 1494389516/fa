-- Worker 进程初始化脚本
-- 在每个 Nginx worker 进程启动时执行

local cjson = require "cjson"

-- 定时任务：清理过期的缓存数据
local function cleanup_expired_cache()
    local threat_cache = ngx.shared.threat_cache
    local rate_limit_cache = ngx.shared.rate_limit_cache
    local asn_cache = ngx.shared.asn_cache
    local ja3_cache = ngx.shared.ja3_cache
    
    -- 清理威胁缓存中的过期数据
    local keys = threat_cache:get_keys(1000)
    for _, key in ipairs(keys) do
        local value, flags = threat_cache:get(key)
        if value then
            local data = cjson.decode(value)
            if data.expires and data.expires < ngx.time() then
                threat_cache:delete(key)
            end
        end
    end
    
    -- 清理速率限制缓存
    keys = rate_limit_cache:get_keys(1000)
    for _, key in ipairs(keys) do
        local value, flags = rate_limit_cache:get(key)
        if value then
            local data = cjson.decode(value)
            if data.window_start + config.rate_limit.window < ngx.time() then
                rate_limit_cache:delete(key)
            end
        end
    end
    
    log_info("Cache cleanup completed")
end

-- 定时任务：更新配置
local function update_config()
    local red = get_redis_connection()
    if red then
        -- 从Redis获取最新配置
        local config_str, err = red:get("edge_gateway:config")
        if config_str and config_str ~= ngx.null then
            local new_config = cjson.decode(config_str)
            if new_config then
                -- 更新全局配置
                for key, value in pairs(new_config) do
                    config[key] = value
                end
                log_info("Configuration updated from Redis")
            end
        end
        
        -- 获取被封锁的ASN列表
        local blocked_asns, err = red:smembers("edge_gateway:blocked_asns")
        if blocked_asns and #blocked_asns > 0 then
            config.asn.blocked_asns = blocked_asns
            log_info("Updated blocked ASNs: " .. table.concat(blocked_asns, ", "))
        end
        
        close_redis_connection(red)
    end
end

-- 定时任务：发送统计数据
local function send_metrics()
    local threat_cache = ngx.shared.threat_cache
    local rate_limit_cache = ngx.shared.rate_limit_cache
    
    local metrics = {
        timestamp = ngx.time(),
        worker_id = ngx.worker.id(),
        cache_stats = {
            threat_cache_size = threat_cache:capacity(),
            threat_cache_used = threat_cache:free_space(),
            rate_limit_cache_size = rate_limit_cache:capacity(),
            rate_limit_cache_used = rate_limit_cache:free_space()
        },
        counters = {
            total_requests = ngx.shared.threat_cache:get("counter:total_requests") or 0,
            blocked_requests = ngx.shared.threat_cache:get("counter:blocked_requests") or 0,
            challenged_requests = ngx.shared.threat_cache:get("counter:challenged_requests") or 0
        }
    }
    
    -- 发送到Kafka
    send_to_kafka("edge-gateway-metrics", metrics)
end

-- 启动定时器
if ngx.worker.id() == 0 then
    -- 只在第一个worker中启动定时任务
    
    -- 每5分钟清理一次缓存
    local cleanup_timer = ngx.timer.every(300, cleanup_expired_cache)
    if not cleanup_timer then
        log_error("Failed to create cleanup timer")
    end
    
    -- 每分钟更新一次配置
    local config_timer = ngx.timer.every(60, update_config)
    if not config_timer then
        log_error("Failed to create config update timer")
    end
    
    -- 每30秒发送一次指标
    local metrics_timer = ngx.timer.every(30, send_metrics)
    if not metrics_timer then
        log_error("Failed to create metrics timer")
    end
    
    log_info("Timers started successfully")
end

-- 初始化worker特定的数据
local worker_id = ngx.worker.id()
log_info("Worker " .. worker_id .. " initialized")