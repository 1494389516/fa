# Edge Gateway Service

边缘网关服务是恶意流量分控系统的第一道防线，基于 OpenResty (Nginx + Lua) 构建，提供高性能的流量过滤、速率控制和威胁检测功能。

## 功能特性

- **高性能流量处理**: 基于 Nginx 的异步非阻塞架构
- **实时威胁检测**: Lua 脚本实现的快速威胁评估
- **智能速率控制**: 基于 IP、API 路径的多维度限流
- **ASN 封锁**: 支持按自治系统号进行流量封锁
- **JA3 指纹识别**: SSL/TLS 客户端指纹识别
- **协议异常检测**: HTTP 协议层面的异常行为检测
- **实时配置更新**: 支持热更新配置，无需重启服务

## 架构设计

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   外部流量      │───▶│   Edge Gateway   │───▶│   后端服务      │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                              │
                              ▼
                       ┌──────────────────┐
                       │   Redis Cache    │
                       └──────────────────┘
                              │
                              ▼
                       ┌──────────────────┐
                       │   Kafka Queue    │
                       └──────────────────┘
```

## 技术栈

- **OpenResty**: 1.21.4.1 (Nginx + LuaJIT)
- **Lua 模块**:
  - lua-resty-redis: Redis 连接
  - lua-resty-kafka: Kafka 生产者
  - lua-resty-http: HTTP 客户端
  - lua-resty-jwt: JWT 处理
  - lua-cjson: JSON 编解码

## 目录结构

```
services/edge-gateway/
├── Dockerfile              # 容器构建文件
├── README.md              # 服务文档
├── conf/                  # 配置文件
│   ├── nginx.conf         # 主配置文件
│   └── default.conf       # 虚拟主机配置
├── lua/                   # Lua 脚本
│   ├── init.lua           # 初始化脚本
│   ├── init_worker.lua    # Worker 初始化
│   ├── threat_detection.lua # 威胁检测
│   ├── rate_limit.lua     # 速率控制
│   ├── asn_check.lua      # ASN 检查
│   ├── ja3_fingerprint.lua # JA3 指纹
│   ├── metrics.lua        # 指标收集
│   └── admin.lua          # 管理接口
├── scripts/               # 脚本文件
│   └── start.sh           # 启动脚本
└── tests/                 # 测试文件
    ├── unit/              # 单元测试
    └── integration/       # 集成测试
```

## 配置说明

### 环境变量

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| REDIS_HOST | redis | Redis 服务器地址 |
| REDIS_PORT | 6379 | Redis 服务器端口 |
| KAFKA_BROKERS | kafka:29092 | Kafka 集群地址 |

### 限流配置

- **全局限流**: 10 req/s，突发 15 个请求
- **API 限流**: 5 req/s，突发 10 个请求  
- **登录限流**: 1 req/s，突发 3 个请求
- **连接限制**: 每个 IP 最多 20 个并发连接

### 威胁评分阈值

- **高威胁**: ≥ 0.8 (阻断)
- **中威胁**: 0.5 - 0.8 (挑战)
- **低威胁**: < 0.5 (允许)

## 快速开始

### 本地开发

```bash
# 构建镜像
docker build -t edge-gateway .

# 启动服务
docker run -d \
  --name edge-gateway \
  -p 8080:80 \
  -e REDIS_HOST=redis \
  -e KAFKA_BROKERS=kafka:29092 \
  edge-gateway
```

### Docker Compose

```bash
# 在项目根目录执行
docker-compose up edge-gateway
```

## API 接口

### 健康检查

```bash
GET /health
```

响应:
```json
{
  "status": "healthy",
  "timestamp": "2025-01-14T10:30:00Z",
  "version": "1.0"
}
```

### 指标接口

```bash
GET /metrics
```

返回 Prometheus 格式的指标数据。

### 管理接口

```bash
# 获取配置
GET /admin/config

# 更新配置
POST /admin/config
Content-Type: application/json

{
  "rate_limit": {
    "default_rate": 200
  }
}

# 获取统计信息
GET /admin/stats

# 清理缓存
POST /admin/cache/clear
```

## 监控指标

### 请求指标

- `nginx_http_requests_total`: 总请求数
- `nginx_http_request_duration_seconds`: 请求处理时间
- `nginx_http_requests_per_second`: 每秒请求数

### 威胁检测指标

- `edge_gateway_threat_detections_total`: 威胁检测总数
- `edge_gateway_blocked_requests_total`: 被阻断的请求数
- `edge_gateway_challenged_requests_total`: 被挑战的请求数

### 缓存指标

- `edge_gateway_cache_hits_total`: 缓存命中数
- `edge_gateway_cache_misses_total`: 缓存未命中数
- `edge_gateway_cache_size_bytes`: 缓存使用大小

## 日志格式

### 访问日志

```
192.168.1.100 - - [14/Jan/2025:10:30:00 +0000] "GET /api/data HTTP/1.1" 200 1234 "-" "Mozilla/5.0..." "192.168.1.100" rt=0.123 uct="0.001" uht="0.002" urt="0.120"
```

### 安全日志

```
192.168.1.100 - - [14/Jan/2025:10:30:00 +0000] "GET /api/data HTTP/1.1" 403 0 "-" "suspicious-bot" "192.168.1.100" threat_score="0.85" action="block" ja3="769,47-53-5-10..." asn="AS12345"
```

## 性能调优

### Nginx 配置优化

```nginx
# Worker 进程数 = CPU 核心数
worker_processes auto;

# 每个 worker 的连接数
events {
    worker_connections 4096;
    use epoll;
    multi_accept on;
}

# 缓冲区优化
client_body_buffer_size 128k;
client_max_body_size 10m;
large_client_header_buffers 4 4k;
```

### Lua 性能优化

```lua
-- 使用本地变量
local ngx = ngx
local cjson = require "cjson"

-- 预编译正则表达式
local suspicious_ua_pattern = ngx.re.compile([[bot|crawler|spider]], "joi")

-- 使用共享内存缓存
local cache = ngx.shared.threat_cache
```

## 故障排除

### 常见问题

1. **Redis 连接失败**
   ```bash
   # 检查 Redis 连接
   docker exec edge-gateway redis-cli -h redis ping
   ```

2. **Lua 脚本错误**
   ```bash
   # 查看错误日志
   docker logs edge-gateway | grep ERROR
   ```

3. **性能问题**
   ```bash
   # 检查 Nginx 状态
   curl http://localhost:8080/admin/stats
   ```

### 调试模式

```bash
# 启用调试日志
docker run -e NGINX_LOG_LEVEL=debug edge-gateway
```

## 安全考虑

- 管理接口仅允许内网访问
- 使用 HTTPS 传输敏感数据
- 定期更新威胁情报数据
- 监控异常访问模式
- 实施最小权限原则

## 测试

### 单元测试

```bash
# 运行 Lua 单元测试
docker exec edge-gateway lua tests/unit/test_threat_detection.lua
```

### 集成测试

```bash
# 运行集成测试
./tests/integration/test_api.sh
```

### 压力测试

```bash
# 使用 wrk 进行压力测试
wrk -t12 -c400 -d30s http://localhost:8080/health
```

## 部署建议

### 生产环境

- 使用多个实例进行负载均衡
- 配置健康检查和自动重启
- 设置适当的资源限制
- 启用日志轮转
- 配置监控告警

### 扩展性

- 水平扩展: 增加更多网关实例
- 垂直扩展: 增加 CPU 和内存资源
- 缓存优化: 使用 Redis 集群
- 数据库优化: 使用读写分离

## 版本历史

- v1.0.0: 初始版本，基础功能实现
- v1.1.0: 添加 JA3 指纹识别
- v1.2.0: 优化性能，添加更多指标

## 贡献指南

请参考项目根目录的 [CONTRIBUTING.md](../../CONTRIBUTING.md) 文件。