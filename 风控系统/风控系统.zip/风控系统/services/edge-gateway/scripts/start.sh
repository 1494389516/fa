#!/bin/sh

# 启动脚本

set -e

echo "Starting Edge Gateway..."

# 检查环境变量
if [ -z "$REDIS_HOST" ]; then
    export REDIS_HOST="redis"
fi

if [ -z "$REDIS_PORT" ]; then
    export REDIS_PORT="6379"
fi

if [ -z "$KAFKA_BROKERS" ]; then
    export KAFKA_BROKERS="kafka:29092"
fi

echo "Configuration:"
echo "  Redis: $REDIS_HOST:$REDIS_PORT"
echo "  Kafka: $KAFKA_BROKERS"

# 等待依赖服务启动
echo "Waiting for Redis..."
while ! nc -z $REDIS_HOST $REDIS_PORT; do
    sleep 1
done
echo "Redis is ready"

# 创建必要的目录
mkdir -p /var/log/nginx
mkdir -p /var/cache/nginx

# 测试配置文件
echo "Testing Nginx configuration..."
/usr/local/openresty/bin/openresty -t

# 启动 OpenResty
echo "Starting OpenResty..."
exec /usr/local/openresty/bin/openresty -g "daemon off;"