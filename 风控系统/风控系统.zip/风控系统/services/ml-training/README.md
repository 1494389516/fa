# 机器学习模型训练服务

本服务负责使用历史流量数据训练机器学习模型，用于检测恶意网络请求。它提供了一个 RESTful API 来启动、管理和监控训练任务。

## 核心功能

-   **模型训练**: 支持两种类型的模型：
    -   `light`: 基于 `XGBoost` 的轻量级模型，用于快速实时推理。
    -   `heavy`: 基于 `PyTorch` 和 `Transformers` 的深度学习模型，用于更复杂的模式检测。
-   **异步任务管理**: 训练任务作为后台作业运行，可以通过 API 查询其状态。
-   **模型导出**: 训练完成后，模型会自动导出为 ONNX 格式，以便在高性能的 `ml-inference` 服务中使用。
-   **配置驱动**: 模型的超参数和训练设置通过 `config/default.toml` 进行管理。

## API 端点

-   `POST /train/`: 启动一个新的训练任务。
    -   **Body**: `{"model_type": "light" | "heavy", "dataset_path": "path/to/data.csv"}`
-   `GET /train/{job_id}`: 获取特定训练任务的状态和结果。

## 本地开发与运行

1.  **创建虚拟环境** (推荐):
    ```bash
    python -m venv .venv
    source .venv/bin/activate  # On Windows, use `.\.venv\Scripts\activate`
    ```

2.  **安装依赖**:
    ```bash
    pip install -r requirements.txt
    ```
    对于开发，你可能还需要安装 `requirements-dev.txt` 中的依赖。

3.  **运行服务**:
    ```bash
    uvicorn ml_training.main:app --host 0.0.0.0 --port 8085 --reload
    ```
    服务将在 `http://localhost:8085` 上可用。

## 配置

服务的配置位于 `config/default.toml` 文件中。主要配置项包括：

-   `[server]`: 服务器监听的地址和端口。
-   `[training]`: 训练相关的参数，如模型输出路径和测试集比例。
-   `[light_model]` 和 `[heavy_model]`: 各自模型的超参数。

环境变量可以覆盖配置文件中的设置，例如 `MODEL_OUTPUT_PATH`。

## 与其他服务的交互

-   **数据源**: 通常从数据仓库（在本项目中模拟为 CSV 文件）加载训练数据。
-   **模型输出**: 训练好的模型（`.joblib` 或 `.pt` 格式）和 ONNX 文件保存在 `models/` 目录下，该目录通过 Docker Volume 共享给 `ml-inference` 服务使用。