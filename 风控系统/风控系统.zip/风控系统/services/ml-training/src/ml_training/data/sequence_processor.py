"""
序列数据处理器
用于处理时序数据和序列特征
"""

import numpy as np
import pandas as pd
from typing import List, Tuple, Optional, Dict, Any
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import logging

logger = logging.getLogger(__name__)


class SequenceProcessor:
    """序列数据处理器"""
    
    def __init__(self, 
                 max_length: int = 100,
                 padding_value: float = 0.0,
                 truncate_method: str = 'tail'):
        """
        初始化序列处理器
        
        Args:
            max_length: 最大序列长度
            padding_value: 填充值
            truncate_method: 截断方法 ('head', 'tail', 'middle')
        """
        self.max_length = max_length
        self.padding_value = padding_value
        self.truncate_method = truncate_method
        self.scaler = None
    
    def pad_sequences(self, sequences: List[List[float]]) -> np.ndarray:
        """
        对序列进行填充和截断
        
        Args:
            sequences: 输入序列列表
        
        Returns:
            处理后的序列数组
        """
        processed = []
        
        for seq in sequences:
            if len(seq) > self.max_length:
                # 截断
                if self.truncate_method == 'head':
                    processed_seq = seq[-self.max_length:]
                elif self.truncate_method == 'tail':
                    processed_seq = seq[:self.max_length]
                elif self.truncate_method == 'middle':
                    start = (len(seq) - self.max_length) // 2
                    processed_seq = seq[start:start + self.max_length]
                else:
                    processed_seq = seq[:self.max_length]
            else:
                # 填充
                padding_length = self.max_length - len(seq)
                processed_seq = seq + [self.padding_value] * padding_length
            
            processed.append(processed_seq)
        
        return np.array(processed, dtype=np.float32)
    
    def create_temporal_features(self, sequences: List[List[float]]) -> np.ndarray:
        """
        创建时序统计特征
        
        Args:
            sequences: 输入序列列表
        
        Returns:
            时序特征数组
        """
        temporal_features = []
        
        for seq in sequences:
            if not seq:
                # 空序列的默认特征
                features = [0.0] * 10
            else:
                seq_array = np.array(seq)
                features = [
                    len(seq),                           # 序列长度
                    np.mean(seq_array),                 # 均值
                    np.std(seq_array),                  # 标准差
                    np.min(seq_array),                  # 最小值
                    np.max(seq_array),                  # 最大值
                    np.median(seq_array),               # 中位数
                    np.percentile(seq_array, 25),       # 25分位数
                    np.percentile(seq_array, 75),       # 75分位数
                    np.sum(seq_array),                  # 总和
                    np.var(seq_array)                   # 方差
                ]
            
            temporal_features.append(features)
        
        return np.array(temporal_features, dtype=np.float32)
    
    def create_sliding_windows(self, 
                             sequence: List[float], 
                             window_size: int, 
                             step_size: int = 1) -> List[List[float]]:
        """
        创建滑动窗口
        
        Args:
            sequence: 输入序列
            window_size: 窗口大小
            step_size: 步长
        
        Returns:
            滑动窗口列表
        """
        windows = []
        
        for i in range(0, len(sequence) - window_size + 1, step_size):
            window = sequence[i:i + window_size]
            windows.append(window)
        
        return windows
    
    def extract_trend_features(self, sequences: List[List[float]]) -> np.ndarray:
        """
        提取趋势特征
        
        Args:
            sequences: 输入序列列表
        
        Returns:
            趋势特征数组
        """
        trend_features = []
        
        for seq in sequences:
            if len(seq) < 2:
                # 序列太短，无法计算趋势
                features = [0.0] * 5
            else:
                seq_array = np.array(seq)
                
                # 计算一阶差分
                diff1 = np.diff(seq_array)
                
                # 计算二阶差分
                diff2 = np.diff(diff1) if len(diff1) > 1 else np.array([0.0])
                
                features = [
                    np.mean(diff1),                     # 一阶差分均值 (趋势)
                    np.std(diff1),                      # 一阶差分标准差 (波动性)
                    np.mean(diff2),                     # 二阶差分均值 (加速度)
                    np.sum(diff1 > 0) / len(diff1),     # 上升比例
                    np.sum(diff1 < 0) / len(diff1)      # 下降比例
                ]
            
            trend_features.append(features)
        
        return np.array(trend_features, dtype=np.float32)
    
    def detect_anomalies(self, 
                        sequences: List[List[float]], 
                        method: str = 'iqr',
                        threshold: float = 1.5) -> List[List[bool]]:
        """
        检测序列中的异常值
        
        Args:
            sequences: 输入序列列表
            method: 异常检测方法 ('iqr', 'zscore')
            threshold: 异常阈值
        
        Returns:
            异常值标记列表
        """
        anomaly_masks = []
        
        for seq in sequences:
            if len(seq) < 4:
                # 序列太短，无法检测异常
                mask = [False] * len(seq)
            else:
                seq_array = np.array(seq)
                
                if method == 'iqr':
                    # 使用IQR方法
                    q1 = np.percentile(seq_array, 25)
                    q3 = np.percentile(seq_array, 75)
                    iqr = q3 - q1
                    lower_bound = q1 - threshold * iqr
                    upper_bound = q3 + threshold * iqr
                    mask = (seq_array < lower_bound) | (seq_array > upper_bound)
                
                elif method == 'zscore':
                    # 使用Z-score方法
                    z_scores = np.abs((seq_array - np.mean(seq_array)) / np.std(seq_array))
                    mask = z_scores > threshold
                
                else:
                    mask = [False] * len(seq)
                
                mask = mask.tolist()
            
            anomaly_masks.append(mask)
        
        return anomaly_masks
    
    def normalize_sequences(self, 
                          sequences: List[List[float]], 
                          method: str = 'standard',
                          fit: bool = True) -> List[List[float]]:
        """
        标准化序列数据
        
        Args:
            sequences: 输入序列列表
            method: 标准化方法 ('standard', 'minmax')
            fit: 是否拟合标准化器
        
        Returns:
            标准化后的序列列表
        """
        # 将序列展平为二维数组
        all_values = []
        sequence_lengths = []
        
        for seq in sequences:
            all_values.extend(seq)
            sequence_lengths.append(len(seq))
        
        if not all_values:
            return sequences
        
        all_values = np.array(all_values).reshape(-1, 1)
        
        # 选择标准化方法
        if fit or self.scaler is None:
            if method == 'standard':
                self.scaler = StandardScaler()
            elif method == 'minmax':
                self.scaler = MinMaxScaler()
            else:
                logger.warning(f"Unknown normalization method: {method}")
                return sequences
            
            normalized_values = self.scaler.fit_transform(all_values).flatten()
        else:
            normalized_values = self.scaler.transform(all_values).flatten()
        
        # 重新组织为序列格式
        normalized_sequences = []
        start_idx = 0
        
        for length in sequence_lengths:
            end_idx = start_idx + length
            normalized_seq = normalized_values[start_idx:end_idx].tolist()
            normalized_sequences.append(normalized_seq)
            start_idx = end_idx
        
        return normalized_sequences
    
    def create_sequence_embeddings(self, 
                                 sequences: List[List[float]], 
                                 embedding_dim: int = 50) -> np.ndarray:
        """
        创建序列嵌入表示
        
        Args:
            sequences: 输入序列列表
            embedding_dim: 嵌入维度
        
        Returns:
            序列嵌入数组
        """
        embeddings = []
        
        for seq in sequences:
            if not seq:
                # 空序列的零嵌入
                embedding = [0.0] * embedding_dim
            else:
                # 简单的统计嵌入
                seq_array = np.array(seq)
                
                # 基础统计特征
                basic_stats = [
                    np.mean(seq_array), np.std(seq_array), np.min(seq_array), np.max(seq_array),
                    np.median(seq_array), len(seq), np.sum(seq_array), np.var(seq_array)
                ]
                
                # 分位数特征
                percentiles = [np.percentile(seq_array, p) for p in [10, 20, 30, 40, 60, 70, 80, 90]]
                
                # 趋势特征
                if len(seq) > 1:
                    diff = np.diff(seq_array)
                    trend_stats = [np.mean(diff), np.std(diff), np.sum(diff > 0) / len(diff)]
                else:
                    trend_stats = [0.0, 0.0, 0.0]
                
                # 组合所有特征
                all_features = basic_stats + percentiles + trend_stats
                
                # 截断或填充到指定维度
                if len(all_features) > embedding_dim:
                    embedding = all_features[:embedding_dim]
                else:
                    embedding = all_features + [0.0] * (embedding_dim - len(all_features))
            
            embeddings.append(embedding)
        
        return np.array(embeddings, dtype=np.float32)

    def process_sequences(self, sequences: List[List[float]]) -> np.ndarray:
        """
        Process a list of sequences into a feature matrix.
        This is a simplified version for demonstration.
        """
        return self.pad_sequences(sequences)
    
    def process_batch(self, 
                     sequences: List[List[float]], 
                     include_temporal: bool = True,
                     include_trend: bool = True,
                     include_embeddings: bool = False,
                     normalize: bool = True) -> Dict[str, np.ndarray]:
        """
        批量处理序列数据
        
        Args:
            sequences: 输入序列列表
            include_temporal: 是否包含时序特征
            include_trend: 是否包含趋势特征
            include_embeddings: 是否包含嵌入特征
            normalize: 是否标准化
        
        Returns:
            处理后的特征字典
        """
        result = {}
        
        # 标准化序列
        if normalize:
            sequences = self.normalize_sequences(sequences)
        
        # 填充序列
        result['padded_sequences'] = self.pad_sequences(sequences)
        
        # 时序特征
        if include_temporal:
            result['temporal_features'] = self.create_temporal_features(sequences)
        
        # 趋势特征
        if include_trend:
            result['trend_features'] = self.extract_trend_features(sequences)
        
        # 嵌入特征
        if include_embeddings:
            result['embedding_features'] = self.create_sequence_embeddings(sequences)
        
        return result