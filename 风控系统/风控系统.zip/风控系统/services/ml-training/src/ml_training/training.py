"""
Enhanced Training Manager for ML model training, evaluation, and deployment.
Includes advanced features like hyperparameter optimization, model ensemble,
cross-validation, and comprehensive monitoring.
"""
import asyncio
import logging
import time
import uuid
import json
import pickle
import hashlib
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List, Union
from dataclasses import dataclass, asdict
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager

import numpy as np
import pandas as pd
from sklearn.model_selection import (
    train_test_split, StratifiedKFold, cross_val_score,
    GridSearchCV, RandomizedSearchCV
)
from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import VotingClassifier
import optuna
from optuna.samplers import TPESampler
from optuna.pruners import MedianPruner

from .config import Config, get_settings
from .models.light_model import LightModel
from .models.heavy_model import HeavyModel
from .models.advanced_models import (
    EnsembleRiskModel, SequentialRiskModel, RealTimeRiskScorer,
    DeepFraudNet, AttentionFraudNet
)
from .utils.metrics import calculate_metrics

logger = logging.getLogger(__name__)

@dataclass
class TrainingConfig:
    """Enhanced training configuration."""
    test_ratio: float = 0.2
    val_ratio: float = 0.1
    cv_folds: int = 5
    enable_hyperopt: bool = True
    hyperopt_trials: int = 100
    enable_ensemble: bool = True
    enable_feature_selection: bool = True
    feature_selection_k: int = 50
    scaler_type: str = "standard"  # standard, robust, minmax
    early_stopping_patience: int = 10
    class_weight_strategy: str = "balanced"  # balanced, None, custom
    enable_model_explanation: bool = True
    cache_preprocessed_data: bool = True
    parallel_jobs: int = -1

@dataclass
class ModelPerformance:
    """Model performance metrics container."""
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    auc_roc: float
    confusion_matrix: List[List[int]]
    classification_report: Dict[str, Any]
    cross_val_scores: Optional[List[float]] = None
    feature_importance: Optional[Dict[str, float]] = None

class EnhancedTrainingManager:
    """Enhanced training manager with advanced ML capabilities."""

    def __init__(self, settings: Config):
        self.settings = settings
        self.training_config = TrainingConfig()
        self.active_jobs: Dict[str, Any] = {}
        self.job_history: Dict[str, Any] = {}
        self.model_registry: Dict[str, Any] = {}
        self._lock = asyncio.Lock()
        self._executor = ThreadPoolExecutor(max_workers=4)
        self._data_cache: Dict[str, Any] = {}
        
        # Initialize paths
        self.cache_dir = Path(getattr(settings.training, 'cache_dir', './cache'))
        self.model_dir = Path(getattr(settings.training, 'model_output_path', './models'))
        self.log_dir = Path(getattr(settings.training, 'log_dir', './logs'))
        
        for dir_path in [self.cache_dir, self.model_dir, self.log_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # Reproducibility
        self._set_global_seed(42)

    async def initialize(self):
        """Initialize the enhanced training manager."""
        logger.info("Initializing Enhanced Training Manager...")
        
        # Load job history if exists
        history_file = self.log_dir / "job_history.json"
        if history_file.exists():
            try:
                with open(history_file, 'r') as f:
                    self.job_history = json.load(f)
                logger.info(f"Loaded {len(self.job_history)} historical jobs")
            except Exception as e:
                logger.warning(f"Failed to load job history: {e}")
        
        # Initialize Optuna study for hyperparameter optimization
        self.study = optuna.create_study(
            direction="maximize",
            sampler=TPESampler(seed=42),
            pruner=MedianPruner(n_startup_trials=5, n_warmup_steps=10)
        )

    async def cleanup(self):
        """Clean up resources and save job history."""
        logger.info("Cleaning up Enhanced Training Manager...")
        
        # Cancel running jobs
        for job_id in list(self.active_jobs.keys()):
            if self.active_jobs[job_id]["status"] == "running":
                await self._update_job_status(job_id, "canceled", 100.0)
        
        # Save job history
        history_file = self.log_dir / "job_history.json"
        try:
            with open(history_file, 'w') as f:
                json.dump(self.job_history, f, indent=2, default=str)
            logger.info("Job history saved successfully")
        except Exception as e:
            logger.error(f"Failed to save job history: {e}")
        
        # Shutdown executor
        self._executor.shutdown(wait=True)

    async def start_training(self, model_type: str, dataset_path: str, 
                           config_override: Optional[Dict[str, Any]] = None) -> str:
        """Start an enhanced training job with advanced features."""
        job_id = str(uuid.uuid4())
        
        # Apply configuration overrides
        job_config = asdict(self.training_config)
        if config_override:
            job_config.update(config_override)
        
        async with self._lock:
            self.active_jobs[job_id] = {
                "status": "starting",
                "progress": 0.0,
                "model_type": model_type,
                "dataset_path": dataset_path,
                "config": job_config,
                "start_time": time.time(),
                "logs": [],
                "metrics": {},
                "best_params": {},
                "models": {}
            }
        
        logger.info(f"Starting enhanced training job {job_id} for model type '{model_type}'")
        asyncio.create_task(self._run_enhanced_training_job(job_id))
        
        return job_id

    async def _run_enhanced_training_job(self, job_id: str):
        """Enhanced training pipeline with advanced ML features."""
        try:
            job_info = self.active_jobs[job_id]
            config = job_info["config"]
            
            # 1. Data Loading and Caching
            await self._update_job_status(job_id, "loading_data", 5.0)
            data = await self._load_and_cache_data(job_info["dataset_path"])
            
            # 2. Data Preprocessing
            await self._update_job_status(job_id, "preprocessing_data", 15.0)
            processed_data = await self._preprocess_data(data, config, job_id)
            
            # 3. Feature Engineering and Selection
            await self._update_job_status(job_id, "feature_engineering", 25.0)
            X_processed, y, feature_names = await self._feature_engineering(
                processed_data, config, job_id
            )
            
            # 4. Data Splitting with Stratification
            await self._update_job_status(job_id, "splitting_data", 30.0)
            splits = self._enhanced_data_split(X_processed, y, config)
            X_train, X_val, X_test, y_train, y_val, y_test = splits
            
            # 5. Hyperparameter Optimization (if enabled)
            if config["enable_hyperopt"]:
                await self._update_job_status(job_id, "hyperparameter_optimization", 40.0)
                best_params = await self._hyperparameter_optimization(
                    job_id, X_train, y_train, X_val, y_val, config
                )
                job_info["best_params"] = best_params
            else:
                best_params = {}
            
            # 6. Model Training with Best Parameters
            await self._update_job_status(job_id, "training_model", 60.0)
            models = await self._train_enhanced_models(
                job_id, X_train, y_train, X_val, y_val, best_params, feature_names
            )
            
            # 7. Model Ensemble (if enabled)
            if config["enable_ensemble"] and len(models) > 1:
                await self._update_job_status(job_id, "creating_ensemble", 75.0)
                ensemble_model = self._create_ensemble(models, X_val, y_val)
                models["ensemble"] = ensemble_model
            
            # 8. Cross-Validation
            await self._update_job_status(job_id, "cross_validation", 80.0)
            cv_results = await self._cross_validation(models, X_train, y_train, config)
            
            # 9. Final Evaluation
            await self._update_job_status(job_id, "final_evaluation", 90.0)
            evaluation_results = await self._comprehensive_evaluation(
                models, X_test, y_test, feature_names, config
            )
            
            # 10. Model Saving and Export
            await self._update_job_status(job_id, "saving_models", 95.0)
            model_paths = await self._save_enhanced_models(models, job_id, evaluation_results)
            
            # 11. Generate Model Report
            await self._update_job_status(job_id, "generating_report", 98.0)
            report = self._generate_training_report(
                job_id, evaluation_results, cv_results, model_paths
            )
            
            # Update job completion
            job_info.update({
                "evaluation": evaluation_results,
                "cv_results": cv_results,
                "model_paths": model_paths,
                "report": report,
                "end_time": time.time()
            })
            
            await self._update_job_status(job_id, "completed", 100.0)
            
            # Archive to history
            self.job_history[job_id] = dict(job_info)
            
            logger.info(f"Enhanced training job {job_id} completed successfully")

        except Exception as e:
            logger.exception(f"Error during enhanced training job {job_id}: {e}")
            await self._update_job_status(job_id, "failed", 100.0, str(e))

    async def _load_and_cache_data(self, dataset_path: str) -> pd.DataFrame:
        """Load data with intelligent caching."""
        # Create cache key based on file path and modification time
        file_path = Path(dataset_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Dataset not found: {dataset_path}")
        
        cache_key = hashlib.md5(
            f"{dataset_path}_{file_path.stat().st_mtime}".encode()
        ).hexdigest()
        
        cache_file = self.cache_dir / f"data_{cache_key}.pkl"
        
        if cache_file.exists() and self.training_config.cache_preprocessed_data:
            logger.info(f"Loading cached data from {cache_file}")
            with open(cache_file, 'rb') as f:
                return pickle.load(f)
        
        logger.info(f"Loading fresh data from {dataset_path}")
        
        # Support multiple file formats
        if dataset_path.endswith('.csv'):
            data = pd.read_csv(dataset_path)
        elif dataset_path.endswith('.parquet'):
            data = pd.read_parquet(dataset_path)
        elif dataset_path.endswith('.json'):
            data = pd.read_json(dataset_path)
        else:
            raise ValueError(f"Unsupported file format: {dataset_path}")
        
        # Cache the loaded data
        if self.training_config.cache_preprocessed_data:
            with open(cache_file, 'wb') as f:
                pickle.dump(data, f)
        
        return data

    async def _preprocess_data(self, data: pd.DataFrame, config: Dict[str, Any], 
                             job_id: str) -> pd.DataFrame:
        """Enhanced data preprocessing pipeline."""
        logger.info("Starting enhanced data preprocessing...")
        
        # Handle missing values
        data = data.dropna()
        
        # Remove duplicates
        initial_shape = data.shape
        data = data.drop_duplicates()
        logger.info(f"Removed {initial_shape[0] - data.shape[0]} duplicate rows")
        
        # Data type optimization
        for col in data.select_dtypes(include=['int64']).columns:
            if data[col].min() >= 0 and data[col].max() <= 255:
                data[col] = data[col].astype('uint8')
            elif data[col].min() >= -128 and data[col].max() <= 127:
                data[col] = data[col].astype('int8')
        
        # Log preprocessing results
        self.active_jobs[job_id]["logs"].append(
            f"Preprocessing completed: {data.shape[0]} rows, {data.shape[1]} columns"
        )
        
        return data

    async def _feature_engineering(self, data: pd.DataFrame, config: Dict[str, Any], 
                                 job_id: str) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        """Advanced feature engineering and selection."""
        logger.info("Starting feature engineering...")
        
        # Assume 'label' is the target column
        if 'label' not in data.columns:
            raise ValueError("Target column 'label' not found in dataset")
        
        X = data.drop('label', axis=1)
        y = data['label']
        
        # Feature scaling
        scaler_type = config.get("scaler_type", "standard")
        if scaler_type == "standard":
            scaler = StandardScaler()
        elif scaler_type == "robust":
            scaler = RobustScaler()
        elif scaler_type == "minmax":
            scaler = MinMaxScaler()
        else:
            scaler = StandardScaler()
        
        X_scaled = scaler.fit_transform(X)
        
        # Feature selection (if enabled)
        if config.get("enable_feature_selection", True):
            k_features = min(config.get("feature_selection_k", 50), X.shape[1])
            selector = SelectKBest(score_func=f_classif, k=k_features)
            X_selected = selector.fit_transform(X_scaled, y)
            
            # Get selected feature names
            selected_indices = selector.get_support(indices=True)
            feature_names = [X.columns[i] for i in selected_indices]
            
            logger.info(f"Selected {len(feature_names)} features out of {X.shape[1]}")
        else:
            X_selected = X_scaled
            feature_names = list(X.columns)
        
        # Store preprocessing objects for later use
        self.active_jobs[job_id]["preprocessing"] = {
            "scaler": scaler,
            "feature_selector": selector if config.get("enable_feature_selection") else None,
            "feature_names": feature_names
        }
        
        return X_selected, y.values, feature_names

    def _enhanced_data_split(self, X: np.ndarray, y: np.ndarray, 
                           config: Dict[str, Any]) -> Tuple[np.ndarray, ...]:
        """Enhanced data splitting with stratification."""
        test_ratio = config.get("test_ratio", 0.2)
        val_ratio = config.get("val_ratio", 0.1)
        
        # First split: train_val vs test
        X_train_val, X_test, y_train_val, y_test = train_test_split(
            X, y, test_size=test_ratio, random_state=42, stratify=y
        )
        
        # Second split: train vs val
        val_relative = val_ratio / (1.0 - test_ratio)
        X_train, X_val, y_train, y_val = train_test_split(
            X_train_val, y_train_val, test_size=val_relative, 
            random_state=42, stratify=y_train_val
        )
        
        logger.info(f"Data split - Train: {X_train.shape[0]}, Val: {X_val.shape[0]}, Test: {X_test.shape[0]}")
        
        return X_train, X_val, X_test, y_train, y_val, y_test

    async def _hyperparameter_optimization(self, job_id: str, X_train: np.ndarray, 
                                         y_train: np.ndarray, X_val: np.ndarray, 
                                         y_val: np.ndarray, config: Dict[str, Any]) -> Dict[str, Any]:
        """Hyperparameter optimization using Optuna."""
        logger.info("Starting hyperparameter optimization...")
        
        model_type = self.active_jobs[job_id]["model_type"]
        
        def objective(trial):
            try:
                if model_type == "light":
                    # Optimize LightGBM parameters
                    params = {
                        'n_estimators': trial.suggest_int('n_estimators', 50, 500),
                        'max_depth': trial.suggest_int('max_depth', 3, 15),
                        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
                        'num_leaves': trial.suggest_int('num_leaves', 10, 300),
                        'min_child_samples': trial.suggest_int('min_child_samples', 5, 100),
                        'subsample': trial.suggest_float('subsample', 0.5, 1.0),
                        'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0)
                    }
                elif model_type == "heavy":
                    # Optimize neural network parameters
                    params = {
                        'hidden_layers': trial.suggest_int('hidden_layers', 2, 5),
                        'hidden_size': trial.suggest_int('hidden_size', 64, 512),
                        'dropout_rate': trial.suggest_float('dropout_rate', 0.1, 0.5),
                        'learning_rate': trial.suggest_float('learning_rate', 1e-5, 1e-2, log=True),
                        'batch_size': trial.suggest_categorical('batch_size', [32, 64, 128, 256])
                    }
                else:
                    raise ValueError(f"Unknown model type: {model_type}")
                
                # Create and train model with suggested parameters
                if model_type == "light":
                    model = LightModel({**self.settings.light_model.__dict__, **params})
                else:
                    model = HeavyModel({**self.settings.heavy_model.__dict__, **params})
                
                model.train(X_train, y_train, X_val, y_val)
                
                # Evaluate on validation set
                val_predictions = model.predict(X_val)
                val_metrics = calculate_metrics(y_val, val_predictions)
                
                return val_metrics.get('f1_score', 0.0)
                
            except Exception as e:
                logger.warning(f"Trial failed: {e}")
                return 0.0
        
        # Run optimization
        n_trials = config.get("hyperopt_trials", 100)
        self.study.optimize(objective, n_trials=n_trials, timeout=3600)  # 1 hour timeout
        
        best_params = self.study.best_params
        logger.info(f"Best hyperparameters found: {best_params}")
        logger.info(f"Best validation score: {self.study.best_value:.4f}")
        
        return best_params

    async def _train_enhanced_models(self, job_id: str, X_train: np.ndarray, 
                                   y_train: np.ndarray, X_val: np.ndarray, 
                                   y_val: np.ndarray, best_params: Dict[str, Any],
                                   feature_names: List[str]) -> Dict[str, Any]:
        """Train models with enhanced configurations."""
        logger.info("Training enhanced models...")
        
        model_type = self.active_jobs[job_id]["model_type"]
        models = {}
        
        # Train primary model with best parameters
        if model_type == "light":
            model_config = {**self.settings.light_model.__dict__, **best_params}
            model = LightModel(model_config)
        else:
            model_config = {**self.settings.heavy_model.__dict__, **best_params}
            model = HeavyModel(model_config)
        
        model.train(X_train, y_train, X_val, y_val, feature_names=feature_names)
        models["primary"] = model
        
        # Train additional models for ensemble (if enabled)
        config = self.active_jobs[job_id]["config"]
        if config.get("enable_ensemble", True):
            # Train with different random seeds for diversity
            for i in range(2):
                seed_model_config = model_config.copy()
                seed_model_config['random_state'] = 42 + i + 1
                
                if model_type == "light":
                    seed_model = LightModel(seed_model_config)
                else:
                    seed_model = HeavyModel(seed_model_config)
                
                seed_model.train(X_train, y_train, X_val, y_val, feature_names=feature_names)
                models[f"seed_{i+1}"] = seed_model
        
        return models

    def _create_ensemble(self, models: Dict[str, Any], X_val: np.ndarray, 
                        y_val: np.ndarray) -> VotingClassifier:
        """Create ensemble model from trained models."""
        logger.info("Creating ensemble model...")
        
        # Prepare estimators for VotingClassifier
        estimators = []
        for name, model in models.items():
            if hasattr(model, 'model'):  # Wrap our custom models
                estimators.append((name, model.model))
        
        # Create voting classifier
        ensemble = VotingClassifier(
            estimators=estimators,
            voting='soft' if hasattr(models['primary'], 'predict_proba') else 'hard'
        )
        
        # Fit ensemble on validation data
        ensemble.fit(X_val, y_val)
        
        return ensemble

    async def _cross_validation(self, models: Dict[str, Any], X_train: np.ndarray, 
                              y_train: np.ndarray, config: Dict[str, Any]) -> Dict[str, Any]:
        """Perform cross-validation on trained models."""
        logger.info("Performing cross-validation...")
        
        cv_folds = config.get("cv_folds", 5)
        cv_results = {}
        
        for model_name, model in models.items():
            if model_name == "ensemble":
                continue  # Skip ensemble for CV
            
            try:
                # Use the underlying sklearn model for CV
                sklearn_model = model.model if hasattr(model, 'model') else model
                
                cv_scores = cross_val_score(
                    sklearn_model, X_train, y_train, 
                    cv=StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42),
                    scoring='f1_macro',
                    n_jobs=config.get("parallel_jobs", -1)
                )
                
                cv_results[model_name] = {
                    "scores": cv_scores.tolist(),
                    "mean": float(cv_scores.mean()),
                    "std": float(cv_scores.std())
                }
                
                logger.info(f"{model_name} CV F1: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
                
            except Exception as e:
                logger.warning(f"CV failed for {model_name}: {e}")
                cv_results[model_name] = {"error": str(e)}
        
        return cv_results

    async def _comprehensive_evaluation(self, models: Dict[str, Any], X_test: np.ndarray, 
                                      y_test: np.ndarray, feature_names: List[str],
                                      config: Dict[str, Any]) -> Dict[str, ModelPerformance]:
        """Comprehensive model evaluation with detailed metrics."""
        logger.info("Performing comprehensive evaluation...")
        
        evaluation_results = {}
        
        for model_name, model in models.items():
            try:
                # Get predictions
                if hasattr(model, 'predict'):
                    y_pred = model.predict(X_test)
                    y_pred_proba = model.predict_proba(X_test) if hasattr(model, 'predict_proba') else None
                else:
                    y_pred = model.predict(X_test)
                    y_pred_proba = None
                
                # Calculate comprehensive metrics
                metrics = calculate_metrics(y_test, y_pred, y_pred_proba)
                
                # Get feature importance if available
                feature_importance = None
                if hasattr(model, 'feature_importances_'):
                    importance_scores = model.feature_importances_
                    feature_importance = dict(zip(feature_names, importance_scores))
                elif hasattr(model, 'model') and hasattr(model.model, 'feature_importances_'):
                    importance_scores = model.model.feature_importances_
                    feature_importance = dict(zip(feature_names, importance_scores))
                
                # Create performance object
                performance = ModelPerformance(
                    accuracy=metrics.get('accuracy', 0.0),
                    precision=metrics.get('precision', 0.0),
                    recall=metrics.get('recall', 0.0),
                    f1_score=metrics.get('f1_score', 0.0),
                    auc_roc=metrics.get('auc_roc', 0.0),
                    confusion_matrix=confusion_matrix(y_test, y_pred).tolist(),
                    classification_report=classification_report(y_test, y_pred, output_dict=True),
                    feature_importance=feature_importance
                )
                
                evaluation_results[model_name] = performance
                
                logger.info(f"{model_name} - F1: {performance.f1_score:.4f}, "
                          f"AUC: {performance.auc_roc:.4f}")
                
            except Exception as e:
                logger.error(f"Evaluation failed for {model_name}: {e}")
        
        return evaluation_results

    async def _save_enhanced_models(self, models: Dict[str, Any], job_id: str, 
                                  evaluation_results: Dict[str, ModelPerformance]) -> Dict[str, str]:
        """Save models with comprehensive metadata."""
        logger.info("Saving enhanced models...")
        
        model_paths = {}
        
        for model_name, model in models.items():
            try:
                # Determine file extension
                model_type = self.active_jobs[job_id]["model_type"]
                extension = ".pt" if model_type == "heavy" else ".joblib"
                
                # Create model path
                model_path = self.model_dir / f"{model_type}_{model_name}_{job_id}{extension}"
                
                # Save model
                if hasattr(model, 'save_model'):
                    model.save_model(str(model_path))
                else:
                    # Fallback for ensemble models
                    import joblib
                    joblib.dump(model, model_path)
                
                # Save metadata
                metadata = {
                    "job_id": job_id,
                    "model_name": model_name,
                    "model_type": model_type,
                    "training_time": time.time(),
                    "performance": asdict(evaluation_results.get(model_name)) if model_name in evaluation_results else {},
                    "config": self.active_jobs[job_id]["config"]
                }
                
                metadata_path = model_path.with_suffix('.json')
                with open(metadata_path, 'w') as f:
                    json.dump(metadata, f, indent=2, default=str)
                
                model_paths[model_name] = str(model_path)
                
                logger.info(f"Saved {model_name} to {model_path}")
                
            except Exception as e:
                logger.error(f"Failed to save {model_name}: {e}")
        
        return model_paths

    def _generate_training_report(self, job_id: str, evaluation_results: Dict[str, ModelPerformance],
                                cv_results: Dict[str, Any], model_paths: Dict[str, str]) -> Dict[str, Any]:
        """Generate comprehensive training report."""
        job_info = self.active_jobs[job_id]
        
        # Find best model
        best_model = max(evaluation_results.items(), 
                        key=lambda x: x[1].f1_score if x[1] else 0)
        
        report = {
            "job_id": job_id,
            "model_type": job_info["model_type"],
            "training_duration": time.time() - job_info["start_time"],
            "best_model": {
                "name": best_model[0],
                "f1_score": best_model[1].f1_score,
                "accuracy": best_model[1].accuracy,
                "auc_roc": best_model[1].auc_roc
            },
            "model_comparison": {
                name: {
                    "f1_score": perf.f1_score,
                    "accuracy": perf.accuracy,
                    "precision": perf.precision,
                    "recall": perf.recall,
                    "auc_roc": perf.auc_roc
                }
                for name, perf in evaluation_results.items()
            },
            "cross_validation": cv_results,
            "hyperparameters": job_info.get("best_params", {}),
            "model_paths": model_paths,
            "data_info": {
                "dataset_path": job_info["dataset_path"],
                "preprocessing_steps": list(job_info.get("preprocessing", {}).keys())
            }
        }
        
        return report

    async def _update_job_status(self, job_id: str, status: str, progress: float, 
                               error: Optional[str] = None):
        """Update job status with enhanced logging."""
        async with self._lock:
            if job_id in self.active_jobs:
                self.active_jobs[job_id]["status"] = status
                self.active_jobs[job_id]["progress"] = progress
                
                log_message = f"Job {job_id} - {status}: {progress:.1f}%"
                if error:
                    self.active_jobs[job_id]["error"] = error
                    log_message += f" - Error: {error}"
                
                self.active_jobs[job_id]["logs"].append({
                    "timestamp": time.time(),
                    "status": status,
                    "progress": progress,
                    "message": log_message,
                    "error": error
                })
                
                logger.info(log_message)

    def get_job_status(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get comprehensive job status."""
        return self.active_jobs.get(job_id)

    def get_job_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get job history with optional limit."""
        history_items = list(self.job_history.values())
        return sorted(history_items, key=lambda x: x.get("start_time", 0), reverse=True)[:limit]

    def get_model_registry(self) -> Dict[str, Any]:
        """Get model registry information."""
        return self.model_registry

    async def cancel_job(self, job_id: str) -> bool:
        """Cancel a running job."""
        async with self._lock:
            if job_id in self.active_jobs:
                if self.active_jobs[job_id]["status"] in ["running", "starting"]:
                    await self._update_job_status(job_id, "canceled", 100.0)
                    logger.info(f"Job {job_id} canceled successfully")
                    return True
        return False

    def _set_global_seed(self, seed: int = 42) -> None:
        """Set global random seeds for reproducibility."""
        try:
            import random
            import os
            
            random.seed(seed)
            np.random.seed(seed)
            os.environ['PYTHONHASHSEED'] = str(seed)
            
            # Set seeds for ML libraries
            try:
                import torch
                torch.manual_seed(seed)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed(seed)
                    torch.cuda.manual_seed_all(seed)
                    torch.backends.cudnn.deterministic = True
                    torch.backends.cudnn.benchmark = False
            except ImportError:
                pass
                
            try:
                import tensorflow as tf
                tf.random.set_seed(seed)
            except ImportError:
                pass
                
        except Exception as e:
            logger.warning(f"Failed setting random seeds: {e}")

    async def optimize_model_for_deployment(self, job_id: str, model_name: str = "primary") -> Dict[str, Any]:
        """Optimize trained model for deployment."""
        if job_id not in self.job_history:
            raise ValueError(f"Job {job_id} not found in history")
        
        job_info = self.job_history[job_id]
        model_path = job_info["model_paths"].get(model_name)
        
        if not model_path:
            raise ValueError(f"Model {model_name} not found for job {job_id}")
        
        logger.info(f"Optimizing model {model_name} from job {job_id} for deployment")
        
        # Load model
        if model_path.endswith('.pt'):
            import torch
            model = torch.load(model_path)
        else:
            import joblib
            model = joblib.load(model_path)
        
        optimization_results = {
            "original_model_path": model_path,
            "optimizations_applied": [],
            "performance_impact": {}
        }
        
        # Apply optimizations based on model type
        try:
            # Quantization for neural networks
            if hasattr(model, 'state_dict'):
                # PyTorch model quantization
                import torch.quantization as quant
                model.eval()
                quantized_model = quant.quantize_dynamic(
                    model, {torch.nn.Linear}, dtype=torch.qint8
                )
                
                quantized_path = model_path.replace('.pt', '_quantized.pt')
                torch.save(quantized_model, quantized_path)
                
                optimization_results["optimizations_applied"].append("dynamic_quantization")
                optimization_results["quantized_model_path"] = quantized_path
            
            # Model pruning for tree-based models
            elif hasattr(model, 'feature_importances_'):
                # Feature importance based pruning
                importance_threshold = 0.001
                important_features = model.feature_importances_ > importance_threshold
                
                optimization_results["optimizations_applied"].append("feature_pruning")
                optimization_results["features_kept"] = int(important_features.sum())
                optimization_results["features_removed"] = int((~important_features).sum())
        
        except Exception as e:
            logger.warning(f"Model optimization failed: {e}")
            optimization_results["optimization_error"] = str(e)
        
        return optimization_results

    async def compare_models(self, job_ids: List[str]) -> Dict[str, Any]:
        """Compare models across different training jobs."""
        comparison_results = {
            "jobs_compared": job_ids,
            "comparison_metrics": {},
            "best_overall": None,
            "recommendations": []
        }
        
        job_performances = {}
        
        for job_id in job_ids:
            if job_id in self.job_history:
                job_info = self.job_history[job_id]
                if "evaluation" in job_info:
                    # Get best model from this job
                    best_model = max(
                        job_info["evaluation"].items(),
                        key=lambda x: x[1].f1_score if hasattr(x[1], 'f1_score') else 0
                    )
                    job_performances[job_id] = {
                        "best_model_name": best_model[0],
                        "performance": best_model[1],
                        "training_time": job_info.get("training_duration", 0),
                        "model_type": job_info.get("model_type", "unknown")
                    }
        
        if job_performances:
            # Find overall best model
            best_job = max(
                job_performances.items(),
                key=lambda x: x[1]["performance"].f1_score if hasattr(x[1]["performance"], 'f1_score') else 0
            )
            comparison_results["best_overall"] = {
                "job_id": best_job[0],
                "model_name": best_job[1]["best_model_name"],
                "f1_score": best_job[1]["performance"].f1_score
            }
            
            # Generate recommendations
            recommendations = []
            
            # Performance vs Speed trade-off
            fast_models = [j for j, p in job_performances.items() if p["training_time"] < 300]  # 5 min
            if fast_models:
                best_fast = max(fast_models, key=lambda j: job_performances[j]["performance"].f1_score)
                recommendations.append(f"For fast training: Use job {best_fast}")
            
            # High accuracy models
            high_acc_models = [j for j, p in job_performances.items() if p["performance"].f1_score > 0.9]
            if high_acc_models:
                recommendations.append(f"High accuracy models available: {', '.join(high_acc_models)}")
            
            comparison_results["recommendations"] = recommendations
            comparison_results["comparison_metrics"] = job_performances
        
        return comparison_results


# Backward compatibility - keep original TrainingManager as alias
TrainingManager = EnhancedTrainingManager
