"""
ML训练服务主程序
"""
import asyncio
import logging
import os
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import router
from .config import get_settings
from .training import TrainingManager
from .monitoring import setup_metrics

# 配置日志
logger = logging.getLogger(__name__)

# 全局训练管理器
training_manager = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    global training_manager
    
    # 启动时初始化
    logger.info("启动ML训练服务...")
    settings = get_settings()
    
    # 初始化训练管理器
    training_manager = TrainingManager(settings)
    await training_manager.initialize()
    
    # 设置监控
    setup_metrics()
    
    logger.info("ML训练服务启动完成")
    
    yield
    
    # 关闭时清理
    logger.info("关闭ML训练服务...")
    if training_manager:
        await training_manager.cleanup()
    logger.info("ML训练服务已关闭")

def create_app() -> FastAPI:
    """创建FastAPI应用"""
    settings = get_settings()
    
    app = FastAPI(
        title="ML训练服务",
        description="恶意流量控制系统 - 机器学习模型训练服务",
        version="1.0.0",
        lifespan=lifespan
    )
    
    # 添加CORS中间件
    if settings.environment == "development":
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    
    # 注册路由
    app.include_router(router, prefix="/api/v1")
    
    return app

def setup_logging(log_path: str):
    """配置日志记录"""
    log_dir = os.path.dirname(log_path)
    os.makedirs(log_dir, exist_ok=True)
    
    # 配置Uvicorn和应用日志
    log_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "()": "uvicorn.logging.DefaultFormatter",
                "fmt": "%(levelprefix)s %(asctime)s - %(name)s - %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
        },
        "handlers": {
            "default": {
                "formatter": "default",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stderr",
            },
            "file": {
                "formatter": "default",
                "class": "logging.handlers.RotatingFileHandler",
                "filename": log_path,
                "maxBytes": 1024 * 1024 * 100,  # 100 MB
                "backupCount": 5,
            },
        },
        "loggers": {
            "": {"handlers": ["default", "file"], "level": "INFO"},
            "uvicorn.error": {"level": "INFO"},
            "uvicorn.access": {"handlers": ["default", "file"], "level": "INFO", "propagate": False},
        },
    }
    logging.config.dictConfig(log_config)

def main():
    """主函数"""
    settings = get_settings()
    
    # 创建必要的目录
    os.makedirs(settings.model_output_path, exist_ok=True)
    os.makedirs(settings.data_path, exist_ok=True)
    
    # 配置日志
    setup_logging(settings.log_path)
    
    # 启动服务
    uvicorn.run(
        "ml_training.main:create_app",
        factory=True,
        host="0.0.0.0",
        port=8085,
        reload=False
    )

if __name__ == "__main__":
    main()