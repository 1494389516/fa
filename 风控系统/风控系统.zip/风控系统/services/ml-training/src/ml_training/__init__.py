"""
ML Training Service for Malicious Traffic Detection

This package provides dual-layer model training:
- Light models (XGBoost/LightGBM) for fast initial screening
- Heavy models (Transformer) for accurate threat detection
"""

__version__ = "1.0.0"
__author__ = "Malicious Traffic Control System Team"

from .config import Config
from .models.light_model import LightModelTrainer
from .models.heavy_model import HeavyModelTrainer
from .data.processor import DataProcessor
from .features.extractor import FeatureExtractor

__all__ = [
    "Config",
    "LightModelTrainer", 
    "HeavyModelTrainer",
    "DataProcessor",
    "FeatureExtractor",
]