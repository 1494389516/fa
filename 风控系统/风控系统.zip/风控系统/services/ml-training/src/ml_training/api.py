"""
ML训练服务API路由
"""
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import logging
import time

from .advanced_training import get_advanced_trainer
from .config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter()

class TrainingRequest(BaseModel):
    """训练请求模型"""
    model_type: str  # "light" or "heavy"
    dataset_path: str
    hyperparameters: Optional[Dict[str, Any]] = None
    experiment_name: Optional[str] = None

class TrainingResponse(BaseModel):
    """训练响应模型"""
    job_id: str
    status: str
    message: str

class ModelInfo(BaseModel):
    """模型信息"""
    model_id: str
    model_type: str
    version: str
    accuracy: float
    created_at: str
    file_path: str

@router.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "healthy", "service": "ml-training"}

@router.post("/train", response_model=TrainingResponse)
async def start_training(
    request: TrainingRequest,
    background_tasks: BackgroundTasks
):
    """启动模型训练"""
    try:
        # 这里应该调用实际的训练管理器
        job_id = f"job_{request.model_type}_{hash(request.dataset_path)}"
        
        # 添加后台训练任务
        # background_tasks.add_task(training_manager.start_training, request)
        
        return TrainingResponse(
            job_id=job_id,
            status="started",
            message=f"Training job {job_id} started successfully"
        )
    except Exception as e:
        logger.error(f"Failed to start training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/jobs/{job_id}")
async def get_job_status(job_id: str):
    """获取训练任务状态"""
    # 这里应该查询实际的任务状态
    return {
        "job_id": job_id,
        "status": "running",
        "progress": 0.5,
        "metrics": {
            "accuracy": 0.85,
            "loss": 0.15
        }
    }

@router.get("/models", response_model=List[ModelInfo])
async def list_models():
    """列出所有模型"""
    # 这里应该查询实际的模型列表
    return [
        ModelInfo(
            model_id="light_model_v1",
            model_type="light",
            version="1.0.0",
            accuracy=0.92,
            created_at="2024-01-01T00:00:00Z",
            file_path="/app/models/light_model_v1.onnx"
        )
    ]

@router.get("/models/{model_id}")
async def get_model_info(model_id: str):
    """获取模型详细信息"""
    # 这里应该查询实际的模型信息
    return {
        "model_id": model_id,
        "model_type": "light",
        "version": "1.0.0",
        "accuracy": 0.92,
        "metrics": {
            "precision": 0.91,
            "recall": 0.93,
            "f1_score": 0.92
        },
        "hyperparameters": {
            "learning_rate": 0.01,
            "max_depth": 6,
            "n_estimators": 100
        }
    }

@router.post("/models/{model_id}/deploy")
async def deploy_model(model_id: str):
    """部署模型到推理服务"""
    try:
        # 这里应该调用模型部署逻辑
        return {
            "model_id": model_id,
            "status": "deployed",
            "message": f"Model {model_id} deployed successfully"
        }
    except Exception as e:
        logger.error(f"Failed to deploy model {model_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/models/{model_id}")
async def delete_model(model_id: str):
    """删除模型"""
    try:
        # 这里应该调用模型删除逻辑
        return {
            "model_id": model_id,
            "status": "deleted",
            "message": f"Model {model_id} deleted successfully"
        }
    except Exception as e:
        logger.error(f"Failed to delete model {model_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/train/advanced", response_model=TrainingResponse)
async def start_advanced_training(request: TrainingRequest):
    """启动高级风控模型训练"""
    try:
        settings = get_settings()
        advanced_trainer = get_advanced_trainer(settings)
        
        # 启动高级训练
        results = await advanced_trainer.train_comprehensive_risk_models(
            dataset_path=request.dataset_path,
            target_column=request.hyperparameters.get('target_column', 'is_malicious') if request.hyperparameters else 'is_malicious'
        )
        
        # 生成报告
        report = advanced_trainer.generate_model_report()
        
        return TrainingResponse(
            job_id=f"advanced_{int(time.time())}",
            status="completed",
            message="高级风控模型训练完成"
        )
    except Exception as e:
        logger.error(f"高级训练失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/metrics")
async def get_metrics():
    """获取训练服务指标"""
    return {
        "total_models": 5,
        "active_jobs": 2,
        "completed_jobs": 10,
        "failed_jobs": 1,
        "avg_training_time": "2h 30m",
        "best_model_accuracy": 0.95
    }
