"""
高级风控模型训练管理器
专注于风控系统的核心 - 智能威胁检测和风险评估
"""

import asyncio
import logging
import time
import uuid
import json
from pathlib import Path
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

from .models.advanced_models import (
    EnsembleRiskModel, SequentialRiskModel, RealTimeRiskScorer
)
from .config import Config

logger = logging.getLogger(__name__)

@dataclass
class AdvancedTrainingConfig:
    """高级训练配置"""
    # 数据配置
    test_ratio: float = 0.2
    val_ratio: float = 0.1
    min_samples_per_class: int = 100
    
    # 模型配置
    enable_ensemble: bool = True
    enable_sequential: bool = True
    enable_deep_learning: bool = True
    
    # 训练配置
    max_training_time: int = 3600  # 1小时
    early_stopping_patience: int = 10
    cross_validation_folds: int = 5
    
    # 性能要求
    min_precision: float = 0.90
    min_recall: float = 0.95
    max_inference_time_ms: float = 50.0

class AdvancedRiskModelTrainer:
    """高级风控模型训练器"""
    
    def __init__(self, config: Config):
        self.config = config
        self.training_config = AdvancedTrainingConfig()
        self.models: Dict[str, Any] = {}
        self.training_history: List[Dict[str, Any]] = []
        self.best_model: Optional[Any] = None
        self.best_score: float = 0.0
        
        # 创建必要的目录
        self.model_dir = Path("./models/advanced")
        self.log_dir = Path("./logs/advanced")
        self.data_dir = Path("./data/processed")
        
        for dir_path in [self.model_dir, self.log_dir, self.data_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
    
    async def train_comprehensive_risk_models(self, 
                                            dataset_path: str,
                                            target_column: str = 'is_malicious') -> Dict[str, Any]:
        """训练综合风控模型套件"""
        logger.info("开始训练综合风控模型套件...")
        start_time = time.time()
        
        try:
            # 1. 数据加载和预处理
            logger.info("步骤 1/5: 数据加载和预处理")
            X, y, feature_names = await self._load_and_preprocess_data(dataset_path, target_column)
            
            # 2. 数据分割
            logger.info("步骤 2/5: 数据分割")
            X_train, X_val, X_test, y_train, y_val, y_test = self._split_data(X, y)
            
            # 3. 训练集成模型
            logger.info("步骤 3/5: 训练集成风控模型")
            ensemble_results = await self._train_ensemble_model(
                X_train, y_train, X_val, y_val, feature_names
            )
            
            # 4. 训练序列模型
            logger.info("步骤 4/5: 训练序列风控模型")
            sequential_results = await self._train_sequential_model(
                X_train, y_train, X_val, y_val
            )
            
            # 5. 创建实时风险评分器
            logger.info("步骤 5/5: 创建实时风险评分器")
            scorer_results = await self._create_real_time_scorer(
                X_train, y_train, X_test, y_test, feature_names
            )
            
            # 综合评估
            final_evaluation = await self._comprehensive_evaluation(
                X_test, y_test, feature_names
            )
            
            training_time = time.time() - start_time
            
            # 保存最佳模型
            await self._save_best_models()
            
            results = {
                "training_time_seconds": training_time,
                "ensemble_results": ensemble_results,
                "sequential_results": sequential_results,
                "scorer_results": scorer_results,
                "final_evaluation": final_evaluation,
                "best_model_info": {
                    "model_type": type(self.best_model).__name__ if self.best_model else None,
                    "best_score": self.best_score
                },
                "data_info": {
                    "total_samples": len(X),
                    "features": len(feature_names),
                    "positive_ratio": float(np.mean(y)),
                    "train_samples": len(X_train),
                    "val_samples": len(X_val),
                    "test_samples": len(X_test)
                }
            }
            
            logger.info(f"综合风控模型训练完成，耗时 {training_time:.2f} 秒")
            return results
            
        except Exception as e:
            logger.error(f"训练过程中发生错误: {e}")
            raise
    
    async def _load_and_preprocess_data(self, dataset_path: str, target_column: str):
        """加载和预处理数据"""
        logger.info(f"从 {dataset_path} 加载数据...")
        
        # 加载数据
        if dataset_path.endswith('.csv'):
            data = pd.read_csv(dataset_path)
        elif dataset_path.endswith('.parquet'):
            data = pd.read_parquet(dataset_path)
        else:
            raise ValueError(f"不支持的文件格式: {dataset_path}")
        
        logger.info(f"原始数据形状: {data.shape}")
        
        # 检查目标列
        if target_column not in data.columns:
            raise ValueError(f"目标列 '{target_column}' 不存在于数据中")
        
        # 数据清洗
        initial_rows = len(data)
        data = data.dropna()
        logger.info(f"删除缺失值后: {len(data)} 行 (删除了 {initial_rows - len(data)} 行)")
        
        data = data.drop_duplicates()
        logger.info(f"删除重复值后: {len(data)} 行")
        
        # 分离特征和标签
        y = data[target_column].values
        X = data.drop(columns=[target_column])
        feature_names = list(X.columns)
        
        # 处理分类特征
        categorical_columns = X.select_dtypes(include=['object']).columns
        if len(categorical_columns) > 0:
            logger.info(f"处理分类特征: {list(categorical_columns)}")
            X = pd.get_dummies(X, columns=categorical_columns, drop_first=True)
            feature_names = list(X.columns)
        
        # 转换为numpy数组
        X = X.values.astype(np.float32)
        y = y.astype(np.int32)
        
        # 数据标准化
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
        
        logger.info(f"预处理后数据形状: X={X.shape}, y={y.shape}")
        logger.info(f"正样本比例: {np.mean(y):.3f}")
        
        return X, y, feature_names
    
    def _split_data(self, X: np.ndarray, y: np.ndarray):
        """分割数据"""
        unique, counts = np.unique(y, return_counts=True)
        logger.info(f"类别分布: {dict(zip(unique, counts))}")
        
        min_samples = min(counts)
        if min_samples < self.training_config.min_samples_per_class:
            logger.warning(f"最少类别样本数 {min_samples} 小于要求的 {self.training_config.min_samples_per_class}")
        
        # 第一次分割: 训练+验证 vs 测试
        X_train_val, X_test, y_train_val, y_test = train_test_split(
            X, y, 
            test_size=self.training_config.test_ratio,
            random_state=42,
            stratify=y
        )
        
        # 第二次分割: 训练 vs 验证
        val_size = self.training_config.val_ratio / (1 - self.training_config.test_ratio)
        X_train, X_val, y_train, y_val = train_test_split(
            X_train_val, y_train_val,
            test_size=val_size,
            random_state=42,
            stratify=y_train_val
        )
        
        logger.info(f"数据分割完成:")
        logger.info(f"  训练集: {X_train.shape[0]} 样本")
        logger.info(f"  验证集: {X_val.shape[0]} 样本")
        logger.info(f"  测试集: {X_test.shape[0]} 样本")
        
        return X_train, X_val, X_test, y_train, y_val, y_test
    
    async def _train_ensemble_model(self, X_train, y_train, X_val, y_val, feature_names):
        """训练集成模型"""
        logger.info("训练集成风控模型...")
        
        try:
            # 转换为DataFrame
            X_train_df = pd.DataFrame(X_train, columns=feature_names)
            X_val_df = pd.DataFrame(X_val, columns=feature_names)
            y_train_series = pd.Series(y_train)
            y_val_series = pd.Series(y_val)
            
            # 创建并训练集成模型
            ensemble_model = EnsembleRiskModel()
            ensemble_model.fit(X_train_df, y_train_series)
            
            # 验证集评估
            val_predictions = ensemble_model.predict_proba(X_val_df)
            val_binary_pred = ensemble_model.predict(X_val_df)
            
            # 计算指标
            val_auc = roc_auc_score(y_val, val_predictions)
            val_report = classification_report(y_val, val_binary_pred, output_dict=True)
            
            # 保存模型
            self.models['ensemble'] = ensemble_model
            
            # 更新最佳模型
            if val_auc > self.best_score:
                self.best_score = val_auc
                self.best_model = ensemble_model
            
            results = {
                "model_type": "ensemble",
                "validation_auc": val_auc,
                "validation_f1": val_report['weighted avg']['f1-score'],
                "validation_precision": val_report['weighted avg']['precision'],
                "validation_recall": val_report['weighted avg']['recall'],
                "model_weights": getattr(ensemble_model, 'weights', {})
            }
            
            logger.info(f"集成模型训练完成 - AUC: {val_auc:.4f}")
            return results
            
        except Exception as e:
            logger.error(f"集成模型训练失败: {e}")
            return {"error": str(e)}
    
    async def _train_sequential_model(self, X_train, y_train, X_val, y_val):
        """训练序列模型"""
        logger.info("训练序列风控模型...")
        
        try:
            if len(X_train) < 1000:
                logger.warning("数据量不足，跳过序列模型训练")
                return {"skipped": "insufficient_data"}
            
            # 转换为DataFrame
            X_train_df = pd.DataFrame(X_train)
            X_val_df = pd.DataFrame(X_val)
            y_train_series = pd.Series(y_train)
            
            # 创建并训练序列模型
            sequential_model = SequentialRiskModel(sequence_length=10)
            sequential_model.fit(X_train_df, y_train_series, epochs=50)
            
            # 验证集评估
            val_predictions = sequential_model.predict_proba(X_val_df)
            val_auc = roc_auc_score(y_val, val_predictions)
            
            # 保存模型
            self.models['sequential'] = sequential_model
            
            # 更新最佳模型
            if val_auc > self.best_score:
                self.best_score = val_auc
                self.best_model = sequential_model
            
            results = {
                "model_type": "sequential",
                "validation_auc": val_auc,
                "sequence_length": 10,
                "training_epochs": 50
            }
            
            logger.info(f"序列模型训练完成 - AUC: {val_auc:.4f}")
            return results
            
        except Exception as e:
            logger.error(f"序列模型训练失败: {e}")
            return {"error": str(e)}
    
    async def _create_real_time_scorer(self, X_train, y_train, X_test, y_test, feature_names):
        """创建实时风险评分器"""
        logger.info("创建实时风险评分器...")
        
        try:
            # 转换为DataFrame
            X_train_df = pd.DataFrame(X_train, columns=feature_names)
            X_test_df = pd.DataFrame(X_test, columns=feature_names)
            y_train_series = pd.Series(y_train)
            
            # 创建实时风险评分器
            risk_scorer = RealTimeRiskScorer()
            risk_scorer.fit(X_train_df, y_train_series)
            
            # 测试评分器性能
            test_scores = []
            inference_times = []
            
            for i in range(min(100, len(X_test))):
                start_time = time.time()
                score_result = risk_scorer.score_risk(X_test_df.iloc[[i]])
                inference_time = (time.time() - start_time) * 1000
                
                test_scores.append(score_result['risk_score'])
                inference_times.append(inference_time)
            
            # 计算性能指标
            avg_inference_time = np.mean(inference_times)
            test_auc = roc_auc_score(y_test[:len(test_scores)], test_scores)
            
            # 保存评分器
            self.models['risk_scorer'] = risk_scorer
            risk_scorer.save_models(str(self.model_dir / "risk_scorer"))
            
            results = {
                "model_type": "risk_scorer",
                "test_auc": test_auc,
                "avg_inference_time_ms": avg_inference_time,
                "max_inference_time_ms": max(inference_times),
                "min_inference_time_ms": min(inference_times),
                "meets_performance_requirement": avg_inference_time <= self.training_config.max_inference_time_ms
            }
            
            logger.info(f"实时风险评分器创建完成 - AUC: {test_auc:.4f}, 平均推理时间: {avg_inference_time:.2f}ms")
            return results
            
        except Exception as e:
            logger.error(f"实时风险评分器创建失败: {e}")
            return {"error": str(e)}
    
    async def _comprehensive_evaluation(self, X_test, y_test, feature_names):
        """综合评估所有模型"""
        logger.info("进行综合模型评估...")
        
        evaluation_results = {}
        
        for model_name, model in self.models.items():
            try:
                logger.info(f"评估模型: {model_name}")
                
                if model_name == 'risk_scorer':
                    # 特殊处理风险评分器
                    X_test_df = pd.DataFrame(X_test, columns=feature_names)
                    scores = []
                    for i in range(len(X_test)):
                        result = model.score_risk(X_test_df.iloc[[i]])
                        scores.append(result['risk_score'])
                    
                    predictions = np.array(scores)
                    binary_pred = (predictions >= 0.5).astype(int)
                    
                elif hasattr(model, 'predict_proba'):
                    X_test_df = pd.DataFrame(X_test, columns=feature_names)
                    predictions = model.predict_proba(X_test_df)
                    binary_pred = model.predict(X_test_df)
                else:
                    continue
                
                # 计算评估指标
                auc_score = roc_auc_score(y_test, predictions)
                report = classification_report(y_test, binary_pred, output_dict=True)
                
                evaluation_results[model_name] = {
                    "auc": auc_score,
                    "f1": report['weighted avg']['f1-score'],
                    "precision": report['weighted avg']['precision'],
                    "recall": report['weighted avg']['recall'],
                    "accuracy": report['accuracy']
                }
                
                logger.info(f"{model_name} - AUC: {auc_score:.4f}, F1: {report['weighted avg']['f1-score']:.4f}")
                
            except Exception as e:
                logger.error(f"评估模型 {model_name} 失败: {e}")
                evaluation_results[model_name] = {"error": str(e)}
        
        return evaluation_results
    
    async def _save_best_models(self):
        """保存最佳模型"""
        logger.info("保存最佳模型...")
        
        try:
            # 保存所有模型
            for model_name, model in self.models.items():
                model_path = self.model_dir / f"{model_name}_model.pkl"
                
                if hasattr(model, 'save_models'):
                    # 对于复杂模型，使用其自定义保存方法
                    model.save_models(str(self.model_dir / model_name))
                else:
                    # 对于简单模型，使用joblib保存
                    import joblib
                    joblib.dump(model, model_path)
                
                logger.info(f"模型 {model_name} 已保存到 {model_path}")
            
            # 保存训练配置和结果
            config_data = {
                "training_config": self.training_config.__dict__,
                "best_score": self.best_score,
                "best_model_type": type(self.best_model).__name__ if self.best_model else None,
                "training_history": self.training_history
            }
            
            config_path = self.model_dir / "training_config.json"
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            
            logger.info("训练配置已保存")
            
        except Exception as e:
            logger.error(f"保存模型失败: {e}")
    
    def generate_model_report(self) -> Dict[str, Any]:
        """生成模型训练报告"""
        report = {
            "training_summary": {
                "total_models_trained": len(self.models),
                "best_model_score": self.best_score,
                "best_model_type": type(self.best_model).__name__ if self.best_model else None
            },
            "model_performance": {},
            "recommendations": []
        }
        
        # 添加性能建议
        if self.best_score >= 0.95:
            report["recommendations"].append("模型性能优秀，可以部署到生产环境")
        elif self.best_score >= 0.90:
            report["recommendations"].append("模型性能良好，建议进一步优化后部署")
        else:
            report["recommendations"].append("模型性能需要改进，建议收集更多数据或调整特征")
        
        return report

# 创建全局训练器实例
_trainer_instance = None

def get_advanced_trainer(config: Config) -> AdvancedRiskModelTrainer:
    """获取高级训练器实例"""
    global _trainer_instance
    if _trainer_instance is None:
        _trainer_instance = AdvancedRiskModelTrainer(config)
    return _trainer_instance