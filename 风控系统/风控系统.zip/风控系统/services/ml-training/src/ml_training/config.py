"""
Configuration management for ML training service using Pydantic V2.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from functools import lru_cache

from pydantic import BaseModel, Field, PostgresDsn, validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Helper function to load settings from YAML, if it exists.
def yaml_config_settings_source(settings: BaseSettings) -> Dict[str, Any]:
    """
    A settings source that loads variables from a YAML file
    at the location specified by the `config_path` attribute.
    """
    config_path = getattr(settings.__class__.model_config, 'config_path', None)
    if config_path and Path(config_path).exists():
        import yaml
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    return {}


class DatabaseConfig(BaseModel):
    """Database configuration."""
    url: PostgresDsn = "postgresql://admin:password@postgres:5432/malicious_traffic"
    pool_size: int = 10
    timeout: int = 30


class KafkaConfig(BaseModel):
    """Kafka configuration."""
    brokers: str = "kafka:29092"
    topics: Dict[str, str] = {
        "training_data": "training-data",
        "model_updates": "model-updates",
        "evaluation_results": "evaluation-results"
    }
    consumer_group: str = "ml-training"


class LightModelConfig(BaseModel):
    """Light model (L1) configuration."""
    algorithm: str = "xgboost"
    max_depth: int = 6
    n_estimators: int = 100
    learning_rate: float = 0.1
    feature_count: int = 19
    threshold: float = Field(0.3, ge=0, le=1)
    inference_timeout_ms: int = 1
    enable_hpo: bool = True
    hpo_trials: int = 100
    hpo_timeout: int = 3600
    export_onnx: bool = True
    onnx_opset: int = 11


class HeavyModelConfig(BaseModel):
    """Heavy model (L2) configuration."""
    architecture: str = "transformer"
    model_name: str = "distilbert-base-uncased"
    max_sequence_length: int = 512
    hidden_size: int = 768
    num_attention_heads: int = 12
    num_hidden_layers: int = 6
    dropout: float = 0.1
    threshold: float = Field(0.7, ge=0, le=1)
    inference_timeout_ms: int = 50
    batch_size: int = 32
    learning_rate: float = 2e-5
    num_epochs: int = 10
    warmup_steps: int = 1000
    weight_decay: float = 0.01
    use_attention_weights: bool = True
    use_sequence_features: bool = True
    use_temporal_features: bool = True
    export_onnx: bool = True
    export_tensorrt: bool = False
    quantization: bool = True


class TrainingConfig(BaseModel):
    """Training configuration."""
    data_path: str = "data/"
    model_output_path: str = "models/"
    log_path: str = "logs/"
    train_ratio: float = 0.7
    val_ratio: float = 0.15
    test_ratio: float = 0.15
    max_samples: int = 1_000_000
    balance_classes: bool = True
    oversample_minority: bool = True
    enable_feature_selection: bool = True
    feature_selection_method: str = "mutual_info"
    max_features: int = 50
    cv_folds: int = 5
    stratified: bool = True
    early_stopping: bool = True
    patience: int = 10
    min_delta: float = 0.001

    @model_validator(mode='after')
    def check_ratios_sum_to_one(self) -> 'TrainingConfig':
        total_ratio = self.train_ratio + self.val_ratio + self.test_ratio
        if abs(total_ratio - 1.0) > 0.001:
            raise ValueError(f"Train/val/test ratios must sum to 1.0, got {total_ratio}")
        return self


class EvaluationConfig(BaseModel):
    """Model evaluation configuration."""
    metrics: List[str] = ["accuracy", "precision", "recall", "f1", "auc", "ap"]
    optimize_threshold: bool = True
    threshold_metric: str = "f1"
    light_model_latency_ms: float = 1.0
    heavy_model_latency_ms: float = 50.0
    min_accuracy: float = Field(0.95, ge=0, le=1)
    min_precision: float = Field(0.90, ge=0, le=1)
    min_recall: float = Field(0.95, ge=0, le=1)
    enable_ab_testing: bool = True
    ab_test_duration_hours: int = 24
    ab_test_traffic_split: float = 0.1


class MLFlowConfig(BaseModel):
    """MLFlow configuration."""
    tracking_uri: str = "http://mlflow:5000"
    experiment_name: str = "threat-detection"
    artifact_location: str = "s3://ml-artifacts/"
    enable_autolog: bool = True


class Config(BaseSettings):
    """Main configuration class using Pydantic BaseSettings."""
    
    # Nested configurations
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    kafka: KafkaConfig = Field(default_factory=KafkaConfig)
    light_model: LightModelConfig = Field(default_factory=LightModelConfig)
    heavy_model: HeavyModelConfig = Field(default_factory=HeavyModelConfig)
    training: TrainingConfig = Field(default_factory=TrainingConfig)
    evaluation: EvaluationConfig = Field(default_factory=EvaluationConfig)
    mlflow: MLFlowConfig = Field(default_factory=MLFlowConfig)
    
    # Top-level settings
    environment: str = "development"
    debug: bool = False
    log_level: str = "INFO"
    max_memory_gb: int = 16
    max_cpu_cores: int = 8
    gpu_enabled: bool = False
    gpu_memory_fraction: float = 0.8

    model_config = SettingsConfigDict(
        env_nested_delimiter='__',
        env_file='.env',
        env_file_encoding='utf-8',
        config_path=os.getenv("ML_CONFIG_PATH", "config/default.yaml")
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls,
        init_settings,
        env_settings,
        dotenv_settings,
        file_secret_settings,
    ):
        return (
            init_settings,
            yaml_config_settings_source,
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )

    @model_validator(mode='after')
    def ensure_paths_exist(self) -> 'Config':
        """Ensure necessary directories exist."""
        for path in [self.training.data_path, self.training.model_output_path, self.training.log_path]:
            Path(path).mkdir(parents=True, exist_ok=True)
        return self


@lru_cache()
def get_settings() -> Config:
    """
    Get the application settings.
    This function is cached to avoid reloading the settings on every call.
    """
    return Config()