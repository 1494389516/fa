"""
监控模块
"""
import logging
from prometheus_client import Counter, Histogram, Gauge, start_http_server

logger = logging.getLogger(__name__)

# Prometheus指标
training_jobs_total = Counter('training_jobs_total', 'Total number of training jobs', ['model_type', 'status'])
training_duration = Histogram('training_duration_seconds', 'Training duration in seconds', ['model_type'])
active_jobs = Gauge('active_training_jobs', 'Number of active training jobs')
model_accuracy = Gauge('model_accuracy', 'Model accuracy', ['model_id', 'model_type'])

def setup_metrics():
    """设置监控指标"""
    logger.info("设置Prometheus指标...")
    # 启动Prometheus指标服务器
    start_http_server(9090)
    logger.info("Prometheus指标服务器已启动在端口9090")