"""
Light Model Trainer (L1) - Fast Initial Screening

This module implements fast, lightweight models for initial threat screening:
- XGBoost for high-performance gradient boosting
- LightGBM for memory-efficient training
- Logistic Regression for interpretable baseline

Target: < 1ms inference time with high recall (> 95%)
"""

import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, classification_report
)
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import lightgbm as lgb
import optuna
import mlflow
import mlflow.sklearn
import mlflow.xgboost
import mlflow.lightgbm
import onnx
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType

from ..config import Config, LightModelConfig
from ..utils.metrics import calculate_metrics, optimize_threshold
from ..utils.model_export import export_to_onnx

logger = logging.getLogger(__name__)


class LightModel:
    """Trainer for lightweight models (L1) - fast initial screening."""
    
    def __init__(self, config: LightModelConfig):
        self.config = config
        self.model = None
        self.scaler = None
        self.feature_names = None
        self.threshold = config.threshold
        self.training_metrics = {}
        
    def train(self, 
              X_train: np.ndarray, 
              y_train: np.ndarray,
              X_val: Optional[np.ndarray] = None,
              y_val: Optional[np.ndarray] = None,
              feature_names: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Train light model for fast initial screening.
        
        Args:
            X_train: Training features (n_samples, n_features)
            y_train: Training labels (n_samples,)
            X_val: Validation features (optional)
            y_val: Validation labels (optional)
            feature_names: Feature names (optional)
            
        Returns:
            Training metrics and model info
        """
        logger.info(f"Training light model with algorithm: {self.config.algorithm}")
        start_time = time.time()
        
        # Store feature names
        self.feature_names = feature_names or [f"feature_{i}" for i in range(X_train.shape[1])]
        
        # Validate input
        if X_train.shape[1] != self.config.feature_count:
            logger.warning(f"Expected {self.config.feature_count} features, got {X_train.shape[1]}")
        
        # Start MLflow run
        with mlflow.start_run(run_name=f"light_model_{self.config.algorithm}"):
            # Log parameters
            mlflow.log_params({
                "algorithm": self.config.algorithm,
                "feature_count": X_train.shape[1],
                "training_samples": len(X_train),
                "positive_ratio": np.mean(y_train),
            })
            
            # Train model based on algorithm
            if self.config.algorithm == "xgboost":
                self.model = self._train_xgboost(X_train, y_train, X_val, y_val)
            elif self.config.algorithm == "lightgbm":
                self.model = self._train_lightgbm(X_train, y_train, X_val, y_val)
            elif self.config.algorithm == "logistic":
                self.model = self._train_logistic(X_train, y_train)
            else:
                raise ValueError(f"Unsupported algorithm: {self.config.algorithm}")
            
            # Evaluate model
            if X_val is not None and y_val is not None:
                val_metrics = self.evaluate(X_val, y_val)
                self.training_metrics.update(val_metrics)
                
                # Log metrics
                for metric_name, value in val_metrics.items():
                    mlflow.log_metric(f"val_{metric_name}", value)
            
            # Optimize threshold for high recall
            if X_val is not None and y_val is not None:
                self.threshold = self._optimize_threshold(X_val, y_val)
                mlflow.log_metric("optimized_threshold", self.threshold)
            
            # Log model
            if self.config.algorithm == "xgboost":
                mlflow.xgboost.log_model(self.model, "model")
            elif self.config.algorithm == "lightgbm":
                mlflow.lightgbm.log_model(self.model, "model")
            else:
                mlflow.sklearn.log_model(self.model, "model")
            
            training_time = time.time() - start_time
            mlflow.log_metric("training_time_seconds", training_time)
            
            logger.info(f"Light model training completed in {training_time:.2f}s")
            
            return {
                "algorithm": self.config.algorithm,
                "training_time": training_time,
                "threshold": self.threshold,
                "metrics": self.training_metrics,
                "feature_importance": self._get_feature_importance(),
            }
    
    def _train_xgboost(self, X_train, y_train, X_val=None, y_val=None) -> xgb.XGBClassifier:
        """Train XGBoost model."""
        logger.info("Training XGBoost model")
        
        # Hyperparameter optimization
        if self.config.enable_hpo:
            best_params = self._optimize_xgboost_hyperparameters(X_train, y_train)
        else:
            best_params = {
                "max_depth": self.config.max_depth,
                "n_estimators": self.config.n_estimators,
                "learning_rate": self.config.learning_rate,
            }
        
        # Train model with best parameters
        # Handle class imbalance
        pos = float(np.sum(y_train == 1))
        neg = float(len(y_train) - pos)
        scale_pos_weight = (neg / pos) if pos > 0 else 1.0

        model = xgb.XGBClassifier(
            **best_params,
            random_state=42,
            n_jobs=-1,
            eval_metric="logloss",
            objective="binary:logistic",
            scale_pos_weight=scale_pos_weight,
            early_stopping_rounds=10 if X_val is not None else None,
        )
        
        # Fit model
        eval_set = [(X_val, y_val)] if X_val is not None else None
        model.fit(
            X_train, y_train,
            eval_set=eval_set,
            verbose=False
        )
        
        return model
    
    def _train_lightgbm(self, X_train, y_train, X_val=None, y_val=None) -> lgb.LGBMClassifier:
        """Train LightGBM model."""
        logger.info("Training LightGBM model")
        
        # Hyperparameter optimization
        if self.config.enable_hpo:
            best_params = self._optimize_lightgbm_hyperparameters(X_train, y_train)
        else:
            best_params = {
                "max_depth": self.config.max_depth,
                "n_estimators": self.config.n_estimators,
                "learning_rate": self.config.learning_rate,
            }
        
        # Train model
        model = lgb.LGBMClassifier(
            **best_params,
            random_state=42,
            n_jobs=-1,
            verbose=-1,
            class_weight="balanced",
        )
        
        # Fit model
        eval_set = [(X_val, y_val)] if X_val is not None else None
        model.fit(
            X_train, y_train,
            eval_set=eval_set,
            callbacks=[lgb.early_stopping(10)] if X_val is not None else None,
        )
        
        return model
    
    def _train_logistic(self, X_train, y_train) -> LogisticRegression:
        """Train Logistic Regression model."""
        logger.info("Training Logistic Regression model")
        
        # Scale features for logistic regression
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        
        # Train model
        model = LogisticRegression(
            random_state=42,
            max_iter=1000,
            n_jobs=-1,
            class_weight="balanced",
        )
        model.fit(X_train_scaled, y_train)
        
        return model
    
    def _optimize_xgboost_hyperparameters(self, X_train, y_train) -> Dict[str, Any]:
        """Optimize XGBoost hyperparameters using Optuna."""
        logger.info("Optimizing XGBoost hyperparameters")
        
        def objective(trial):
            params = {
                "max_depth": trial.suggest_int("max_depth", 3, 10),
                "n_estimators": trial.suggest_int("n_estimators", 50, 300),
                "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3),
                "subsample": trial.suggest_float("subsample", 0.6, 1.0),
                "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
                "reg_alpha": trial.suggest_float("reg_alpha", 0, 10),
                "reg_lambda": trial.suggest_float("reg_lambda", 0, 10),
            }
            
            model = xgb.XGBClassifier(**params, random_state=42, n_jobs=1)
            
            # Cross-validation
            cv_scores = cross_val_score(
                model, X_train, y_train, 
                cv=3, scoring="recall",  # Optimize for recall
                n_jobs=1
            )
            return cv_scores.mean()
        
        study = optuna.create_study(direction="maximize")
        study.optimize(objective, n_trials=self.config.hpo_trials, timeout=self.config.hpo_timeout)
        
        logger.info(f"Best hyperparameters: {study.best_params}")
        return study.best_params
    
    def _optimize_lightgbm_hyperparameters(self, X_train, y_train) -> Dict[str, Any]:
        """Optimize LightGBM hyperparameters using Optuna."""
        logger.info("Optimizing LightGBM hyperparameters")
        
        def objective(trial):
            params = {
                "max_depth": trial.suggest_int("max_depth", 3, 10),
                "n_estimators": trial.suggest_int("n_estimators", 50, 300),
                "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3),
                "subsample": trial.suggest_float("subsample", 0.6, 1.0),
                "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
                "reg_alpha": trial.suggest_float("reg_alpha", 0, 10),
                "reg_lambda": trial.suggest_float("reg_lambda", 0, 10),
                "num_leaves": trial.suggest_int("num_leaves", 10, 100),
            }
            
            model = lgb.LGBMClassifier(**params, random_state=42, n_jobs=1, verbose=-1)
            
            # Cross-validation
            cv_scores = cross_val_score(
                model, X_train, y_train,
                cv=3, scoring="recall",  # Optimize for recall
                n_jobs=1
            )
            return cv_scores.mean()
        
        study = optuna.create_study(direction="maximize")
        study.optimize(objective, n_trials=self.config.hpo_trials, timeout=self.config.hpo_timeout)
        
        logger.info(f"Best hyperparameters: {study.best_params}")
        return study.best_params
    
    def _optimize_threshold(self, X_val, y_val) -> float:
        """Optimize threshold for high recall."""
        logger.info("Optimizing threshold for high recall")
        
        # Get prediction probabilities
        if self.config.algorithm == "logistic" and self.scaler:
            X_val_scaled = self.scaler.transform(X_val)
            y_proba = self.model.predict_proba(X_val_scaled)[:, 1]
        else:
            y_proba = self.model.predict_proba(X_val)[:, 1]
        
        # Find threshold that maximizes recall while maintaining reasonable precision
        best_threshold = 0.5
        best_score = 0
        
        for threshold in np.arange(0.1, 0.9, 0.05):
            y_pred = (y_proba >= threshold).astype(int)
            recall = recall_score(y_val, y_pred)
            precision = precision_score(y_val, y_pred)
            
            # Weighted score favoring recall (for initial screening)
            score = 0.8 * recall + 0.2 * precision
            
            if score > best_score and recall >= 0.95:  # Ensure high recall
                best_score = score
                best_threshold = threshold
        
        logger.info(f"Optimized threshold: {best_threshold:.3f} (score: {best_score:.3f})")
        return best_threshold
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict binary labels."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        proba = self.predict_proba(X)
        return (proba >= self.threshold).astype(int)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict probabilities."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        # Apply scaling for logistic regression
        if self.config.algorithm == "logistic" and self.scaler:
            X = self.scaler.transform(X)
        
        # Get probabilities for positive class
        assert self.model is not None
        return self.model.predict_proba(X)[:, 1]
    
    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, float]:
        """Evaluate model performance."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        # Predictions
        y_pred = self.predict(X_test)
        y_proba = self.predict_proba(X_test)
        
        # Calculate metrics
        metrics = {
            "accuracy": accuracy_score(y_test, y_pred),
            "precision": precision_score(y_test, y_pred),
            "recall": recall_score(y_test, y_pred),
            "f1": f1_score(y_test, y_pred),
            "auc": roc_auc_score(y_test, y_proba),
            "ap": average_precision_score(y_test, y_proba),
        }
        
        # Measure inference time
        start_time = time.time()
        _ = self.predict(X_test[:100])  # Sample 100 predictions
        inference_time = (time.time() - start_time) / 100 * 1000  # ms per prediction
        metrics["inference_time_ms"] = inference_time
        
        logger.info(f"Light model evaluation: {metrics}")
        return metrics
    
    def _get_feature_importance(self) -> Optional[Dict[str, float]]:
        """Get feature importance."""
        if self.model is None or self.feature_names is None:
            return None
        
        if hasattr(self.model, "feature_importances_"):
            importance = self.model.feature_importances_
        elif hasattr(self.model, "coef_"):
            importance = np.abs(self.model.coef_[0])
        else:
            return None
        
        # Normalize to Python floats to avoid typing issues
        imp_list = [float(v) for v in np.array(importance, dtype=float).tolist()]
        return dict(zip(self.feature_names, imp_list))
    
    def save_model(self, model_path: Union[str, Path]) -> None:
        """Save trained model."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        path_obj = Path(model_path)
        path_obj.parent.mkdir(parents=True, exist_ok=True)
        
        # Save model and metadata
        model_data = {
            "model": self.model,
            "scaler": self.scaler,
            "config": self.config,
            "feature_names": self.feature_names,
            "threshold": self.threshold,
            "training_metrics": self.training_metrics,
        }
        
        joblib.dump(model_data, path_obj)
        logger.info(f"Light model saved to {path_obj}")
        
        # Export to ONNX if enabled
        if self.config.export_onnx:
            onnx_path = path_obj.with_suffix(".onnx")
            self.export_to_onnx(str(onnx_path))
    
    def load_model(self, model_path: str) -> None:
        """Load trained model."""
        model_data = joblib.load(model_path)
        
        self.model = model_data["model"]
        self.scaler = model_data.get("scaler")
        self.config = model_data["config"]
        self.feature_names = model_data["feature_names"]
        self.threshold = model_data["threshold"]
        self.training_metrics = model_data["training_metrics"]
        
        logger.info(f"Light model loaded from {model_path}")
    
    def export_to_onnx(self, onnx_path: str) -> None:
        """Export model to ONNX format."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        logger.info(f"Exporting light model to ONNX: {onnx_path}")
        
        try:
            if self.config.algorithm in ["xgboost", "lightgbm"]:
                # For tree-based models, use their native ONNX export
                if self.config.algorithm == "xgboost":
                    self.model.save_model(onnx_path.replace(".onnx", ".json"))
                    # Convert to ONNX using onnxmltools (would need to install)
                    logger.warning("XGBoost ONNX export requires onnxmltools")
                else:
                    # LightGBM ONNX export
                    logger.warning("LightGBM ONNX export requires onnxmltools")
            else:
                # For sklearn models
                initial_type = [("float_input", FloatTensorType([None, self.config.feature_count]))]
                
                if self.scaler:
                    # Create pipeline with scaler
                    from sklearn.pipeline import Pipeline
                    pipeline = Pipeline([
                        ("scaler", self.scaler),
                        ("classifier", self.model)
                    ])
                    onnx_model = convert_sklearn(pipeline, initial_types=initial_type, 
                                               target_opset=self.config.onnx_opset)
                else:
                    onnx_model = convert_sklearn(self.model, initial_types=initial_type,
                                               target_opset=self.config.onnx_opset)
                
                # Save ONNX model
                with open(onnx_path, "wb") as f:
                    f.write(onnx_model.SerializeToString())
                
                logger.info(f"Light model exported to ONNX: {onnx_path}")
                
        except Exception as e:
            logger.error(f"Failed to export to ONNX: {e}")
            raise