"""
高级风控模型实现
包含多种先进的机器学习和深度学习模型
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
import joblib
import logging
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class ModelConfig:
    """模型配置"""
    model_type: str
    hyperparameters: Dict[str, Any]
    feature_columns: List[str]
    target_column: str
    validation_split: float = 0.2

class DeepFraudNet(nn.Module):
    """深度学习欺诈检测网络"""
    
    def __init__(self, input_dim: int, hidden_dims: List[int] = [512, 256, 128, 64]):
        super(DeepFraudNet, self).__init__()
        
        layers = []
        prev_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.3)
            ])
            prev_dim = hidden_dim
        
        # 输出层
        layers.append(nn.Linear(prev_dim, 1))
        layers.append(nn.Sigmoid())
        
        self.network = nn.Sequential(*layers)
        
    def forward(self, x):
        return self.network(x)

class AttentionFraudNet(nn.Module):
    """基于注意力机制的欺诈检测网络"""
    
    def __init__(self, input_dim: int, attention_dim: int = 128):
        super(AttentionFraudNet, self).__init__()
        
        self.feature_embedding = nn.Linear(input_dim, attention_dim)
        self.attention = nn.MultiheadAttention(attention_dim, num_heads=8, batch_first=True)
        self.classifier = nn.Sequential(
            nn.Linear(attention_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # 特征嵌入
        embedded = self.feature_embedding(x)
        embedded = embedded.unsqueeze(1)  # 添加序列维度
        
        # 自注意力
        attended, _ = self.attention(embedded, embedded, embedded)
        attended = attended.squeeze(1)
        
        # 分类
        output = self.classifier(attended)
        return output

class EnsembleRiskModel:
    """集成风控模型"""
    
    def __init__(self):
        self.models = {}
        self.weights = {}
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.is_fitted = False
        
    def _init_models(self) -> Dict[str, Any]:
        """初始化各种模型"""
        return {
            'xgboost': XGBClassifier(
                n_estimators=200,
                max_depth=6,
                learning_rate=0.1,
                subsample=0.8,
                colsample_bytree=0.8,
                random_state=42,
                eval_metric='logloss'
            ),
            'lightgbm': LGBMClassifier(
                n_estimators=200,
                max_depth=6,
                learning_rate=0.1,
                subsample=0.8,
                colsample_bytree=0.8,
                random_state=42,
                verbose=-1
            ),
            'catboost': CatBoostClassifier(
                iterations=200,
                depth=6,
                learning_rate=0.1,
                random_seed=42,
                verbose=False
            ),
            'random_forest': RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                n_jobs=-1
            ),
            'isolation_forest': IsolationForest(
                contamination=0.1,
                random_state=42,
                n_jobs=-1
            )
        }
    
    def fit(self, X: pd.DataFrame, y: pd.Series) -> 'EnsembleRiskModel':
        """训练集成模型"""
        logger.info("开始训练集成风控模型...")
        
        # 数据预处理
        X_scaled = self.scaler.fit_transform(X)
        
        # 初始化模型
        self.models = self._init_models()
        
        # 训练各个模型
        for name, model in self.models.items():
            logger.info(f"训练 {name} 模型...")
            try:
                if name == 'isolation_forest':
                    # 异常检测模型只需要正常数据
                    normal_data = X_scaled[y == 0] if len(y[y == 0]) > 0 else X_scaled
                    model.fit(normal_data)
                else:
                    model.fit(X_scaled, y)
                logger.info(f"{name} 模型训练完成")
            except Exception as e:
                logger.error(f"训练 {name} 模型失败: {e}")
                del self.models[name]
        
        # 计算模型权重（基于交叉验证性能）
        self._calculate_weights(X_scaled, y)
        
        self.is_fitted = True
        logger.info("集成模型训练完成")
        return self
    
    def _calculate_weights(self, X: np.ndarray, y: np.ndarray):
        """计算模型权重"""
        from sklearn.model_selection import cross_val_score
        
        scores = {}
        for name, model in self.models.items():
            if name == 'isolation_forest':
                # 异常检测模型使用不同的评估方式
                scores[name] = 0.1  # 给予较低权重
            else:
                try:
                    cv_scores = cross_val_score(model, X, y, cv=3, scoring='roc_auc')
                    scores[name] = np.mean(cv_scores)
                except:
                    scores[name] = 0.5
        
        # 归一化权重
        total_score = sum(scores.values())
        self.weights = {name: score / total_score for name, score in scores.items()}
        
        logger.info(f"模型权重: {self.weights}")
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """预测概率"""
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        X_scaled = self.scaler.transform(X)
        predictions = []
        
        for name, model in self.models.items():
            try:
                if name == 'isolation_forest':
                    # 异常检测模型返回异常分数
                    scores = model.decision_function(X_scaled)
                    # 转换为概率（异常分数越低，欺诈概率越高）
                    proba = 1 / (1 + np.exp(scores))
                else:
                    if hasattr(model, 'predict_proba'):
                        proba = model.predict_proba(X_scaled)[:, 1]
                    else:
                        proba = model.predict(X_scaled)
                
                predictions.append(proba * self.weights[name])
            except Exception as e:
                logger.error(f"模型 {name} 预测失败: {e}")
        
        # 加权平均
        ensemble_pred = np.sum(predictions, axis=0)
        return ensemble_pred
    
    def predict(self, X: pd.DataFrame, threshold: float = 0.5) -> np.ndarray:
        """预测类别"""
        proba = self.predict_proba(X)
        return (proba >= threshold).astype(int)

class SequentialRiskModel:
    """序列风控模型（用于时间序列欺诈检测）"""
    
    def __init__(self, sequence_length: int = 10, hidden_size: int = 128):
        self.sequence_length = sequence_length
        self.hidden_size = hidden_size
        self.model = None
        self.scaler = StandardScaler()
        self.is_fitted = False
        
    def _build_lstm_model(self, input_dim: int) -> nn.Module:
        """构建LSTM模型"""
        class LSTMRiskModel(nn.Module):
            def __init__(self, input_dim, hidden_size, sequence_length):
                super(LSTMRiskModel, self).__init__()
                self.hidden_size = hidden_size
                self.sequence_length = sequence_length
                
                self.lstm = nn.LSTM(
                    input_dim, 
                    hidden_size, 
                    batch_first=True, 
                    dropout=0.2,
                    num_layers=2
                )
                self.attention = nn.Linear(hidden_size, 1)
                self.classifier = nn.Sequential(
                    nn.Linear(hidden_size, 64),
                    nn.ReLU(),
                    nn.Dropout(0.3),
                    nn.Linear(64, 1),
                    nn.Sigmoid()
                )
                
            def forward(self, x):
                lstm_out, _ = self.lstm(x)
                
                # 注意力机制
                attention_weights = F.softmax(self.attention(lstm_out), dim=1)
                attended = torch.sum(lstm_out * attention_weights, dim=1)
                
                output = self.classifier(attended)
                return output
        
        return LSTMRiskModel(input_dim, self.hidden_size, self.sequence_length)
    
    def _prepare_sequences(self, X: np.ndarray) -> np.ndarray:
        """准备序列数据"""
        sequences = []
        for i in range(len(X) - self.sequence_length + 1):
            sequences.append(X[i:i + self.sequence_length])
        return np.array(sequences)
    
    def fit(self, X: pd.DataFrame, y: pd.Series, epochs: int = 100) -> 'SequentialRiskModel':
        """训练序列模型"""
        logger.info("开始训练序列风控模型...")
        
        # 数据预处理
        X_scaled = self.scaler.fit_transform(X)
        X_seq = self._prepare_sequences(X_scaled)
        y_seq = y[self.sequence_length - 1:].values
        
        # 构建模型
        self.model = self._build_lstm_model(X.shape[1])
        
        # 训练参数
        criterion = nn.BCELoss()
        optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)
        
        # 转换为张量
        X_tensor = torch.FloatTensor(X_seq)
        y_tensor = torch.FloatTensor(y_seq).unsqueeze(1)
        
        # 训练循环
        self.model.train()
        for epoch in range(epochs):
            optimizer.zero_grad()
            outputs = self.model(X_tensor)
            loss = criterion(outputs, y_tensor)
            loss.backward()
            optimizer.step()
            
            if (epoch + 1) % 20 == 0:
                logger.info(f"Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.4f}")
        
        self.is_fitted = True
        logger.info("序列模型训练完成")
        return self
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """预测概率"""
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        X_scaled = self.scaler.transform(X)
        X_seq = self._prepare_sequences(X_scaled)
        
        self.model.eval()
        with torch.no_grad():
            X_tensor = torch.FloatTensor(X_seq)
            predictions = self.model(X_tensor).numpy().flatten()
        
        return predictions

class RealTimeRiskScorer:
    """实时风险评分器"""
    
    def __init__(self):
        self.ensemble_model = EnsembleRiskModel()
        self.sequential_model = SequentialRiskModel()
        self.feature_importance = {}
        self.risk_thresholds = {
            'low': 0.3,
            'medium': 0.6,
            'high': 0.8,
            'critical': 0.95
        }
    
    def fit(self, X: pd.DataFrame, y: pd.Series):
        """训练实时风险评分器"""
        logger.info("训练实时风险评分器...")
        
        # 训练集成模型
        self.ensemble_model.fit(X, y)
        
        # 训练序列模型（如果数据足够）
        if len(X) > 100:
            self.sequential_model.fit(X, y)
        
        # 计算特征重要性
        self._calculate_feature_importance(X, y)
        
        logger.info("实时风险评分器训练完成")
    
    def _calculate_feature_importance(self, X: pd.DataFrame, y: pd.Series):
        """计算特征重要性"""
        try:
            # 使用XGBoost计算特征重要性
            xgb_model = XGBClassifier(random_state=42)
            xgb_model.fit(X, y)
            
            importance_scores = xgb_model.feature_importances_
            self.feature_importance = dict(zip(X.columns, importance_scores))
            
            # 排序
            self.feature_importance = dict(
                sorted(self.feature_importance.items(), 
                      key=lambda x: x[1], reverse=True)
            )
            
            logger.info(f"Top 5 重要特征: {list(self.feature_importance.keys())[:5]}")
            
        except Exception as e:
            logger.error(f"计算特征重要性失败: {e}")
    
    def score_risk(self, X: pd.DataFrame) -> Dict[str, Any]:
        """实时风险评分"""
        try:
            # 集成模型预测
            ensemble_score = self.ensemble_model.predict_proba(X)
            
            # 序列模型预测（如果可用）
            sequential_score = None
            if self.sequential_model.is_fitted and len(X) >= self.sequential_model.sequence_length:
                sequential_score = self.sequential_model.predict_proba(X)
            
            # 综合评分
            if sequential_score is not None:
                final_score = 0.7 * ensemble_score + 0.3 * sequential_score[-1]
            else:
                final_score = ensemble_score
            
            # 确保是标量
            if isinstance(final_score, np.ndarray):
                final_score = final_score[0] if len(final_score) > 0 else 0.0
            
            # 风险等级
            risk_level = self._get_risk_level(final_score)
            
            # 特征贡献分析
            feature_contributions = self._analyze_feature_contributions(X)
            
            return {
                'risk_score': float(final_score),
                'risk_level': risk_level,
                'ensemble_score': float(ensemble_score[0]) if isinstance(ensemble_score, np.ndarray) else float(ensemble_score),
                'sequential_score': float(sequential_score[-1]) if sequential_score is not None else None,
                'feature_contributions': feature_contributions,
                'timestamp': pd.Timestamp.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"风险评分失败: {e}")
            return {
                'risk_score': 0.0,
                'risk_level': 'unknown',
                'error': str(e),
                'timestamp': pd.Timestamp.now().isoformat()
            }
    
    def _get_risk_level(self, score: float) -> str:
        """获取风险等级"""
        if score >= self.risk_thresholds['critical']:
            return 'critical'
        elif score >= self.risk_thresholds['high']:
            return 'high'
        elif score >= self.risk_thresholds['medium']:
            return 'medium'
        elif score >= self.risk_thresholds['low']:
            return 'low'
        else:
            return 'minimal'
    
    def _analyze_feature_contributions(self, X: pd.DataFrame) -> Dict[str, float]:
        """分析特征贡献度"""
        contributions = {}
        
        try:
            # 基于特征重要性和当前值计算贡献度
            for feature, importance in list(self.feature_importance.items())[:10]:
                if feature in X.columns:
                    value = X[feature].iloc[0] if len(X) > 0 else 0
                    # 简单的贡献度计算（可以更复杂）
                    contribution = importance * abs(value)
                    contributions[feature] = float(contribution)
        
        except Exception as e:
            logger.error(f"特征贡献分析失败: {e}")
        
        return contributions
    
    def save_models(self, model_dir: str):
        """保存模型"""
        import os
        os.makedirs(model_dir, exist_ok=True)
        
        # 保存集成模型
        joblib.dump(self.ensemble_model, os.path.join(model_dir, 'ensemble_model.pkl'))
        
        # 保存序列模型
        if self.sequential_model.is_fitted:
            torch.save(self.sequential_model.model.state_dict(), 
                      os.path.join(model_dir, 'sequential_model.pth'))
        
        # 保存其他配置
        config = {
            'feature_importance': self.feature_importance,
            'risk_thresholds': self.risk_thresholds
        }
        joblib.dump(config, os.path.join(model_dir, 'config.pkl'))
        
        logger.info(f"模型已保存到 {model_dir}")
    
    def load_models(self, model_dir: str):
        """加载模型"""
        import os
        
        # 加载集成模型
        ensemble_path = os.path.join(model_dir, 'ensemble_model.pkl')
        if os.path.exists(ensemble_path):
            self.ensemble_model = joblib.load(ensemble_path)
        
        # 加载序列模型
        sequential_path = os.path.join(model_dir, 'sequential_model.pth')
        if os.path.exists(sequential_path):
            # 需要重新构建模型结构
            pass
        
        # 加载配置
        config_path = os.path.join(model_dir, 'config.pkl')
        if os.path.exists(config_path):
            config = joblib.load(config_path)
            self.feature_importance = config.get('feature_importance', {})
            self.risk_thresholds = config.get('risk_thresholds', self.risk_thresholds)
        
        logger.info(f"模型已从 {model_dir} 加载")