"""
Heavy Model Trainer (L2) - Accurate Threat Detection

This module implements sophisticated Transformer-based models for accurate threat detection:
- Custom Transformer architecture for sequence modeling
- Pre-trained BERT-like models for transfer learning
- Attention mechanisms for interpretability
- Multi-modal feature fusion

Target: < 50ms inference time with high precision (> 90%)
"""

import logging
import time
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from torch.optim import AdamW
from torch.optim.lr_scheduler import get_linear_schedule_with_warmup
from transformers import (
    AutoModel, AutoTokenizer, AutoConfig,
    TrainingArguments, Trainer, EarlyStoppingCallback
)
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, classification_report
)
import mlflow
import mlflow.pytorch
import optuna

from ..config import HeavyModelConfig
from ..utils.metrics import calculate_metrics
from ..data.sequence_processor import SequenceProcessor

logger = logging.getLogger(__name__)


class ThreatTransformer(nn.Module):
    """Custom Transformer model for threat detection."""
    
    def __init__(self, config: HeavyModelConfig):
        super().__init__()
        self.config = config
        
        # Input embedding layers
        self.feature_embedding = nn.Linear(19, config.hidden_size)  # Basic features
        self.sequence_embedding = nn.Linear(config.max_sequence_length, config.hidden_size)
        self.temporal_embedding = nn.Linear(24, config.hidden_size)  # Hour embeddings
        
        # Positional encoding
        self.pos_encoding = PositionalEncoding(config.hidden_size, config.max_sequence_length)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.hidden_size,
            nhead=config.num_attention_heads,
            dim_feedforward=config.hidden_size * 4,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, 
            num_layers=config.num_hidden_layers
        )
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_size // 2, 2)  # Binary classification
        )
        
        # Attention weights for interpretability
        self.attention_weights = None
        
    def forward(self, 
                basic_features: torch.Tensor,
                sequence_features: Optional[torch.Tensor] = None,
                temporal_features: Optional[torch.Tensor] = None,
                attention_mask: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        
        batch_size = basic_features.size(0)
        
        # Embed basic features
        basic_emb = self.feature_embedding(basic_features)  # [batch, hidden_size]
        
        # Create sequence input
        if sequence_features is not None:
            seq_emb = self.sequence_embedding(sequence_features)
            inputs = torch.stack([basic_emb, seq_emb], dim=1)  # [batch, 2, hidden_size]
        else:
            inputs = basic_emb.unsqueeze(1)  # [batch, 1, hidden_size]
        
        # Add temporal features if available
        if temporal_features is not None:
            temp_emb = self.temporal_embedding(temporal_features)
            inputs = torch.cat([inputs, temp_emb.unsqueeze(1)], dim=1)
        
        # Add positional encoding
        inputs = self.pos_encoding(inputs)
        
        # Apply transformer
        if attention_mask is not None:
            # Create causal mask for transformer
            seq_len = inputs.size(1)
            causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
            causal_mask = causal_mask.to(inputs.device)
        else:
            causal_mask = None
        
        transformer_output = self.transformer(inputs, mask=causal_mask)
        
        # Global average pooling
        if attention_mask is not None:
            # Masked average pooling
            mask_expanded = attention_mask.unsqueeze(-1).expand_as(transformer_output)
            sum_embeddings = torch.sum(transformer_output * mask_expanded, dim=1)
            sum_mask = torch.sum(mask_expanded, dim=1)
            pooled_output = sum_embeddings / sum_mask
        else:
            pooled_output = torch.mean(transformer_output, dim=1)
        
        # Classification
        logits = self.classifier(pooled_output)
        
        # Store attention weights for interpretability
        if self.config.use_attention_weights:
            self.attention_weights = self._extract_attention_weights(transformer_output)
        
        return {
            "logits": logits,
            "hidden_states": transformer_output,
            "pooled_output": pooled_output,
            "attention_weights": self.attention_weights
        }
    
    def _extract_attention_weights(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Extract attention weights for interpretability."""
        # This is a simplified version - in practice, you'd extract from transformer layers
        return torch.softmax(torch.mean(hidden_states, dim=-1), dim=-1)


class PositionalEncoding(nn.Module):
    """Positional encoding for transformer."""
    
    def __init__(self, d_model: int, max_len: int = 5000):
        super().__init__()
        
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * 
                           (-np.log(10000.0) / d_model))
        
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        
        self.register_buffer('pe', pe)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:x.size(1), :].transpose(0, 1)


class HeavyModel:
    """Trainer for heavy models (L2) - accurate threat detection."""
    
    def __init__(self, config: HeavyModelConfig):
        self.config = config
        self.model = None
        self.tokenizer = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.threshold = config.threshold
        self.training_metrics = {}
        self.sequence_processor = SequenceProcessor()
        self._set_torch_seed(42)
        
        logger.info(f"Heavy model trainer initialized on device: {self.device}")
    
    def train(self,
              X_train: np.ndarray,
              y_train: np.ndarray,
              X_val: Optional[np.ndarray] = None,
              y_val: Optional[np.ndarray] = None,
              sequence_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Train heavy model for accurate threat detection.
        
        Args:
            X_train: Basic training features (n_samples, 19)
            y_train: Training labels (n_samples,)
            X_val: Validation features (optional)
            y_val: Validation labels (optional)
            sequence_data: Additional sequence and temporal data
            
        Returns:
            Training metrics and model info
        """
        logger.info(f"Training heavy model with architecture: {self.config.architecture}")
        start_time = time.time()
        
        # Start MLflow run
        with mlflow.start_run(run_name=f"heavy_model_{self.config.architecture}"):
            # Log parameters
            mlflow.log_params({
                "architecture": self.config.architecture,
                "hidden_size": self.config.hidden_size,
                "num_layers": self.config.num_hidden_layers,
                "num_heads": self.config.num_attention_heads,
                "training_samples": len(X_train),
                "positive_ratio": np.mean(y_train),
            })
            
            # Prepare data
            train_loader, val_loader = self._prepare_data(
                X_train, y_train, X_val, y_val, sequence_data
            )

            # Compute class weights for imbalanced data
            try:
                pos = float(np.sum(y_train == 1))
                neg = float(len(y_train) - pos)
                w0 = (pos + neg) / (2.0 * max(neg, 1.0))
                w1 = (pos + neg) / (2.0 * max(pos, 1.0))
                class_weights = torch.tensor([w0, w1], dtype=torch.float, device=self.device)
            except Exception:
                class_weights = None
            
            # Initialize model
            if self.config.architecture == "transformer":
                self.model = ThreatTransformer(self.config)
            else:
                raise ValueError(f"Unsupported architecture: {self.config.architecture}")
            
            self.model.to(self.device)
            
            # Train model
            self._train_custom_transformer(train_loader, val_loader, class_weights)
            
            # Evaluate model
            if val_loader is not None:
                val_metrics = self.evaluate_dataloader(val_loader)
                self.training_metrics.update(val_metrics)
                
                # Log metrics
                for metric_name, value in val_metrics.items():
                    mlflow.log_metric(f"val_{metric_name}", value)
            
            # Optimize threshold
            if val_loader is not None:
                self.threshold = self._optimize_threshold(val_loader)
                mlflow.log_metric("optimized_threshold", self.threshold)
            
            # Log model
            mlflow.pytorch.log_model(self.model, "model")
            
            training_time = time.time() - start_time
            mlflow.log_metric("training_time_seconds", training_time)
            
            logger.info(f"Heavy model training completed in {training_time:.2f}s")
            
            return {
                "architecture": self.config.architecture,
                "training_time": training_time,
                "threshold": self.threshold,
                "metrics": self.training_metrics,
                "model_size_mb": self._get_model_size(),
            }
    
    def _prepare_data(self, X_train, y_train, X_val, y_val, sequence_data):
        """Prepare data loaders."""
        # Convert to tensors
        X_train_tensor = torch.FloatTensor(X_train)
        y_train_tensor = torch.LongTensor(y_train)
        
        # Process sequence data if available
        if sequence_data and self.config.use_sequence_features:
            seq_train = self.sequence_processor.process_sequences(
                sequence_data.get("train_sequences", [])
            )
            seq_train_tensor = torch.FloatTensor(seq_train)
        else:
            seq_train_tensor = None
        
        # Create training dataset
        if seq_train_tensor is not None:
            train_dataset = TensorDataset(X_train_tensor, seq_train_tensor, y_train_tensor)
        else:
            train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        
        train_loader = DataLoader(
            train_dataset,
            batch_size=self.config.batch_size,
            shuffle=True,
            num_workers=4
        )
        
        # Validation data
        val_loader = None
        if X_val is not None and y_val is not None:
            X_val_tensor = torch.FloatTensor(X_val)
            y_val_tensor = torch.LongTensor(y_val)
            
            if seq_train_tensor is not None and sequence_data:
                seq_val = self.sequence_processor.process_sequences(
                    sequence_data.get("val_sequences", [])
                )
                seq_val_tensor = torch.FloatTensor(seq_val)
                val_dataset = TensorDataset(X_val_tensor, seq_val_tensor, y_val_tensor)
            else:
                val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
            
            val_loader = DataLoader(
                val_dataset,
                batch_size=self.config.batch_size,
                shuffle=False,
                num_workers=4
            )
        
        return train_loader, val_loader
    
    def _train_custom_transformer(self, train_loader, val_loader, class_weights=None):
        """Train custom transformer model."""
        logger.info("Training custom transformer model")
        
        # Optimizer and scheduler
        optimizer = AdamW(
            self.model.parameters(),
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay
        )
        
        total_steps = len(train_loader) * self.config.num_epochs
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=self.config.warmup_steps,
            num_training_steps=total_steps
        )
        # AMP scaler for mixed-precision training
        scaler = torch.cuda.amp.GradScaler(enabled=torch.cuda.is_available())
        
        # Training loop
        best_val_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(self.config.num_epochs):
            # Training phase
            self.model.train()
            total_loss = 0
            
            for batch in train_loader:
                optimizer.zero_grad()

                with torch.cuda.amp.autocast(enabled=torch.cuda.is_available()):
                    if len(batch) == 3:  # With sequence features
                        basic_features, seq_features, labels = batch
                        basic_features = basic_features.to(self.device)
                        seq_features = seq_features.to(self.device)
                        labels = labels.to(self.device)
                        outputs = self.model(basic_features, seq_features)
                    else:  # Basic features only
                        basic_features, labels = batch
                        basic_features = basic_features.to(self.device)
                        labels = labels.to(self.device)
                        outputs = self.model(basic_features)

                    loss = (
                        F.cross_entropy(
                            outputs["logits"],
                            labels,
                            weight=class_weights,
                            label_smoothing=getattr(self.config, "label_smoothing", 0.0),
                        )
                        if class_weights is not None
                        else F.cross_entropy(
                            outputs["logits"],
                            labels,
                            label_smoothing=getattr(self.config, "label_smoothing", 0.0),
                        )
                    )

                # Backward with AMP scaler
                scaler.scale(loss).backward()

                # Gradient clipping
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)

                # Optimizer step with AMP scaler
                scaler.step(optimizer)
                scaler.update()

                scheduler.step()

                total_loss += loss.item()
            
            avg_train_loss = total_loss / len(train_loader)
            
            # Validation phase
            if val_loader is not None:
                val_loss = self._validate(val_loader)
                
                logger.info(f"Epoch {epoch+1}/{self.config.num_epochs}: "
                          f"Train Loss: {avg_train_loss:.4f}, Val Loss: {val_loss:.4f}")
                
                # Early stopping
                if self.config.early_stopping and val_loss < best_val_loss - self.config.min_delta:
                    best_val_loss = val_loss
                    patience_counter = 0
                    torch.save(self.model.state_dict(), "best_model.pt")
                elif self.config.early_stopping:
                    patience_counter += 1
                    if patience_counter >= self.config.patience:
                        logger.info("Early stopping triggered")
                        break
            else:
                logger.info(f"Epoch {epoch+1}/{self.config.num_epochs}: "
                          f"Train Loss: {avg_train_loss:.4f}")
        
        # Load best model
        if val_loader is not None:
            self.model.load_state_dict(torch.load("best_model.pt"))
    
    def _validate(self, val_loader):
        """Validate model."""
        self.model.eval()
        total_loss = 0
        
        with torch.no_grad():
            for batch in val_loader:
                if len(batch) == 3:
                    basic_features, seq_features, labels = batch
                    basic_features = basic_features.to(self.device)
                    seq_features = seq_features.to(self.device)
                    labels = labels.to(self.device)
                    
                    outputs = self.model(basic_features, seq_features)
                else:
                    basic_features, labels = batch
                    basic_features = basic_features.to(self.device)
                    labels = labels.to(self.device)
                    
                    outputs = self.model(basic_features)
                
                loss = F.cross_entropy(outputs["logits"], labels)
                total_loss += loss.item()
        
        return total_loss / len(val_loader)
    
    
    def _optimize_threshold(self, val_loader) -> float:
        """Optimize threshold for high precision."""
        logger.info("Optimizing threshold for high precision")
        
        # Get all predictions
        all_probs = []
        all_labels = []
        
        self.model.eval()
        with torch.no_grad():
            for batch in val_loader:
                if len(batch) == 3:
                    basic_features, seq_features, labels = batch
                    basic_features = basic_features.to(self.device)
                    seq_features = seq_features.to(self.device)
                    outputs = self.model(basic_features, seq_features)
                else:
                    basic_features, labels = batch
                    basic_features = basic_features.to(self.device)
                    outputs = self.model(basic_features)
                
                probs = F.softmax(outputs["logits"], dim=1)[:, 1]
                all_probs.extend(probs.cpu().numpy())
                all_labels.extend(labels.numpy())
        
        all_probs = np.array(all_probs)
        all_labels = np.array(all_labels)
        
        # Find threshold that maximizes precision while maintaining reasonable recall
        best_threshold = 0.5
        best_score = 0
        
        for threshold in np.arange(0.3, 0.9, 0.05):
            y_pred = (all_probs >= threshold).astype(int)
            precision = precision_score(all_labels, y_pred)
            recall = recall_score(all_labels, y_pred)
            
            # Weighted score favoring precision (for accurate detection)
            score = 0.8 * precision + 0.2 * recall
            
            if score > best_score and precision >= 0.90:  # Ensure high precision
                best_score = score
                best_threshold = threshold
        
        logger.info(f"Optimized threshold: {best_threshold:.3f} (score: {best_score:.3f})")
        return best_threshold
    
    def predict(self, X: np.ndarray, sequence_data: Optional[np.ndarray] = None) -> np.ndarray:
        """Predict binary labels."""
        proba = self.predict_proba(X, sequence_data)
        return (proba >= self.threshold).astype(int)
    
    def predict_proba(self, X: np.ndarray, sequence_data: Optional[np.ndarray] = None) -> np.ndarray:
        """Predict probabilities."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        self.model.eval()
        
        X_tensor = torch.FloatTensor(X).to(self.device)
        seq_tensor = None
        if sequence_data is not None:
            seq_tensor = torch.FloatTensor(sequence_data).to(self.device)
        
        with torch.no_grad():
            if seq_tensor is not None:
                outputs = self.model(X_tensor, seq_tensor)
            else:
                outputs = self.model(X_tensor)
            
            probs = F.softmax(outputs["logits"], dim=1)[:, 1]
            return probs.cpu().numpy()
    
    def evaluate_dataloader(self, data_loader) -> Dict[str, float]:
        """Evaluate model on data loader."""
        all_preds = []
        all_probs = []
        all_labels = []
        
        self.model.eval()
        inference_times = []
        
        with torch.no_grad():
            for batch in data_loader:
                start_time = time.time()
                
                if len(batch) == 3:
                    basic_features, seq_features, labels = batch
                    basic_features = basic_features.to(self.device)
                    seq_features = seq_features.to(self.device)
                    outputs = self.model(basic_features, seq_features)
                else:
                    basic_features, labels = batch
                    basic_features = basic_features.to(self.device)
                    outputs = self.model(basic_features)
                
                inference_time = (time.time() - start_time) / len(labels) * 1000
                inference_times.append(inference_time)
                
                probs = F.softmax(outputs["logits"], dim=1)[:, 1]
                preds = (probs >= self.threshold).long()
                
                all_probs.extend(probs.cpu().numpy())
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.numpy())
        
        all_probs = np.array(all_probs)
        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)
        
        # Calculate metrics
        metrics = {
            "accuracy": accuracy_score(all_labels, all_preds),
            "precision": precision_score(all_labels, all_preds),
            "recall": recall_score(all_labels, all_preds),
            "f1": f1_score(all_labels, all_preds),
            "auc": roc_auc_score(all_labels, all_probs),
            "ap": average_precision_score(all_labels, all_probs),
            "inference_time_ms": np.mean(inference_times),
        }
        
        logger.info(f"Heavy model evaluation: {metrics}")
        return metrics
    
    def _get_model_size(self) -> float:
        """Get model size in MB."""
        if self.model is None:
            return 0.0
        
        param_size = 0
        for param in self.model.parameters():
            param_size += param.nelement() * param.element_size()
        
        buffer_size = 0
        for buffer in self.model.buffers():
            buffer_size += buffer.nelement() * buffer.element_size()
        
        size_mb = (param_size + buffer_size) / 1024 / 1024
        return size_mb

    def _set_torch_seed(self, seed: int = 42) -> None:
        """Set torch-related random seeds for reproducibility."""
        try:
            import random
            random.seed(seed)
            np.random.seed(seed)
            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        except Exception as e:
            logger.warning(f"Failed setting torch random seeds: {e}")
    
    def save_model(self, model_path: str) -> None:
        """Save trained model."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        model_path = Path(model_path)
        model_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save model state dict and config
        torch.save({
            "model_state_dict": self.model.state_dict(),
            "config": self.config,
            "threshold": self.threshold,
            "training_metrics": self.training_metrics,
        }, model_path)
        
        logger.info(f"Heavy model saved to {model_path}")
        
        # Export to ONNX if enabled
        if self.config.export_onnx:
            onnx_path = model_path.with_suffix(".onnx")
            self.export_to_onnx(str(onnx_path))
    
    def load_model(self, model_path: str) -> None:
        """Load trained model."""
        checkpoint = torch.load(model_path, map_location=self.device)
        
        self.config = checkpoint["config"]
        self.threshold = checkpoint["threshold"]
        self.training_metrics = checkpoint["training_metrics"]
        
        # Recreate model
        if self.config.architecture == "transformer":
            self.model = ThreatTransformer(self.config)
        else:
            raise ValueError(f"Unsupported architecture: {self.config.architecture}")
        
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.model.to(self.device)
        
        logger.info(f"Heavy model loaded from {model_path}")
    
    def export_to_onnx(self, onnx_path: str) -> None:
        """Export model to ONNX format."""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        logger.info(f"Exporting heavy model to ONNX: {onnx_path}")
        
        try:
            self.model.eval()
            
            # Create dummy input
            dummy_basic = torch.randn(1, 19).to(self.device)
            dummy_seq = torch.randn(1, self.config.max_sequence_length).to(self.device)
            
            # Export to ONNX
            torch.onnx.export(
                self.model,
                (dummy_basic, dummy_seq),
                onnx_path,
                export_params=True,
                opset_version=11,
                do_constant_folding=True,
                input_names=["basic_features", "sequence_features"],
                output_names=["logits"],
                dynamic_axes={
                    "basic_features": {0: "batch_size"},
                    "sequence_features": {0: "batch_size"},
                    "logits": {0: "batch_size"}
                }
            )
            
            logger.info(f"Heavy model exported to ONNX: {onnx_path}")
            
        except Exception as e:
            logger.error(f"Failed to export to ONNX: {e}")
            raise