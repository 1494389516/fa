"""
模型导出工具
支持导出到ONNX、TorchScript等格式
"""

import torch
import torch.onnx
import numpy as np
from pathlib import Path
from typing import Tuple, Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


def export_to_onnx(model: torch.nn.Module, 
                   model_path: str, 
                   input_shape: Tuple[int, ...],
                   opset_version: int = 11,
                   dynamic_axes: Optional[Dict[str, Dict[int, str]]] = None) -> bool:
    """
    导出PyTorch模型到ONNX格式
    
    Args:
        model: PyTorch模型
        model_path: 导出路径
        input_shape: 输入形状 (不包括batch维度)
        opset_version: ONNX opset版本
        dynamic_axes: 动态轴配置
    
    Returns:
        是否导出成功
    """
    try:
        # 确保模型在评估模式
        model.eval()
        
        # 创建示例输入
        dummy_input = torch.randn(1, *input_shape)
        
        # 默认动态轴配置
        if dynamic_axes is None:
            dynamic_axes = {
                'input': {0: 'batch_size'},
                'output': {0: 'batch_size'}
            }
        
        # 创建输出目录
        Path(model_path).parent.mkdir(parents=True, exist_ok=True)
        
        # 导出到ONNX
        torch.onnx.export(
            model,
            dummy_input,
            model_path,
            export_params=True,
            opset_version=opset_version,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['output'],
            dynamic_axes=dynamic_axes,
            verbose=False
        )
        
        logger.info(f"Model successfully exported to ONNX: {model_path}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to export model to ONNX: {e}")
        return False


def export_to_torchscript(model: torch.nn.Module,
                         model_path: str,
                         input_shape: Tuple[int, ...],
                         use_trace: bool = True) -> bool:
    """
    导出PyTorch模型到TorchScript格式
    
    Args:
        model: PyTorch模型
        model_path: 导出路径
        input_shape: 输入形状
        use_trace: 是否使用trace模式 (否则使用script模式)
    
    Returns:
        是否导出成功
    """
    try:
        model.eval()
        
        # 创建输出目录
        Path(model_path).parent.mkdir(parents=True, exist_ok=True)
        
        if use_trace:
            # 使用trace模式
            dummy_input = torch.randn(1, *input_shape)
            traced_model = torch.jit.trace(model, dummy_input)
            traced_model.save(model_path)
        else:
            # 使用script模式
            scripted_model = torch.jit.script(model)
            scripted_model.save(model_path)
        
        logger.info(f"Model successfully exported to TorchScript: {model_path}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to export model to TorchScript: {e}")
        return False


def export_sklearn_to_onnx(model, model_path: str, input_shape: Tuple[int, ...]) -> bool:
    """
    导出sklearn模型到ONNX格式
    
    Args:
        model: sklearn模型
        model_path: 导出路径
        input_shape: 输入形状
    
    Returns:
        是否导出成功
    """
    try:
        from skl2onnx import convert_sklearn
        from skl2onnx.common.data_types import FloatTensorType
        
        # 定义输入类型
        initial_type = [('float_input', FloatTensorType([None, input_shape[-1]]))]
        
        # 转换模型
        onnx_model = convert_sklearn(model, initial_types=initial_type)
        
        # 创建输出目录
        Path(model_path).parent.mkdir(parents=True, exist_ok=True)
        
        # 保存模型
        with open(model_path, "wb") as f:
            f.write(onnx_model.SerializeToString())
        
        logger.info(f"Sklearn model successfully exported to ONNX: {model_path}")
        return True
        
    except ImportError:
        logger.error("skl2onnx not installed. Please install it to export sklearn models.")
        return False
    except Exception as e:
        logger.error(f"Failed to export sklearn model to ONNX: {e}")
        return False


def export_xgboost_to_onnx(model, model_path: str, input_shape: Tuple[int, ...]) -> bool:
    """
    导出XGBoost模型到ONNX格式
    
    Args:
        model: XGBoost模型
        model_path: 导出路径
        input_shape: 输入形状
    
    Returns:
        是否导出成功
    """
    try:
        from onnxmltools import convert_xgboost
        from onnxmltools.convert.common.data_types import FloatTensorType
        
        # 定义输入类型
        initial_type = [('float_input', FloatTensorType([None, input_shape[-1]]))]
        
        # 转换模型
        onnx_model = convert_xgboost(model, initial_types=initial_type)
        
        # 创建输出目录
        Path(model_path).parent.mkdir(parents=True, exist_ok=True)
        
        # 保存模型
        with open(model_path, "wb") as f:
            f.write(onnx_model.SerializeToString())
        
        logger.info(f"XGBoost model successfully exported to ONNX: {model_path}")
        return True
        
    except ImportError:
        logger.error("onnxmltools not installed. Please install it to export XGBoost models.")
        return False
    except Exception as e:
        logger.error(f"Failed to export XGBoost model to ONNX: {e}")
        return False


def validate_onnx_model(model_path: str, input_shape: Tuple[int, ...]) -> bool:
    """
    验证ONNX模型是否有效
    
    Args:
        model_path: ONNX模型路径
        input_shape: 输入形状
    
    Returns:
        模型是否有效
    """
    try:
        import onnx
        import onnxruntime as ort
        
        # 加载并检查ONNX模型
        onnx_model = onnx.load(model_path)
        onnx.checker.check_model(onnx_model)
        
        # 创建推理会话
        ort_session = ort.InferenceSession(model_path)
        
        # 创建测试输入
        test_input = np.random.randn(1, *input_shape).astype(np.float32)
        
        # 运行推理
        ort_inputs = {ort_session.get_inputs()[0].name: test_input}
        ort_outputs = ort_session.run(None, ort_inputs)
        
        logger.info(f"ONNX model validation successful: {model_path}")
        logger.info(f"Input shape: {test_input.shape}, Output shape: {ort_outputs[0].shape}")
        
        return True
        
    except ImportError:
        logger.error("onnx or onnxruntime not installed. Cannot validate ONNX model.")
        return False
    except Exception as e:
        logger.error(f"ONNX model validation failed: {e}")
        return False


def get_model_info(model_path: str) -> Dict[str, Any]:
    """
    获取ONNX模型信息
    
    Args:
        model_path: ONNX模型路径
    
    Returns:
        模型信息字典
    """
    try:
        import onnx
        
        model = onnx.load(model_path)
        
        info = {
            'ir_version': model.ir_version,
            'producer_name': model.producer_name,
            'producer_version': model.producer_version,
            'domain': model.domain,
            'model_version': model.model_version,
            'doc_string': model.doc_string,
            'inputs': [],
            'outputs': []
        }
        
        # 获取输入信息
        for input_tensor in model.graph.input:
            input_info = {
                'name': input_tensor.name,
                'type': input_tensor.type.tensor_type.elem_type,
                'shape': [dim.dim_value for dim in input_tensor.type.tensor_type.shape.dim]
            }
            info['inputs'].append(input_info)
        
        # 获取输出信息
        for output_tensor in model.graph.output:
            output_info = {
                'name': output_tensor.name,
                'type': output_tensor.type.tensor_type.elem_type,
                'shape': [dim.dim_value for dim in output_tensor.type.tensor_type.shape.dim]
            }
            info['outputs'].append(output_info)
        
        return info
        
    except Exception as e:
        logger.error(f"Failed to get model info: {e}")
        return {}