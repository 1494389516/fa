"""
模型评估指标计算工具
"""

import numpy as np
from typing import Dict, Any, Optional, Tuple
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, precision_recall_curve, confusion_matrix,
    classification_report
)


def calculate_metrics(y_true: np.ndarray, y_pred: np.ndarray, 
                     y_proba: Optional[np.ndarray] = None) -> Dict[str, float]:
    """
    计算模型评估指标
    
    Args:
        y_true: 真实标签
        y_pred: 预测标签
        y_proba: 预测概率 (可选)
    
    Returns:
        包含各种指标的字典
    """
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
        'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
        'f1': f1_score(y_true, y_pred, average='weighted', zero_division=0)
    }
    
    # 如果提供了概率，计算AUC
    if y_proba is not None:
        try:
            if y_proba.ndim == 2 and y_proba.shape[1] == 2:
                # 二分类情况
                metrics['auc'] = roc_auc_score(y_true, y_proba[:, 1])
            elif y_proba.ndim == 1:
                # 单列概率
                metrics['auc'] = roc_auc_score(y_true, y_proba)
            else:
                # 多分类情况
                metrics['auc'] = roc_auc_score(y_true, y_proba, multi_class='ovr', average='weighted')
        except Exception as e:
            print(f"Warning: Could not calculate AUC: {e}")
            metrics['auc'] = 0.0
    
    return metrics


def optimize_threshold(y_true: np.ndarray, y_proba: np.ndarray) -> Tuple[float, Dict[str, float]]:
    """
    优化二分类阈值
    
    Args:
        y_true: 真实标签
        y_proba: 预测概率
    
    Returns:
        最优阈值和对应的指标
    """
    if y_proba.ndim == 2:
        y_proba = y_proba[:, 1]  # 取正类概率
    
    precision, recall, thresholds = precision_recall_curve(y_true, y_proba)
    
    # 计算F1分数
    f1_scores = 2 * (precision * recall) / (precision + recall + 1e-8)
    
    # 找到F1分数最高的阈值
    best_threshold_idx = f1_scores.argmax()
    best_threshold = thresholds[best_threshold_idx] if best_threshold_idx < len(thresholds) else 0.5
    
    # 计算最优阈值下的指标
    y_pred_optimal = (y_proba >= best_threshold).astype(int)
    optimal_metrics = calculate_metrics(y_true, y_pred_optimal, y_proba.reshape(-1, 1))
    optimal_metrics['threshold'] = best_threshold
    optimal_metrics['best_f1'] = f1_scores[best_threshold_idx]
    
    return best_threshold, optimal_metrics


def calculate_confusion_matrix_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, Any]:
    """
    计算混淆矩阵相关指标
    
    Args:
        y_true: 真实标签
        y_pred: 预测标签
    
    Returns:
        混淆矩阵和相关指标
    """
    cm = confusion_matrix(y_true, y_pred)
    
    # 对于二分类情况
    if cm.shape == (2, 2):
        tn, fp, fn, tp = cm.ravel()
        
        metrics = {
            'confusion_matrix': cm.tolist(),
            'true_negatives': int(tn),
            'false_positives': int(fp),
            'false_negatives': int(fn),
            'true_positives': int(tp),
            'specificity': tn / (tn + fp) if (tn + fp) > 0 else 0.0,
            'sensitivity': tp / (tp + fn) if (tp + fn) > 0 else 0.0,
            'positive_predictive_value': tp / (tp + fp) if (tp + fp) > 0 else 0.0,
            'negative_predictive_value': tn / (tn + fn) if (tn + fn) > 0 else 0.0
        }
    else:
        # 多分类情况
        metrics = {
            'confusion_matrix': cm.tolist(),
            'per_class_accuracy': cm.diagonal() / cm.sum(axis=1)
        }
    
    return metrics


def generate_classification_report(y_true: np.ndarray, y_pred: np.ndarray, 
                                 target_names: Optional[list] = None) -> str:
    """
    生成分类报告
    
    Args:
        y_true: 真实标签
        y_pred: 预测标签
        target_names: 类别名称
    
    Returns:
        分类报告字符串
    """
    return classification_report(y_true, y_pred, target_names=target_names, zero_division=0)


def calculate_model_performance_summary(y_true: np.ndarray, y_pred: np.ndarray, 
                                      y_proba: Optional[np.ndarray] = None,
                                      target_names: Optional[list] = None) -> Dict[str, Any]:
    """
    计算模型性能综合摘要
    
    Args:
        y_true: 真实标签
        y_pred: 预测标签
        y_proba: 预测概率
        target_names: 类别名称
    
    Returns:
        完整的性能摘要
    """
    summary = {}
    
    # 基础指标
    summary['basic_metrics'] = calculate_metrics(y_true, y_pred, y_proba)
    
    # 混淆矩阵指标
    summary['confusion_matrix_metrics'] = calculate_confusion_matrix_metrics(y_true, y_pred)
    
    # 分类报告
    summary['classification_report'] = generate_classification_report(y_true, y_pred, target_names)
    
    # 如果是二分类且有概率，计算最优阈值
    if y_proba is not None and len(np.unique(y_true)) == 2:
        try:
            best_threshold, optimal_metrics = optimize_threshold(y_true, y_proba)
            summary['threshold_optimization'] = {
                'best_threshold': best_threshold,
                'optimal_metrics': optimal_metrics
            }
        except Exception as e:
            print(f"Warning: Could not optimize threshold: {e}")
    
    return summary