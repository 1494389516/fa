#!/usr/bin/env python3
"""
风控模型训练脚本
直接运行此脚本来训练高级风控模型
"""

import asyncio
import argparse
import logging
import sys
from pathlib import Path

# 添加项目路径
sys.path.append(str(Path(__file__).parent / "src"))

from ml_training.config import get_settings
from ml_training.advanced_training import get_advanced_trainer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('risk_model_training.log')
    ]
)

logger = logging.getLogger(__name__)

async def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='训练高级风控模型')
    parser.add_argument('--dataset', required=True, help='训练数据集路径')
    parser.add_argument('--target', default='is_malicious', help='目标列名称')
    parser.add_argument('--output', default='./models/advanced', help='模型输出目录')
    
    args = parser.parse_args()
    
    logger.info("开始风控模型训练...")
    logger.info(f"数据集: {args.dataset}")
    logger.info(f"目标列: {args.target}")
    logger.info(f"输出目录: {args.output}")
    
    try:
        # 检查数据集文件是否存在
        if not Path(args.dataset).exists():
            logger.error(f"数据集文件不存在: {args.dataset}")
            return 1
        
        # 获取配置和训练器
        settings = get_settings()
        trainer = get_advanced_trainer(settings)
        
        # 开始训练
        logger.info("启动综合风控模型训练...")
        results = await trainer.train_comprehensive_risk_models(
            dataset_path=args.dataset,
            target_column=args.target
        )
        
        # 生成报告
        report = trainer.generate_model_report()
        
        # 输出结果
        logger.info("=" * 60)
        logger.info("训练完成！结果摘要:")
        logger.info("=" * 60)
        
        logger.info(f"训练时间: {results['training_time_seconds']:.2f} 秒")
        logger.info(f"数据集信息:")
        logger.info(f"  - 总样本数: {results['data_info']['total_samples']}")
        logger.info(f"  - 特征数: {results['data_info']['features']}")
        logger.info(f"  - 正样本比例: {results['data_info']['positive_ratio']:.3f}")
        
        logger.info(f"最佳模型:")
        logger.info(f"  - 类型: {results['best_model_info']['model_type']}")
        logger.info(f"  - 得分: {results['best_model_info']['best_score']:.4f}")
        
        # 模型性能
        if 'final_evaluation' in results:
            logger.info("模型性能评估:")
            for model_name, metrics in results['final_evaluation'].items():
                if 'error' not in metrics:
                    logger.info(f"  {model_name}:")
                    logger.info(f"    - AUC: {metrics.get('auc', 0):.4f}")
                    logger.info(f"    - F1: {metrics.get('f1', 0):.4f}")
                    logger.info(f"    - 精确率: {metrics.get('precision', 0):.4f}")
                    logger.info(f"    - 召回率: {metrics.get('recall', 0):.4f}")
        
        # 推荐建议
        logger.info("推荐建议:")
        for recommendation in report.get('recommendations', []):
            logger.info(f"  - {recommendation}")
        
        logger.info("=" * 60)
        logger.info(f"模型已保存到: {trainer.model_dir}")
        logger.info("训练完成！")
        
        return 0
        
    except Exception as e:
        logger.error(f"训练过程中发生错误: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)