#!/usr/bin/env python3
"""
风控模型快速启动脚本
自动生成示例数据并训练模型
"""

import asyncio
import subprocess
import sys
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def quick_start():
    """快速启动风控模型训练"""
    logger.info("🚀 风控模型快速启动...")
    
    try:
        # 1. 生成示例数据
        logger.info("📊 步骤 1/3: 生成示例训练数据...")
        data_file = "sample_risk_data.csv"
        
        cmd = [
            sys.executable, "generate_sample_data.py",
            "--samples", "5000",
            "--malicious-ratio", "0.2",
            "--output", data_file
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            logger.error(f"数据生成失败: {result.stderr}")
            return 1
        
        logger.info("✅ 示例数据生成完成")
        
        # 2. 训练模型
        logger.info("🤖 步骤 2/3: 开始训练风控模型...")
        
        cmd = [
            sys.executable, "train_risk_models.py",
            "--dataset", data_file,
            "--target", "is_malicious"
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            logger.error(f"模型训练失败: {result.stderr}")
            return 1
        
        logger.info("✅ 模型训练完成")
        
        # 3. 显示结果
        logger.info("📈 步骤 3/3: 训练结果摘要")
        logger.info("=" * 50)
        logger.info("🎉 风控模型训练成功完成！")
        logger.info("📁 模型文件保存在: ./models/advanced/")
        logger.info("📋 训练日志保存在: risk_model_training.log")
        logger.info("🔍 可以查看日志了解详细的训练过程和模型性能")
        logger.info("=" * 50)
        
        # 清理临时文件
        if Path(data_file).exists():
            Path(data_file).unlink()
            logger.info("🧹 清理临时数据文件")
        
        return 0
        
    except Exception as e:
        logger.error(f"快速启动失败: {e}")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(quick_start())
    sys.exit(exit_code)