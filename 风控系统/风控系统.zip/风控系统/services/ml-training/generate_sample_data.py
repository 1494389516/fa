#!/usr/bin/env python3
"""
生成风控模型训练的示例数据
模拟真实的网络流量和威胁检测场景
"""

import numpy as np
import pandas as pd
import argparse
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def generate_risk_features(n_samples: int = 10000, random_state: int = 42) -> pd.DataFrame:
    """生成风控特征数据"""
    np.random.seed(random_state)
    
    logger.info(f"生成 {n_samples} 个样本的风控特征数据...")
    
    # 基础网络特征
    data = {
        # 流量特征
        'packet_count': np.random.poisson(100, n_samples),
        'byte_count': np.random.exponential(5000, n_samples),
        'duration_seconds': np.random.exponential(30, n_samples),
        'packets_per_second': np.random.gamma(2, 5, n_samples),
        
        # 连接特征
        'src_port': np.random.randint(1024, 65535, n_samples),
        'dst_port': np.random.choice([80, 443, 22, 21, 25, 53, 8080, 3389], n_samples),
        'protocol': np.random.choice(['TCP', 'UDP', 'ICMP'], n_samples, p=[0.7, 0.25, 0.05]),
        
        # 地理位置特征
        'src_country_risk': np.random.beta(2, 5, n_samples),  # 0-1之间，越高越危险
        'dst_country_risk': np.random.beta(1, 8, n_samples),
        'geo_distance_km': np.random.exponential(2000, n_samples),
        
        # 时间特征
        'hour_of_day': np.random.randint(0, 24, n_samples),
        'day_of_week': np.random.randint(0, 7, n_samples),
        'is_weekend': np.random.choice([0, 1], n_samples, p=[0.7, 0.3]),
        
        # 行为特征
        'failed_login_attempts': np.random.poisson(0.5, n_samples),
        'unique_user_agents': np.random.poisson(2, n_samples),
        'request_frequency': np.random.gamma(1, 3, n_samples),
        'session_duration': np.random.exponential(600, n_samples),
        
        # 内容特征
        'payload_entropy': np.random.beta(3, 2, n_samples),  # 载荷熵值
        'suspicious_keywords': np.random.poisson(0.1, n_samples),
        'file_extension_risk': np.random.beta(1, 9, n_samples),
        
        # 网络指纹特征
        'ja3_hash_known': np.random.choice([0, 1], n_samples, p=[0.1, 0.9]),
        'user_agent_risk': np.random.beta(1, 4, n_samples),
        'tls_version': np.random.choice([1.0, 1.1, 1.2, 1.3], n_samples, p=[0.05, 0.1, 0.6, 0.25]),
        
        # 历史行为特征
        'ip_reputation_score': np.random.beta(8, 2, n_samples),  # 越高越好
        'domain_age_days': np.random.exponential(365, n_samples),
        'previous_violations': np.random.poisson(0.2, n_samples),
        
        # 机器学习特征
        'anomaly_score': np.random.beta(2, 8, n_samples),  # 异常分数
        'clustering_distance': np.random.gamma(2, 1, n_samples),
        'ensemble_prediction': np.random.beta(3, 7, n_samples),
    }
    
    # 转换为DataFrame
    df = pd.DataFrame(data)
    
    # 添加一些相关性和交互特征
    df['bytes_per_packet'] = df['byte_count'] / (df['packet_count'] + 1)
    df['night_activity'] = ((df['hour_of_day'] < 6) | (df['hour_of_day'] > 22)).astype(int)
    df['high_risk_geo'] = ((df['src_country_risk'] > 0.7) | (df['dst_country_risk'] > 0.7)).astype(int)
    df['suspicious_behavior'] = (
        (df['failed_login_attempts'] > 2) | 
        (df['suspicious_keywords'] > 0) | 
        (df['previous_violations'] > 0)
    ).astype(int)
    
    return df

def generate_malicious_labels(df: pd.DataFrame, malicious_ratio: float = 0.15) -> pd.Series:
    """基于特征生成恶意标签"""
    logger.info(f"生成恶意标签，目标恶意比例: {malicious_ratio:.2%}")
    
    # 计算恶意概率
    malicious_prob = (
        0.3 * df['src_country_risk'] +
        0.2 * df['anomaly_score'] +
        0.15 * df['suspicious_behavior'] +
        0.1 * df['high_risk_geo'] +
        0.1 * df['night_activity'] +
        0.05 * (df['failed_login_attempts'] > 0).astype(float) +
        0.05 * (df['payload_entropy'] > 0.8).astype(float) +
        0.05 * (1 - df['ip_reputation_score'])  # 声誉越低越可疑
    )
    
    # 标准化到0-1
    malicious_prob = (malicious_prob - malicious_prob.min()) / (malicious_prob.max() - malicious_prob.min())
    
    # 调整分布以达到目标恶意比例
    threshold = np.percentile(malicious_prob, (1 - malicious_ratio) * 100)
    labels = (malicious_prob >= threshold).astype(int)
    
    actual_ratio = labels.mean()
    logger.info(f"实际恶意比例: {actual_ratio:.2%}")
    
    return labels

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='生成风控模型训练数据')
    parser.add_argument('--samples', type=int, default=10000, help='样本数量')
    parser.add_argument('--malicious-ratio', type=float, default=0.15, help='恶意样本比例')
    parser.add_argument('--output', default='sample_risk_data.csv', help='输出文件路径')
    parser.add_argument('--format', choices=['csv', 'parquet'], default='csv', help='输出格式')
    parser.add_argument('--seed', type=int, default=42, help='随机种子')
    
    args = parser.parse_args()
    
    logger.info("开始生成风控训练数据...")
    logger.info(f"样本数量: {args.samples}")
    logger.info(f"恶意比例: {args.malicious_ratio:.2%}")
    logger.info(f"输出文件: {args.output}")
    
    # 生成特征数据
    df = generate_risk_features(args.samples, args.seed)
    
    # 生成标签
    labels = generate_malicious_labels(df, args.malicious_ratio)
    df['is_malicious'] = labels
    
    # 保存数据
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if args.format == 'csv':
        df.to_csv(output_path, index=False)
    elif args.format == 'parquet':
        df.to_parquet(output_path, index=False)
    
    logger.info(f"数据已保存到: {output_path}")
    logger.info(f"数据形状: {df.shape}")
    logger.info(f"特征列数: {len(df.columns) - 1}")
    logger.info(f"恶意样本数: {labels.sum()}")
    logger.info(f"正常样本数: {len(labels) - labels.sum()}")
    
    # 显示数据统计
    logger.info("\n数据统计摘要:")
    logger.info(df.describe())

if __name__ == "__main__":
    main()