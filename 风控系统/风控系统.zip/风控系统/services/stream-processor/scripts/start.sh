#!/bin/bash

set -e

echo "Starting Stream Processor Service..."

# 检查环境变量
if [ -z "$KAFKA_BROKERS" ]; then
    export KAFKA_BROKERS="kafka:29092"
fi

if [ -z "$POSTGRES_URL" ]; then
    export POSTGRES_URL="jdbc:postgresql://postgres:5432/malicious_traffic"
fi

if [ -z "$POSTGRES_USER" ]; then
    export POSTGRES_USER="admin"
fi

if [ -z "$POSTGRES_PASSWORD" ]; then
    export POSTGRES_PASSWORD="password"
fi

echo "Configuration:"
echo "  Kafka Brokers: $KAFKA_BROKERS"
echo "  Database URL: $POSTGRES_URL"
echo "  Parallelism: ${FLINK_PARALLELISM:-4}"

# 等待依赖服务启动
echo "Waiting for Kafka..."
while ! nc -z ${KAFKA_BROKERS%%:*} ${KAFKA_BROKERS##*:}; do
    sleep 1
done
echo "Kafka is ready"

echo "Waiting for PostgreSQL..."
DB_HOST=$(echo $POSTGRES_URL | sed -n 's/.*\/\/\([^:]*\):.*/\1/p')
DB_PORT=$(echo $POSTGRES_URL | sed -n 's/.*:\([0-9]*\)\/.*/\1/p')
while ! nc -z $DB_HOST $DB_PORT; do
    sleep 1
done
echo "PostgreSQL is ready"

# 设置JVM参数
export JAVA_OPTS="${JAVA_OPTS} -Dlog4j.configurationFile=/app/conf/log4j2.xml"
export JAVA_OPTS="${JAVA_OPTS} -Djava.security.egd=file:/dev/./urandom"

# 启动应用
echo "Starting Flink job..."
exec java $JAVA_OPTS -jar app.jar \
    --kafka.brokers="$KAFKA_BROKERS" \
    --jdbc.url="$POSTGRES_URL" \
    --jdbc.username="$POSTGRES_USER" \
    --jdbc.password="$POSTGRES_PASSWORD" \
    --parallelism="${FLINK_PARALLELISM:-4}" \
    --checkpoint.interval="${FLINK_CHECKPOINT_INTERVAL:-60000}" \
    --metrics.enabled="${METRICS_ENABLED:-true}"