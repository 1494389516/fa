# 实时流处理服务 (Stream Processor)

## 1. 服务概述

本服务是风控系统的实时数据处理核心，基于 **Apache Flink** 构建。它负责从 Kafka 消息队列中消费实时网络流量数据，进行多阶段的分析、处理和聚合，最终识别出潜在的恶意行为。

该服务被设计为一个高性能、可扩展的流处理应用，能够以低延迟处理海量数据。

## 2. 核心功能

- **实时数据消费**: 从指定的 Kafka Topic (`traffic-events`) 消费原始网络流量日志。
- **特征提取**: 对原始数据进行解析和转换，提取出用于风险评估的关键特征（如 IP 地址、请求频率、用户代理等）。
- **异常检测与聚合**: 在时间窗口内对流量数据进行聚合，并应用规则或模型来检测异常模式（如 DDoS 攻击、暴力破解尝试等）。
- **威胁评分**: 为可疑的流量事件生成威胁评分，并将结果输出到下游系统（如 PostgreSQL 数据库或其他 Kafka Topic）进行存储或进一步处理。

## 3. 与 Python 服务的交互

本服务是连接数据源和 Python 机器学习工作流的关键桥梁。

-   **为模型训练提供数据**: 本服务处理和聚合的特征数据可以被导出，用作 `ml-training` 服务（基于 Python）的训练数据集，以生成或更新风控模型。
-   **触发实时推理**: 在检测到可疑流量时，本服务可以将事件发送到下游，可能会触发 `ml-inference` 服务（基于 Rust，但使用 Python 训练出的 ONNX 模型）进行更复杂的模型推理。

通过这种方式，这个基于 Java/Flink 的高性能流处理引擎与项目中的 Python 机器学习组件紧密协作，构成了完整的风控闭环。

## 4. 技术优势

- **高性能与低延迟**: 借助 Apache Flink 的原生流处理能力，确保数据在到达后能够被毫秒级处理，满足实时风控的需求。
- **高可扩展性**: 服务可以水平扩展，通过增加 Flink Task Manager 的并行度来应对不断增长的数据流量。
- **强大的状态管理**: 利用 Flink 的状态后端（State Backend），可以进行复杂的有状态计算，例如跨越长时间窗口的用户行为分析。
- **高容错性**: 通过 Flink 的检查点（Checkpointing）机制，确保在节点故障时能够从上一个一致性状态恢复，保证数据处理的“恰好一次”（Exactly-once）语义，不丢失或重复处理数据。
- **灵活性与可扩展性**: 模块化的代码结构（`Source` -> `Function` -> `Sink`）使得添加新的数据源、处理逻辑或输出目标变得非常简单。

## 5. 部署指南

我强烈推荐使用项目根目录下的 Docker Compose 进行一键部署，它会自动处理所有依赖项（如 Kafka, Zookeeper, PostgreSQL）。

### 先决条件
- Docker 和 Docker Compose
- Java 17+
- Maven 3.6+

> **关于 Python 的说明**: 本服务基于 Java。Python 的环境要求适用于与本服务交互的 `ml-training` 服务。该服务需要 **Python 3.11+** 以及一系列模块。核心依赖包括：
> - **机器学习框架**: `torch`, `xgboost`, `scikit-learn`
> - **数据处理**: `pandas`, `numpy`
> - **模型导出**: `onnx`, `onnxruntime`
> - **数据库与消息队列**: `psycopg2-binary`, `kafka-python`
> 
> 完整的依赖列表请参见 `services/ml-training/requirements.txt` 文件。

### 使用 Docker Compose 部署 (推荐)

1.  **确保 Docker 正在运行**。
2.  在项目的根目录下，打开终端并执行以下命令：
    ```bash
    # 该命令会构建并启动所有服务，包括本服务
    docker compose up --build -d
    ```
3.  服务将在后台启动。你可以使用以下命令查看日志：
    ```bash
    docker compose logs -f stream-processor
    ```

### 手动构建 (用于开发或调试)

1.  在 `services/stream-processor` 目录下，使用 Maven 构建项目：
    ```bash
    mvn clean package
    ```
    构建成功后，JAR 文件会生成在 `target/` 目录下。

2.  要独立运行此 Flink 作业，你需要一个正在运行的 Flink 集群，并手动提交作业。

## 6. 配置说明

- **核心配置文件**: `src/main/resources/application.conf`
  - 此文件使用 HOCON 格式，定义了 Kafka、数据库连接以及 Flink 作业的参数。
- **环境变量**: 在 `docker-compose.yml` 中，通过环境变量向容器注入配置，覆盖 `application.conf` 中的默认值。这是生产环境中管理配置的最佳实践。
  - `KAFKA_BROKERS`: Kafka 集群的地址。
  - `POSTGRES_URL`: PostgreSQL 数据库的连接字符串。
  - `POSTGRES_USER`: 数据库用户名。
  - `POSTGRES_PASSWORD`: 数据库密码。