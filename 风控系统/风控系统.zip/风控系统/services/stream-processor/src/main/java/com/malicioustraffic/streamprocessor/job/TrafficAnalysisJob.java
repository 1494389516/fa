package com.malicioustraffic.streamprocessor.job;

import com.malicioustraffic.streamprocessor.config.StreamProcessorConfig;
import com.malicioustraffic.streamprocessor.function.FeatureExtractionFunction;
import com.malicioustraffic.streamprocessor.model.TrafficEvent;
import com.malicioustraffic.streamprocessor.model.ThreatScore;
import com.malicioustraffic.streamprocessor.sink.ThreatScoreSerializer;
import com.malicioustraffic.streamprocessor.source.TrafficEventDeserializer;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

/**
 * Main Traffic Analysis Flink Job
 * Processes traffic events, extracts features, and generates threat scores
 */
public class TrafficAnalysisJob {
    
    private static final Logger logger = LoggerFactory.getLogger(TrafficAnalysisJob.class);
    
    private final StreamProcessorConfig config;
    
    public TrafficAnalysisJob(StreamProcessorConfig config) {
        this.config = config;
    }
    
    /**
     * Execute the traffic analysis job
     */
    public void execute(StreamExecutionEnvironment env) throws Exception {
        logger.info("Starting Traffic Analysis Job with config: {}", config);
        
        // Create Kafka source
        KafkaSource<TrafficEvent> kafkaSource = createKafkaSource();
        
        // Create Kafka sink
        KafkaSink<ThreatScore> kafkaSink = createKafkaSink();
        
        // Build the processing pipeline
        DataStream<TrafficEvent> trafficStream = env
            .fromSource(kafkaSource, createWatermarkStrategy(), "KafkaSource")
            .uid("kafka-source");
        
        // Feature extraction in its own slot sharing group for resource isolation
        DataStream<TrafficEvent> enrichedStream = trafficStream
            .map(new FeatureExtractionFunction())
            .name("FeatureExtraction")
            .uid("feature-extraction")
            .slotSharingGroup("processing-group");
        
        // Windowed aggregation and threat analysis, also in the processing group
        DataStream<ThreatScore> threatScores = enrichedStream
            .keyBy(TrafficEvent::getClientKey)
            .window(SlidingEventTimeWindows.of(
                Time.seconds(config.getWindowSizeSeconds()),
                Time.seconds(config.getSlidingIntervalSeconds())
            ))
            .process(new ThreatAnalysisWindowFunction(config))
            .name("ThreatAnalysis")
            .uid("threat-analysis")
            .slotSharingGroup("processing-group");
        
        // Filter high-confidence threats
        DataStream<ThreatScore> filteredThreats = threatScores
            .filter(score -> score.getScore() != null && score.getScore() >= config.getThreatThreshold())
            .name("ThreatFilter")
            .uid("threat-filter");
        
        // Send results to Kafka
        filteredThreats
            .sinkTo(kafkaSink)
            .name("KafkaSink")
            .uid("kafka-sink");
        
        // Execute the job
        env.execute("Traffic Analysis Job");
    }
    
    /**
     * Create Kafka source for traffic events
     */
    private KafkaSource<TrafficEvent> createKafkaSource() {
        return KafkaSource.<TrafficEvent>builder()
            .setBootstrapServers(config.getKafkaBrokers())
            .setTopics(config.getInputTopic())
            .setGroupId(config.getConsumerGroupId())
            .setStartingOffsets(OffsetsInitializer.latest())
            .setValueOnlyDeserializer(new TrafficEventDeserializer())
            .setProperties(config.getKafkaConsumerProperties())
            .build();
    }
    
    /**
     * Create Kafka sink for threat scores
     */
    private KafkaSink<ThreatScore> createKafkaSink() {
        return KafkaSink.<ThreatScore>builder()
            .setBootstrapServers(config.getKafkaBrokers())
            .setRecordSerializer(KafkaRecordSerializationSchema.builder()
                .setTopic(config.getOutputTopic())
                .setValueSerializationSchema(new ThreatScoreSerializer())
                .setKeySerializationSchema(element -> element.getEventId().getBytes())
                .build())
            .setKafkaProducerConfig(config.getKafkaProducerProperties())
            .build();
    }
    
    /**
     * Create watermark strategy for event time processing
     */
    private WatermarkStrategy<TrafficEvent> createWatermarkStrategy() {
        return WatermarkStrategy
            .<TrafficEvent>forBoundedOutOfOrderness(Duration.ofSeconds(config.getMaxOutOfOrdernessSeconds()))
            .withTimestampAssigner((event, timestamp) -> event.getTimestamp().toEpochMilli())
            .withIdleness(Duration.ofMinutes(1));
    }
    
    /**
     * Window function for threat analysis
     */
    public static class ThreatAnalysisWindowFunction 
            extends ProcessWindowFunction<TrafficEvent, ThreatScore, String, TimeWindow> {
        
        private static final long serialVersionUID = 1L;
        private static final Logger logger = LoggerFactory.getLogger(ThreatAnalysisWindowFunction.class);
        
        private final StreamProcessorConfig config;
        
        public ThreatAnalysisWindowFunction(StreamProcessorConfig config) {
            this.config = config;
        }
        
        @Override
        public void process(String clientKey, Context context, 
                          Iterable<TrafficEvent> elements, 
                          Collector<ThreatScore> out) throws Exception {
            
            long windowStart = context.window().getStart();
            long windowEnd = context.window().getEnd();
            
            logger.debug("Processing window [{} - {}] for client: {}", 
                        Instant.ofEpochMilli(windowStart), 
                        Instant.ofEpochMilli(windowEnd), 
                        clientKey);
            
            List<TrafficEvent> events = new ArrayList<>();
            elements.forEach(events::add);
            
            if (events.isEmpty()) {
                return;
            }
            
            // Analyze events in the window
            ThreatScore threatScore = analyzeEventsInWindow(events, clientKey, windowStart, windowEnd);
            
            if (threatScore != null) {
                out.collect(threatScore);
                logger.debug("Generated threat score: {} for client: {}", 
                           threatScore.getScore(), clientKey);
            }
        }
        
        /**
         * Analyze events in the window and generate threat score
         */
        private ThreatScore analyzeEventsInWindow(List<TrafficEvent> events, 
                                                String clientKey, 
                                                long windowStart, 
                                                long windowEnd) {
            
            if (events.isEmpty()) {
                return null;
            }
            
            // Use the first event as representative
            TrafficEvent firstEvent = events.get(0);
            
            // Calculate aggregated features
            Map<String, Double> aggregatedFeatures = calculateAggregatedFeatures(events);
            
            // Calculate threat score based on aggregated features
            double threatScore = calculateThreatScore(aggregatedFeatures, events);
            double confidence = calculateConfidence(aggregatedFeatures, events);
            
            // Determine threat categories
            List<String> categories = determineThreatCategories(aggregatedFeatures, events);
            
            // Create threat score object
            ThreatScore result = new ThreatScore(firstEvent.getId(), threatScore, confidence);
            result.setClientIp(firstEvent.getClientIp());
            result.setRequestPath(firstEvent.getRequestPath());
            result.setUserAgent(firstEvent.getUserAgent());
            result.setFeatures(aggregatedFeatures);
            result.setCategories(categories);
            result.setModelVersion("v1.0");
            result.setTimestamp(Instant.ofEpochMilli(windowEnd));
            
            return result;
        }
        
        /**
         * Calculate aggregated features from multiple events
         */
        private Map<String, Double> calculateAggregatedFeatures(List<TrafficEvent> events) {
            Map<String, Double> aggregated = new HashMap<>();
            
            // Request frequency
            aggregated.put("request_frequency", (double) events.size());
            
            // Path diversity
            Set<String> uniquePaths = new HashSet<>();
            events.forEach(event -> uniquePaths.add(event.getRequestPath()));
            aggregated.put("path_diversity", (double) uniquePaths.size() / events.size());
            
            // Average feature values
            if (!events.isEmpty() && events.get(0).hasFeatures()) {
                Map<String, Double> avgFeatures = calculateAverageFeatures(events);
                for (Map.Entry<String, Double> entry : avgFeatures.entrySet()) {
                    aggregated.put("avg_" + entry.getKey(), entry.getValue());
                }
            }
            
            // Time pattern analysis
            aggregated.put("time_pattern_anomaly", calculateTimePatternAnomaly(events));
            
            // Method diversity
            Set<String> uniqueMethods = new HashSet<>();
            events.forEach(event -> uniqueMethods.add(event.getRequestMethod()));
            aggregated.put("method_diversity", (double) uniqueMethods.size());
            
            // Response code patterns
            Map<Integer, Long> responseCodes = new HashMap<>();
            events.forEach(event -> {
                if (event.getResponseCode() != null) {
                    responseCodes.merge(event.getResponseCode(), 1L, Long::sum);
                }
            });
            
            long errorResponses = responseCodes.entrySet().stream()
                .filter(entry -> entry.getKey() >= 400)
                .mapToLong(Map.Entry::getValue)
                .sum();
            
            aggregated.put("error_rate", (double) errorResponses / events.size());
            
            return aggregated;
        }
        
        /**
         * Calculate average features across events
         */
        private Map<String, Double> calculateAverageFeatures(List<TrafficEvent> events) {
            Map<String, Double> avgFeatures = new HashMap<>();
            Map<String, Integer> featureCounts = new HashMap<>();
            
            for (TrafficEvent event : events) {
                if (event.hasFeatures()) {
                    for (Map.Entry<String, Double> entry : event.getFeatures().entrySet()) {
                        avgFeatures.merge(entry.getKey(), entry.getValue(), Double::sum);
                        featureCounts.merge(entry.getKey(), 1, Integer::sum);
                    }
                }
            }
            
            for (Map.Entry<String, Double> entry : avgFeatures.entrySet()) {
                String key = entry.getKey();
                int count = featureCounts.getOrDefault(key, 1);
                entry.setValue(entry.getValue() / count);
            }
            
            return avgFeatures;
        }
        
        /**
         * Calculate time pattern anomaly
         */
        private double calculateTimePatternAnomaly(List<TrafficEvent> events) {
            if (events.size() < 3) {
                return 0.0;
            }
            
            // Sort events by timestamp
            events.sort(Comparator.comparing(TrafficEvent::getTimestamp));
            
            // Calculate intervals between requests
            List<Long> intervals = new ArrayList<>();
            for (int i = 1; i < events.size(); i++) {
                long interval = events.get(i).getTimestamp().toEpochMilli() - 
                               events.get(i-1).getTimestamp().toEpochMilli();
                intervals.add(interval);
            }
            
            // Calculate variance of intervals
            double avgInterval = intervals.stream().mapToLong(Long::longValue).average().orElse(0.0);
            double variance = intervals.stream()
                .mapToDouble(interval -> Math.pow(interval - avgInterval, 2))
                .average()
                .orElse(0.0);
            
            // Low variance indicates regular pattern (bot-like behavior)
            double normalizedVariance = Math.min(variance / (avgInterval * avgInterval), 1.0);
            return 1.0 - normalizedVariance; // Higher score for more regular patterns
        }
        
        /**
         * Calculate overall threat score
         */
        private double calculateThreatScore(Map<String, Double> aggregatedFeatures, List<TrafficEvent> events) {
            StreamProcessorConfig.ThreatAnalysisConfig weights = config.getThreatAnalysisConfig();
            double score = 0.0;
            
            // Request frequency factor
            double requestFreq = aggregatedFeatures.getOrDefault("request_frequency", 0.0);
            if (requestFreq > 50) { // More than 50 requests in window
                score += weights.requestFrequencyWeight;
            } else if (requestFreq > 20) {
                score += weights.requestFrequencyWeight * 0.5;
            }
            
            // Path diversity factor
            double pathDiversity = aggregatedFeatures.getOrDefault("path_diversity", 1.0);
            if (pathDiversity < 0.1 || pathDiversity > 0.9) {
                score += weights.pathDiversityWeight;
            }
            
            // Time pattern anomaly
            double timeAnomaly = aggregatedFeatures.getOrDefault("time_pattern_anomaly", 0.0);
            score += timeAnomaly * weights.timePatternWeight;
            
            // Error rate factor
            double errorRate = aggregatedFeatures.getOrDefault("error_rate", 0.0);
            score += errorRate * weights.errorRateWeight;
            
            // Average feature-based score
            double avgFeatureScore = 0.0;
            int featureCount = 0;
            
            for (Map.Entry<String, Double> entry : aggregatedFeatures.entrySet()) {
                if (entry.getKey().startsWith("avg_")) {
                    avgFeatureScore += entry.getValue();
                    featureCount++;
                }
            }
            
            if (featureCount > 0) {
                score += (avgFeatureScore / featureCount) * weights.featureAvgWeight;
            }
            
            return Math.min(score, 1.0);
        }
        
        /**
         * Calculate confidence score
         */
        private double calculateConfidence(Map<String, Double> features, List<TrafficEvent> events) {
            double confidence = 0.5; // Base confidence
            
            // More events increase confidence
            double eventCount = events.size();
            confidence += Math.min(eventCount / 100.0, 0.3);
            
            // Consistent patterns increase confidence
            double pathDiversity = features.getOrDefault("path_diversity", 1.0);
            if (pathDiversity < 0.2 || pathDiversity > 0.8) {
                confidence += 0.2;
            }
            
            return Math.min(confidence, 1.0);
        }
        
        /**
         * Determine threat categories
         */
        private List<String> determineThreatCategories(Map<String, Double> features, List<TrafficEvent> events) {
            List<String> categories = new ArrayList<>();
            
            double requestFreq = features.getOrDefault("request_frequency", 0.0);
            double pathDiversity = features.getOrDefault("path_diversity", 1.0);
            double timeAnomaly = features.getOrDefault("time_pattern_anomaly", 0.0);
            
            // Bot detection
            if (timeAnomaly > 0.7 && requestFreq > 30) {
                categories.add("bot");
            }
            
            // Scanner detection
            if (pathDiversity > 0.8 && requestFreq > 20) {
                categories.add("scanner");
            }
            
            // Scraper detection
            if (pathDiversity < 0.3 && requestFreq > 50) {
                categories.add("scraper");
            }
            
            // DDoS detection
            if (requestFreq > 100) {
                categories.add("ddos");
            }
            
            // Brute force detection
            double errorRate = features.getOrDefault("error_rate", 0.0);
            if (errorRate > 0.5 && requestFreq > 10) {
                categories.add("brute_force");
            }
            
            return categories;
        }
    }
}