package com.malicioustraffic.streamprocessor.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Threat Score Model
 * Represents the output of threat analysis
 */
public class ThreatScore implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @JsonProperty("event_id")
    private String eventId;
    
    @JsonProperty("score")
    private Double score;
    
    @JsonProperty("confidence")
    private Double confidence;
    
    @JsonProperty("categories")
    private List<String> categories;
    
    @JsonProperty("features")
    private Map<String, Double> features;
    
    @JsonProperty("timestamp")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private Instant timestamp;
    
    @JsonProperty("model_version")
    private String modelVersion;
    
    @JsonProperty("processing_time_ms")
    private Long processingTimeMs;
    
    @JsonProperty("client_ip")
    private String clientIp;
    
    @JsonProperty("request_path")
    private String requestPath;
    
    @JsonProperty("user_agent")
    private String userAgent;
    
    // Detailed analysis results
    @JsonProperty("analysis_details")
    private AnalysisDetails analysisDetails;
    
    // Default constructor
    public ThreatScore() {}
    
    // Constructor with required fields
    public ThreatScore(String eventId, Double score, Double confidence) {
        this.eventId = eventId;
        this.score = score;
        this.confidence = confidence;
        this.timestamp = Instant.now();
    }
    
    // Getters and Setters
    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }
    
    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }
    
    public Double getConfidence() { return confidence; }
    public void setConfidence(Double confidence) { this.confidence = confidence; }
    
    public List<String> getCategories() { return categories; }
    public void setCategories(List<String> categories) { this.categories = categories; }
    
    public Map<String, Double> getFeatures() { return features; }
    public void setFeatures(Map<String, Double> features) { this.features = features; }
    
    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
    
    public String getModelVersion() { return modelVersion; }
    public void setModelVersion(String modelVersion) { this.modelVersion = modelVersion; }
    
    public Long getProcessingTimeMs() { return processingTimeMs; }
    public void setProcessingTimeMs(Long processingTimeMs) { this.processingTimeMs = processingTimeMs; }
    
    public String getClientIp() { return clientIp; }
    public void setClientIp(String clientIp) { this.clientIp = clientIp; }
    
    public String getRequestPath() { return requestPath; }
    public void setRequestPath(String requestPath) { this.requestPath = requestPath; }
    
    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }
    
    public AnalysisDetails getAnalysisDetails() { return analysisDetails; }
    public void setAnalysisDetails(AnalysisDetails analysisDetails) { this.analysisDetails = analysisDetails; }
    
    // Utility methods
    public boolean isHighThreat() {
        return score != null && score >= 0.8;
    }
    
    public boolean isMediumThreat() {
        return score != null && score >= 0.5 && score < 0.8;
    }
    
    public boolean isLowThreat() {
        return score != null && score < 0.5;
    }
    
    public String getThreatLevel() {
        if (isHighThreat()) return "HIGH";
        if (isMediumThreat()) return "MEDIUM";
        return "LOW";
    }
    
    public boolean isHighConfidence() {
        return confidence != null && confidence >= 0.8;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ThreatScore that = (ThreatScore) o;
        return Objects.equals(eventId, that.eventId) &&
               Objects.equals(timestamp, that.timestamp);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(eventId, timestamp);
    }
    
    @Override
    public String toString() {
        return "ThreatScore{" +
                "eventId='" + eventId + '\'' +
                ", score=" + score +
                ", confidence=" + confidence +
                ", categories=" + categories +
                ", timestamp=" + timestamp +
                '}';
    }
    
    /**
     * Analysis Details inner class
     */
    public static class AnalysisDetails implements Serializable {
        
        private static final long serialVersionUID = 1L;
        
        @JsonProperty("request_features")
        private RequestFeatures requestFeatures;
        
        @JsonProperty("client_features")
        private ClientFeatures clientFeatures;
        
        @JsonProperty("behavioral_features")
        private BehavioralFeatures behavioralFeatures;
        
        @JsonProperty("anomaly_scores")
        private Map<String, Double> anomalyScores;
        
        @JsonProperty("rule_matches")
        private List<String> ruleMatches;
        
        // Constructors
        public AnalysisDetails() {}
        
        // Getters and Setters
        public RequestFeatures getRequestFeatures() { return requestFeatures; }
        public void setRequestFeatures(RequestFeatures requestFeatures) { this.requestFeatures = requestFeatures; }
        
        public ClientFeatures getClientFeatures() { return clientFeatures; }
        public void setClientFeatures(ClientFeatures clientFeatures) { this.clientFeatures = clientFeatures; }
        
        public BehavioralFeatures getBehavioralFeatures() { return behavioralFeatures; }
        public void setBehavioralFeatures(BehavioralFeatures behavioralFeatures) { this.behavioralFeatures = behavioralFeatures; }
        
        public Map<String, Double> getAnomalyScores() { return anomalyScores; }
        public void setAnomalyScores(Map<String, Double> anomalyScores) { this.anomalyScores = anomalyScores; }
        
        public List<String> getRuleMatches() { return ruleMatches; }
        public void setRuleMatches(List<String> ruleMatches) { this.ruleMatches = ruleMatches; }
    }
    
    /**
     * Request Features inner class
     */
    public static class RequestFeatures implements Serializable {
        
        private static final long serialVersionUID = 1L;
        
        @JsonProperty("uri_length")
        private Integer uriLength;
        
        @JsonProperty("parameter_count")
        private Integer parameterCount;
        
        @JsonProperty("suspicious_patterns")
        private List<String> suspiciousPatterns;
        
        @JsonProperty("method_anomaly")
        private Boolean methodAnomaly;
        
        @JsonProperty("header_anomalies")
        private List<String> headerAnomalies;
        
        // Constructors
        public RequestFeatures() {}
        
        // Getters and Setters
        public Integer getUriLength() { return uriLength; }
        public void setUriLength(Integer uriLength) { this.uriLength = uriLength; }
        
        public Integer getParameterCount() { return parameterCount; }
        public void setParameterCount(Integer parameterCount) { this.parameterCount = parameterCount; }
        
        public List<String> getSuspiciousPatterns() { return suspiciousPatterns; }
        public void setSuspiciousPatterns(List<String> suspiciousPatterns) { this.suspiciousPatterns = suspiciousPatterns; }
        
        public Boolean getMethodAnomaly() { return methodAnomaly; }
        public void setMethodAnomaly(Boolean methodAnomaly) { this.methodAnomaly = methodAnomaly; }
        
        public List<String> getHeaderAnomalies() { return headerAnomalies; }
        public void setHeaderAnomalies(List<String> headerAnomalies) { this.headerAnomalies = headerAnomalies; }
    }
    
    /**
     * Client Features inner class
     */
    public static class ClientFeatures implements Serializable {
        
        private static final long serialVersionUID = 1L;
        
        @JsonProperty("ip_reputation")
        private Double ipReputation;
        
        @JsonProperty("asn_reputation")
        private Double asnReputation;
        
        @JsonProperty("geo_anomaly")
        private Boolean geoAnomaly;
        
        @JsonProperty("user_agent_anomaly")
        private Double userAgentAnomaly;
        
        @JsonProperty("ja3_suspicion")
        private Double ja3Suspicion;
        
        // Constructors
        public ClientFeatures() {}
        
        // Getters and Setters
        public Double getIpReputation() { return ipReputation; }
        public void setIpReputation(Double ipReputation) { this.ipReputation = ipReputation; }
        
        public Double getAsnReputation() { return asnReputation; }
        public void setAsnReputation(Double asnReputation) { this.asnReputation = asnReputation; }
        
        public Boolean getGeoAnomaly() { return geoAnomaly; }
        public void setGeoAnomaly(Boolean geoAnomaly) { this.geoAnomaly = geoAnomaly; }
        
        public Double getUserAgentAnomaly() { return userAgentAnomaly; }
        public void setUserAgentAnomaly(Double userAgentAnomaly) { this.userAgentAnomaly = userAgentAnomaly; }
        
        public Double getJa3Suspicion() { return ja3Suspicion; }
        public void setJa3Suspicion(Double ja3Suspicion) { this.ja3Suspicion = ja3Suspicion; }
    }
    
    /**
     * Behavioral Features inner class
     */
    public static class BehavioralFeatures implements Serializable {
        
        private static final long serialVersionUID = 1L;
        
        @JsonProperty("request_frequency")
        private Double requestFrequency;
        
        @JsonProperty("path_diversity")
        private Double pathDiversity;
        
        @JsonProperty("time_pattern_anomaly")
        private Double timePatternAnomaly;
        
        @JsonProperty("session_anomaly")
        private Double sessionAnomaly;
        
        @JsonProperty("burst_detection")
        private Boolean burstDetection;
        
        // Constructors
        public BehavioralFeatures() {}
        
        // Getters and Setters
        public Double getRequestFrequency() { return requestFrequency; }
        public void setRequestFrequency(Double requestFrequency) { this.requestFrequency = requestFrequency; }
        
        public Double getPathDiversity() { return pathDiversity; }
        public void setPathDiversity(Double pathDiversity) { this.pathDiversity = pathDiversity; }
        
        public Double getTimePatternAnomaly() { return timePatternAnomaly; }
        public void setTimePatternAnomaly(Double timePatternAnomaly) { this.timePatternAnomaly = timePatternAnomaly; }
        
        public Double getSessionAnomaly() { return sessionAnomaly; }
        public void setSessionAnomaly(Double sessionAnomaly) { this.sessionAnomaly = sessionAnomaly; }
        
        public Boolean getBurstDetection() { return burstDetection; }
        public void setBurstDetection(Boolean burstDetection) { this.burstDetection = burstDetection; }
    }
}