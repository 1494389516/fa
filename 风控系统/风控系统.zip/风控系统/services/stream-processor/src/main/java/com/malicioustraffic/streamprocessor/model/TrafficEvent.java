package com.malicioustraffic.streamprocessor.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Traffic Event Model
 * Represents a single traffic event from the edge gateway
 */
public class TrafficEvent implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @JsonProperty("id")
    private String id;
    
    @JsonProperty("timestamp")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private Instant timestamp;
    
    @JsonProperty("client_ip")
    private String clientIp;
    
    @JsonProperty("user_agent")
    private String userAgent;
    
    @JsonProperty("ja3")
    private String ja3Fingerprint;
    
    @JsonProperty("asn")
    private String asn;
    
    @JsonProperty("request_path")
    private String requestPath;
    
    @JsonProperty("request_method")
    private String requestMethod;
    
    @JsonProperty("headers")
    private Map<String, String> headers;
    
    @JsonProperty("features")
    private Map<String, Double> features;
    
    @JsonProperty("threat_score")
    private Double threatScore;
    
    @JsonProperty("threat_categories")
    private List<String> threatCategories;
    
    // Additional fields for processing
    @JsonProperty("response_code")
    private Integer responseCode;
    
    @JsonProperty("response_size")
    private Long responseSize;
    
    @JsonProperty("processing_time")
    private Long processingTime;
    
    @JsonProperty("geo_country")
    private String geoCountry;
    
    @JsonProperty("geo_city")
    private String geoCity;
    
    // Default constructor
    public TrafficEvent() {}
    
    // Constructor with required fields
    public TrafficEvent(String id, Instant timestamp, String clientIp, String requestPath, String requestMethod) {
        this.id = id;
        this.timestamp = timestamp;
        this.clientIp = clientIp;
        this.requestPath = requestPath;
        this.requestMethod = requestMethod;
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
    
    public String getClientIp() { return clientIp; }
    public void setClientIp(String clientIp) { this.clientIp = clientIp; }
    
    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }
    
    public String getJa3Fingerprint() { return ja3Fingerprint; }
    public void setJa3Fingerprint(String ja3Fingerprint) { this.ja3Fingerprint = ja3Fingerprint; }
    
    public String getAsn() { return asn; }
    public void setAsn(String asn) { this.asn = asn; }
    
    public String getRequestPath() { return requestPath; }
    public void setRequestPath(String requestPath) { this.requestPath = requestPath; }
    
    public String getRequestMethod() { return requestMethod; }
    public void setRequestMethod(String requestMethod) { this.requestMethod = requestMethod; }
    
    public Map<String, String> getHeaders() { return headers; }
    public void setHeaders(Map<String, String> headers) { this.headers = headers; }
    
    public Map<String, Double> getFeatures() { return features; }
    public void setFeatures(Map<String, Double> features) { this.features = features; }
    
    public Double getThreatScore() { return threatScore; }
    public void setThreatScore(Double threatScore) { this.threatScore = threatScore; }
    
    public List<String> getThreatCategories() { return threatCategories; }
    public void setThreatCategories(List<String> threatCategories) { this.threatCategories = threatCategories; }
    
    public Integer getResponseCode() { return responseCode; }
    public void setResponseCode(Integer responseCode) { this.responseCode = responseCode; }
    
    public Long getResponseSize() { return responseSize; }
    public void setResponseSize(Long responseSize) { this.responseSize = responseSize; }
    
    public Long getProcessingTime() { return processingTime; }
    public void setProcessingTime(Long processingTime) { this.processingTime = processingTime; }
    
    public String getGeoCountry() { return geoCountry; }
    public void setGeoCountry(String geoCountry) { this.geoCountry = geoCountry; }
    
    public String getGeoCity() { return geoCity; }
    public void setGeoCity(String geoCity) { this.geoCity = geoCity; }
    
    // Utility methods
    public boolean hasFeatures() {
        return features != null && !features.isEmpty();
    }
    
    public boolean hasThreatScore() {
        return threatScore != null;
    }
    
    public boolean isHighThreat() {
        return threatScore != null && threatScore >= 0.8;
    }
    
    public boolean isMediumThreat() {
        return threatScore != null && threatScore >= 0.5 && threatScore < 0.8;
    }
    
    public boolean isLowThreat() {
        return threatScore != null && threatScore < 0.5;
    }
    
    public String getClientKey() {
        return clientIp + ":" + (userAgent != null ? userAgent.hashCode() : "unknown");
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TrafficEvent that = (TrafficEvent) o;
        return Objects.equals(id, that.id) &&
               Objects.equals(timestamp, that.timestamp) &&
               Objects.equals(clientIp, that.clientIp);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, timestamp, clientIp);
    }
    
    @Override
    public String toString() {
        return "TrafficEvent{" +
                "id='" + id + '\'' +
                ", timestamp=" + timestamp +
                ", clientIp='" + clientIp + '\'' +
                ", requestPath='" + requestPath + '\'' +
                ", requestMethod='" + requestMethod + '\'' +
                ", threatScore=" + threatScore +
                '}';
    }
}