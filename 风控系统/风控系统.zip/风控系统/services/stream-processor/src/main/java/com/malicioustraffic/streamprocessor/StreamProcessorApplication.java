package com.malicioustraffic.streamprocessor;

import com.malicioustraffic.streamprocessor.config.StreamProcessorConfig;
import com.malicioustraffic.streamprocessor.job.TrafficAnalysisJob;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Stream Processor Application Main Class
 * 
 * This application processes real-time traffic data from Kafka,
 * extracts features, and performs threat analysis.
 */
public class StreamProcessorApplication {
    
    private static final Logger logger = LoggerFactory.getLogger(StreamProcessorApplication.class);
    
    public static void main(String[] args) throws Exception {
        logger.info("Starting Stream Processor Application...");
        
        // Parse command line parameters
        final ParameterTool params = ParameterTool.fromArgs(args);
        
        // Load configuration
        StreamProcessorConfig config = StreamProcessorConfig.load(params);
        logger.info("Configuration loaded: {}", config);
        
        // Set up the streaming execution environment
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        
        // Configure environment
        configureEnvironment(env, config);
        
        // Create and execute the traffic analysis job
        TrafficAnalysisJob job = new TrafficAnalysisJob(config);
        job.execute(env);
        
        logger.info("Stream Processor Application started successfully");
    }
    
    /**
     * Configure the Flink execution environment
     */
    private static void configureEnvironment(StreamExecutionEnvironment env, StreamProcessorConfig config) {
        // Set parallelism
        env.setParallelism(config.getParallelism());
        
        // Enable checkpointing
        env.enableCheckpointing(config.getCheckpointInterval());
        
        // Set restart strategy
        env.setRestartStrategy(config.getRestartStrategy());
        
        // Configure state backend
        env.setStateBackend(config.getStateBackend());
        
        // Set time characteristic
        env.getConfig().setAutoWatermarkInterval(config.getWatermarkInterval());
        
        logger.info("Flink environment configured with parallelism: {}, checkpoint interval: {}ms", 
                   config.getParallelism(), config.getCheckpointInterval());
    }
}