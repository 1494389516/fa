package com.malicioustraffic.streamprocessor.function;

import com.malicioustraffic.streamprocessor.model.TrafficEvent;
import com.malicioustraffic.streamprocessor.model.ThreatScore;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.metrics.Gauge;
import org.apache.flink.metrics.Histogram;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.*;

/**
 * Anomaly Detection Function
 * Detects anomalies in traffic patterns using statistical methods and rule-based detection
 */
public class AnomalyDetectionFunction extends RichFlatMapFunction<TrafficEvent, ThreatScore> {
    
    private static final Logger logger = LoggerFactory.getLogger(AnomalyDetectionFunction.class);
    private static final long serialVersionUID = 1L;
    
    // Configuration
    private final double anomalyThreshold;
    private final int windowSizeMinutes;
    private final int minEventsForDetection;
    
    // State for maintaining client statistics
    private transient ValueState<ClientStatistics> clientStatsState;
    
    // Metrics
    private transient Counter anomaliesDetected;
    private transient Counter eventsProcessed;
    private transient Histogram anomalyScore;
    private transient Gauge<Integer> activeClients;
    
    // Active clients counter
    private transient Set<String> activeClientSet;
    
    public AnomalyDetectionFunction(double anomalyThreshold, int windowSizeMinutes, int minEventsForDetection) {
        this.anomalyThreshold = anomalyThreshold;
        this.windowSizeMinutes = windowSizeMinutes;
        this.minEventsForDetection = minEventsForDetection;
    }
    
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        
        // Initialize state
        ValueStateDescriptor<ClientStatistics> statsDescriptor = new ValueStateDescriptor<>(
            "client-statistics",
            TypeInformation.of(new TypeHint<ClientStatistics>() {})
        );
        clientStatsState = getRuntimeContext().getState(statsDescriptor);
        
        // Initialize metrics
        anomaliesDetected = getRuntimeContext()
            .getMetricGroup()
            .counter("anomalies_detected");
            
        eventsProcessed = getRuntimeContext()
            .getMetricGroup()
            .counter("events_processed");
            
        anomalyScore = getRuntimeContext()
            .getMetricGroup()
            .histogram("anomaly_score");
            
        activeClientSet = new HashSet<>();
        activeClients = getRuntimeContext()
            .getMetricGroup()
            .gauge("active_clients", () -> activeClientSet.size());
    }
    
    @Override
    public void flatMap(TrafficEvent event, Collector<ThreatScore> out) throws Exception {
        long startTime = System.currentTimeMillis();
        
        try {
            String clientKey = event.getClientKey();
            activeClientSet.add(clientKey);
            
            // Get or create client statistics
            ClientStatistics stats = clientStatsState.value();
            if (stats == null) {
                stats = new ClientStatistics(clientKey);
            }
            
            // Update statistics with new event
            stats.updateWithEvent(event);
            
            // Detect anomalies if we have enough data
            if (stats.getEventCount() >= minEventsForDetection) {
                ThreatScore threatScore = detectAnomalies(event, stats);
                
                if (threatScore != null && threatScore.getScore() >= anomalyThreshold) {
                    out.collect(threatScore);
                    anomaliesDetected.inc();
                    anomalyScore.update((long) (threatScore.getScore() * 100));
                    
                    logger.info("Anomaly detected for client {}: score={}, categories={}", 
                               clientKey, threatScore.getScore(), threatScore.getCategories());
                }
            }
            
            // Update state
            clientStatsState.update(stats);
            eventsProcessed.inc();
            
        } catch (Exception e) {
            logger.error("Error processing event {}: {}", event.getId(), e.getMessage(), e);
        } finally {
            long processingTime = System.currentTimeMillis() - startTime;
            logger.debug("Processed event {} in {}ms", event.getId(), processingTime);
        }
    }
    
    /**
     * Detect anomalies based on client statistics
     */
    private ThreatScore detectAnomalies(TrafficEvent event, ClientStatistics stats) {
        Map<String, Double> anomalyScores = new HashMap<>();
        List<String> detectedAnomalies = new ArrayList<>();
        
        // 1. Request frequency anomaly
        double freqAnomaly = detectFrequencyAnomaly(stats);
        anomalyScores.put("frequency_anomaly", freqAnomaly);
        if (freqAnomaly > 0.7) {
            detectedAnomalies.add("high_frequency");
        }
        
        // 2. Path diversity anomaly
        double pathAnomaly = detectPathDiversityAnomaly(stats);
        anomalyScores.put("path_diversity_anomaly", pathAnomaly);
        if (pathAnomaly > 0.7) {
            detectedAnomalies.add("path_scanning");
        }
        
        // 3. Time pattern anomaly
        double timeAnomaly = detectTimePatternAnomaly(stats);
        anomalyScores.put("time_pattern_anomaly", timeAnomaly);
        if (timeAnomaly > 0.8) {
            detectedAnomalies.add("bot_behavior");
        }
        
        // 4. Response pattern anomaly
        double responseAnomaly = detectResponsePatternAnomaly(stats);
        anomalyScores.put("response_pattern_anomaly", responseAnomaly);
        if (responseAnomaly > 0.6) {
            detectedAnomalies.add("error_pattern");
        }
        
        // 5. User-Agent consistency anomaly
        double uaAnomaly = detectUserAgentAnomaly(stats);
        anomalyScores.put("user_agent_anomaly", uaAnomaly);
        if (uaAnomaly > 0.5) {
            detectedAnomalies.add("ua_inconsistency");
        }
        
        // 6. Session behavior anomaly
        double sessionAnomaly = detectSessionAnomaly(stats);
        anomalyScores.put("session_anomaly", sessionAnomaly);
        if (sessionAnomaly > 0.6) {
            detectedAnomalies.add("session_anomaly");
        }
        
        // Calculate overall anomaly score
        double overallScore = calculateOverallAnomalyScore(anomalyScores);
        
        if (overallScore >= anomalyThreshold || !detectedAnomalies.isEmpty()) {
            return createThreatScore(event, overallScore, anomalyScores, detectedAnomalies, stats);
        }
        
        return null;
    }
    
    /**
     * Detect frequency-based anomalies
     */
    private double detectFrequencyAnomaly(ClientStatistics stats) {
        double requestsPerMinute = stats.getRequestsPerMinute();
        
        // Thresholds for different anomaly levels
        if (requestsPerMinute > 100) {
            return 1.0; // Very high frequency
        } else if (requestsPerMinute > 50) {
            return 0.8; // High frequency
        } else if (requestsPerMinute > 20) {
            return 0.5; // Moderate frequency
        }
        
        return 0.0;
    }
    
    /**
     * Detect path diversity anomalies
     */
    private double detectPathDiversityAnomaly(ClientStatistics stats) {
        double pathDiversity = stats.getPathDiversity();
        int uniquePaths = stats.getUniquePaths().size();
        
        // Very high diversity (scanning behavior)
        if (pathDiversity > 0.9 && uniquePaths > 50) {
            return 1.0;
        } else if (pathDiversity > 0.8 && uniquePaths > 20) {
            return 0.8;
        }
        
        // Very low diversity (repeated requests)
        if (pathDiversity < 0.1 && stats.getEventCount() > 50) {
            return 0.7;
        }
        
        return 0.0;
    }
    
    /**
     * Detect time pattern anomalies
     */
    private double detectTimePatternAnomaly(ClientStatistics stats) {
        List<Long> intervals = stats.getRequestIntervals();
        
        if (intervals.size() < 5) {
            return 0.0;
        }
        
        // Calculate coefficient of variation
        double mean = intervals.stream().mapToLong(Long::longValue).average().orElse(0.0);
        double variance = intervals.stream()
            .mapToDouble(interval -> Math.pow(interval - mean, 2))
            .average()
            .orElse(0.0);
        
        double stdDev = Math.sqrt(variance);
        double coefficientOfVariation = mean > 0 ? stdDev / mean : 0.0;
        
        // Low coefficient of variation indicates regular pattern (bot-like)
        if (coefficientOfVariation < 0.1 && mean < 5000) { // Very regular, fast requests
            return 1.0;
        } else if (coefficientOfVariation < 0.2 && mean < 10000) {
            return 0.8;
        } else if (coefficientOfVariation < 0.3) {
            return 0.5;
        }
        
        return 0.0;
    }
    
    /**
     * Detect response pattern anomalies
     */
    private double detectResponsePatternAnomaly(ClientStatistics stats) {
        Map<Integer, Integer> responseCodes = stats.getResponseCodes();
        int totalRequests = stats.getEventCount();
        
        if (totalRequests < 10) {
            return 0.0;
        }
        
        // Calculate error rate
        int errorCount = responseCodes.entrySet().stream()
            .filter(entry -> entry.getKey() >= 400)
            .mapToInt(Map.Entry::getValue)
            .sum();
        
        double errorRate = (double) errorCount / totalRequests;
        
        // High error rate indicates potential attack
        if (errorRate > 0.8) {
            return 1.0; // Very high error rate
        } else if (errorRate > 0.5) {
            return 0.8; // High error rate
        } else if (errorRate > 0.3) {
            return 0.5; // Moderate error rate
        }
        
        // Check for specific error patterns
        int notFoundCount = responseCodes.getOrDefault(404, 0);
        int unauthorizedCount = responseCodes.getOrDefault(401, 0);
        int forbiddenCount = responseCodes.getOrDefault(403, 0);
        
        double notFoundRate = (double) notFoundCount / totalRequests;
        double authErrorRate = (double) (unauthorizedCount + forbiddenCount) / totalRequests;
        
        if (notFoundRate > 0.7) {
            return 0.9; // Scanning for non-existent resources
        }
        
        if (authErrorRate > 0.5) {
            return 0.8; // Potential brute force attack
        }
        
        return 0.0;
    }
    
    /**
     * Detect User-Agent anomalies
     */
    private double detectUserAgentAnomaly(ClientStatistics stats) {
        Set<String> userAgents = stats.getUserAgents();
        
        // Multiple User-Agents from same client
        if (userAgents.size() > 5) {
            return 0.8;
        } else if (userAgents.size() > 2) {
            return 0.4;
        }
        
        // Check for suspicious User-Agent patterns
        for (String ua : userAgents) {
            if (ua == null || ua.isEmpty()) {
                return 0.6; // Missing User-Agent
            }
            
            String lowerUA = ua.toLowerCase();
            if (lowerUA.contains("bot") || lowerUA.contains("crawler") || 
                lowerUA.contains("scanner") || lowerUA.contains("sqlmap") ||
                lowerUA.contains("nikto") || lowerUA.contains("nmap")) {
                return 0.9; // Known malicious tools
            }
        }
        
        return 0.0;
    }
    
    /**
     * Detect session behavior anomalies
     */
    private double detectSessionAnomaly(ClientStatistics stats) {
        double anomalyScore = 0.0;
        
        // Check session duration
        long sessionDuration = stats.getSessionDurationMinutes();
        if (sessionDuration > 60) { // Very long session
            anomalyScore += 0.3;
        }
        
        // Check request distribution over time
        Map<Integer, Integer> hourlyDistribution = stats.getHourlyDistribution();
        if (hourlyDistribution.size() == 1) {
            // All requests in same hour - could be automated
            anomalyScore += 0.2;
        }
        
        // Check for off-hours activity
        int offHoursRequests = 0;
        int totalRequests = stats.getEventCount();
        
        for (Map.Entry<Integer, Integer> entry : hourlyDistribution.entrySet()) {
            int hour = entry.getKey();
            if (hour < 6 || hour > 22) { // Off hours (before 6 AM or after 10 PM)
                offHoursRequests += entry.getValue();
            }
        }
        
        double offHoursRatio = (double) offHoursRequests / totalRequests;
        if (offHoursRatio > 0.8) {
            anomalyScore += 0.4;
        }
        
        return Math.min(anomalyScore, 1.0);
    }
    
    /**
     * Calculate overall anomaly score from individual scores
     */
    private double calculateOverallAnomalyScore(Map<String, Double> anomalyScores) {
        // Weighted combination of anomaly scores
        Map<String, Double> weights = Map.of(
            "frequency_anomaly", 0.25,
            "path_diversity_anomaly", 0.20,
            "time_pattern_anomaly", 0.20,
            "response_pattern_anomaly", 0.15,
            "user_agent_anomaly", 0.10,
            "session_anomaly", 0.10
        );
        
        double weightedSum = 0.0;
        double totalWeight = 0.0;
        
        for (Map.Entry<String, Double> entry : anomalyScores.entrySet()) {
            String key = entry.getKey();
            Double score = entry.getValue();
            Double weight = weights.get(key);
            
            if (weight != null && score != null) {
                weightedSum += score * weight;
                totalWeight += weight;
            }
        }
        
        return totalWeight > 0 ? weightedSum / totalWeight : 0.0;
    }
    
    /**
     * Create ThreatScore object from anomaly detection results
     */
    private ThreatScore createThreatScore(TrafficEvent event, double overallScore, 
                                        Map<String, Double> anomalyScores, 
                                        List<String> detectedAnomalies,
                                        ClientStatistics stats) {
        
        ThreatScore threatScore = new ThreatScore(event.getId(), overallScore, 0.8);
        threatScore.setClientIp(event.getClientIp());
        threatScore.setRequestPath(event.getRequestPath());
        threatScore.setUserAgent(event.getUserAgent());
        threatScore.setCategories(detectedAnomalies);
        threatScore.setModelVersion("anomaly-detector-v1.0");
        threatScore.setTimestamp(Instant.now());
        
        // Add detailed features
        Map<String, Double> features = new HashMap<>(anomalyScores);
        features.put("requests_per_minute", stats.getRequestsPerMinute());
        features.put("path_diversity", stats.getPathDiversity());
        features.put("session_duration_minutes", (double) stats.getSessionDurationMinutes());
        features.put("unique_paths_count", (double) stats.getUniquePaths().size());
        features.put("error_rate", stats.getErrorRate());
        
        threatScore.setFeatures(features);
        
        return threatScore;
    }
    
    /**
     * Client Statistics class to maintain state
     */
    public static class ClientStatistics {
        private String clientKey;
        private int eventCount;
        private long firstEventTime;
        private long lastEventTime;
        private List<Long> requestIntervals;
        private Set<String> uniquePaths;
        private Set<String> userAgents;
        private Map<Integer, Integer> responseCodes;
        private Map<Integer, Integer> hourlyDistribution;
        private List<Long> eventTimestamps;
        
        public ClientStatistics() {
            // Default constructor for serialization
        }
        
        public ClientStatistics(String clientKey) {
            this.clientKey = clientKey;
            this.eventCount = 0;
            this.requestIntervals = new ArrayList<>();
            this.uniquePaths = new HashSet<>();
            this.userAgents = new HashSet<>();
            this.responseCodes = new HashMap<>();
            this.hourlyDistribution = new HashMap<>();
            this.eventTimestamps = new ArrayList<>();
        }
        
        public void updateWithEvent(TrafficEvent event) {
            eventCount++;
            
            long eventTime = event.getTimestamp().toEpochMilli();
            
            if (firstEventTime == 0) {
                firstEventTime = eventTime;
            }
            
            if (lastEventTime > 0) {
                long interval = eventTime - lastEventTime;
                requestIntervals.add(interval);
            }
            
            lastEventTime = eventTime;
            eventTimestamps.add(eventTime);
            
            // Update path statistics
            if (event.getRequestPath() != null) {
                uniquePaths.add(event.getRequestPath());
            }
            
            // Update user agent statistics
            if (event.getUserAgent() != null) {
                userAgents.add(event.getUserAgent());
            }
            
            // Update response code statistics
            if (event.getResponseCode() != null) {
                responseCodes.merge(event.getResponseCode(), 1, Integer::sum);
            }
            
            // Update hourly distribution
            int hour = event.getTimestamp().atZone(java.time.ZoneOffset.UTC).getHour();
            hourlyDistribution.merge(hour, 1, Integer::sum);
            
            // Keep only recent intervals (last 1000)
            if (requestIntervals.size() > 1000) {
                requestIntervals = new ArrayList<>(requestIntervals.subList(500, requestIntervals.size()));
            }
            
            // Keep only recent timestamps (last 1000)
            if (eventTimestamps.size() > 1000) {
                eventTimestamps = new ArrayList<>(eventTimestamps.subList(500, eventTimestamps.size()));
            }
        }
        
        // Getters
        public String getClientKey() { return clientKey; }
        public int getEventCount() { return eventCount; }
        public List<Long> getRequestIntervals() { return requestIntervals; }
        public Set<String> getUniquePaths() { return uniquePaths; }
        public Set<String> getUserAgents() { return userAgents; }
        public Map<Integer, Integer> getResponseCodes() { return responseCodes; }
        public Map<Integer, Integer> getHourlyDistribution() { return hourlyDistribution; }
        
        public double getRequestsPerMinute() {
            if (eventCount < 2) return 0.0;
            long durationMs = lastEventTime - firstEventTime;
            double durationMinutes = durationMs / (1000.0 * 60.0);
            return durationMinutes > 0 ? eventCount / durationMinutes : 0.0;
        }
        
        public double getPathDiversity() {
            return eventCount > 0 ? (double) uniquePaths.size() / eventCount : 0.0;
        }
        
        public long getSessionDurationMinutes() {
            if (firstEventTime == 0 || lastEventTime == 0) return 0;
            return (lastEventTime - firstEventTime) / (1000 * 60);
        }
        
        public double getErrorRate() {
            if (eventCount == 0) return 0.0;
            int errorCount = responseCodes.entrySet().stream()
                .filter(entry -> entry.getKey() >= 400)
                .mapToInt(Map.Entry::getValue)
                .sum();
            return (double) errorCount / eventCount;
        }
    }
}