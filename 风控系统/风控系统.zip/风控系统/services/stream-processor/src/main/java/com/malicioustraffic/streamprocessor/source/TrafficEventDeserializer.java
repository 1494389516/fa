package com.malicioustraffic.streamprocessor.source;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.malicioustraffic.streamprocessor.model.TrafficEvent;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Kafka Deserializer for TrafficEvent
 */
public class TrafficEventDeserializer implements DeserializationSchema<TrafficEvent> {
    
    private static final Logger logger = LoggerFactory.getLogger(TrafficEventDeserializer.class);
    private static final long serialVersionUID = 1L;
    
    private transient ObjectMapper objectMapper;
    
    @Override
    public void open(InitializationContext context) throws Exception {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }
    
    @Override
    public TrafficEvent deserialize(byte[] message) throws IOException {
        if (message == null || message.length == 0) {
            logger.warn("Received empty message");
            return null;
        }
        
        try {
            String jsonString = new String(message, StandardCharsets.UTF_8);
            logger.debug("Deserializing message: {}", jsonString);
            
            TrafficEvent event = objectMapper.readValue(jsonString, TrafficEvent.class);
            
            // Validate required fields
            if (event.getId() == null || event.getClientIp() == null || 
                event.getRequestPath() == null || event.getTimestamp() == null) {
                logger.warn("Received TrafficEvent with missing required fields: {}", event);
                return null;
            }
            
            return event;
            
        } catch (Exception e) {
            logger.error("Failed to deserialize TrafficEvent: {}", e.getMessage(), e);
            return null;
        }
    }
    
    @Override
    public boolean isEndOfStream(TrafficEvent nextElement) {
        return false;
    }
    
    @Override
    public TypeInformation<TrafficEvent> getProducedType() {
        return TypeInformation.of(TrafficEvent.class);
    }
}