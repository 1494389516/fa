package com.malicioustraffic.streamprocessor.sink;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.malicioustraffic.streamprocessor.model.ThreatScore;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;

/**
 * Kafka Serializer for ThreatScore
 */
public class ThreatScoreSerializer implements SerializationSchema<ThreatScore> {
    
    private static final Logger logger = LoggerFactory.getLogger(ThreatScoreSerializer.class);
    private static final long serialVersionUID = 1L;
    
    private transient ObjectMapper objectMapper;
    
    @Override
    public void open(InitializationContext context) throws Exception {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }
    
    @Override
    public byte[] serialize(ThreatScore element) {
        try {
            String jsonString = objectMapper.writeValueAsString(element);
            logger.debug("Serializing ThreatScore: {}", jsonString);
            return jsonString.getBytes(StandardCharsets.UTF_8);
            
        } catch (Exception e) {
            logger.error("Failed to serialize ThreatScore: {}", e.getMessage(), e);
            return null;
        }
    }
}