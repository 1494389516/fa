package com.malicioustraffic.streamprocessor.function;

import com.malicioustraffic.streamprocessor.model.TrafficEvent;
import com.malicioustraffic.streamprocessor.model.ThreatScore;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.metrics.Histogram;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Feature Extraction Function
 * Extracts various features from traffic events for threat analysis
 */
public class FeatureExtractionFunction extends RichMapFunction<TrafficEvent, TrafficEvent> {
    
    private static final Logger logger = LoggerFactory.getLogger(FeatureExtractionFunction.class);
    private static final long serialVersionUID = 1L;
    
    // Metrics
    private transient Counter processedEvents;
    private transient Counter extractedFeatures;
    private transient Histogram processingTime;
    
    // Feature extraction patterns
    private static final List<Pattern> SUSPICIOUS_URI_PATTERNS = Arrays.asList(
        Pattern.compile("\\.\\.[\\/\\\\]"),           // Path traversal
        Pattern.compile("(union|select|insert|delete|drop)\\s", Pattern.CASE_INSENSITIVE), // SQL injection
        Pattern.compile("<script[^>]*>", Pattern.CASE_INSENSITIVE), // XSS
        Pattern.compile("(admin|config|debug|\\.env|backup)", Pattern.CASE_INSENSITIVE), // Sensitive paths
        Pattern.compile("\\.(php|asp|jsp|cgi)$", Pattern.CASE_INSENSITIVE) // Script files
    );
    
    private static final List<Pattern> MALICIOUS_USER_AGENT_PATTERNS = Arrays.asList(
        Pattern.compile("(sqlmap|nikto|nmap|masscan|nessus|openvas|w3af)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(python-requests|python-urllib|curl|wget|libwww)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(test|scanner|bot.*bot|crawler.*crawler)$", Pattern.CASE_INSENSITIVE)
    );
    
    private static final Set<String> DANGEROUS_HTTP_METHODS = Set.of("TRACE", "TRACK", "DEBUG", "CONNECT");
    private static final Set<String> SUSPICIOUS_HEADERS = Set.of(
        "x-forwarded-host", "x-original-url", "x-rewrite-url", "x-real-ip"
    );
    
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        
        // Initialize metrics
        processedEvents = getRuntimeContext()
            .getMetricGroup()
            .counter("processed_events");
            
        extractedFeatures = getRuntimeContext()
            .getMetricGroup()
            .counter("extracted_features");
            
        processingTime = getRuntimeContext()
            .getMetricGroup()
            .histogram("processing_time_ms");
    }
    
    @Override
    public TrafficEvent map(TrafficEvent event) throws Exception {
        long startTime = System.currentTimeMillis();
        
        try {
            // Extract features and add them to the event
            Map<String, Double> features = extractFeatures(event);
            event.setFeatures(features);
            
            processedEvents.inc();
            extractedFeatures.inc(features.size());
            
            logger.debug("Extracted {} features for event {}", features.size(), event.getId());
            
        } catch (Exception e) {
            logger.error("Error extracting features for event {}: {}", event.getId(), e.getMessage(), e);
            // Set empty features map on error
            event.setFeatures(new HashMap<>());
        } finally {
            long processingTimeMs = System.currentTimeMillis() - startTime;
            processingTime.update(processingTimeMs);
        }
        
        return event;
    }

    /**
     * Extract comprehensive features from traffic event
     */
    private Map<String, Double> extractFeatures(TrafficEvent event) {
        Map<String, Double> features = new HashMap<>();
        
        // Request-based features
        features.putAll(extractRequestFeatures(event));
        
        // Client-based features
        features.putAll(extractClientFeatures(event));
        
        // Temporal features
        features.putAll(extractTemporalFeatures(event));
        
        // Header-based features
        features.putAll(extractHeaderFeatures(event));
        
        return features;
    }
    
    /**
     * Extract request-based features
     */
    private Map<String, Double> extractRequestFeatures(TrafficEvent event) {
        Map<String, Double> features = new HashMap<>();
        
        String requestPath = event.getRequestPath();
        String requestMethod = event.getRequestMethod();
        
        features.put("uri_length", requestPath != null ? (double) requestPath.length() : 0.0);
        features.put("path_segments", requestPath != null ? (double) requestPath.split("/").length : 0.0);
        
        double queryParams = 0.0;
        if (requestPath != null && requestPath.contains("?")) {
            String queryString = requestPath.substring(requestPath.indexOf("?") + 1);
            queryParams = (double) queryString.split("&").length;
        }
        features.put("query_params", queryParams);
        
        double suspiciousPatterns = 0.0;
        if (requestPath != null) {
            for (Pattern pattern : SUSPICIOUS_URI_PATTERNS) {
                if (pattern.matcher(requestPath).find()) {
                    suspiciousPatterns += 1.0;
                }
            }
        }
        features.put("suspicious_uri_patterns", suspiciousPatterns);
        
        double methodAnomaly = 0.0;
        if (requestMethod != null) {
            if (DANGEROUS_HTTP_METHODS.contains(requestMethod.toUpperCase())) {
                methodAnomaly = 1.0;
            } else if (!"GET".equals(requestMethod) && !"POST".equals(requestMethod)) {
                methodAnomaly = 0.3;
            }
        }
        features.put("method_anomaly", methodAnomaly);
        
        double fileExtensionRisk = 0.0;
        if (requestPath != null) {
            String lowerPath = requestPath.toLowerCase();
            if (lowerPath.contains(".php") || lowerPath.contains(".asp") || 
                lowerPath.contains(".jsp") || lowerPath.contains(".cgi")) {
                fileExtensionRisk = 0.7;
            } else if (lowerPath.contains(".exe") || lowerPath.contains(".bat") || 
                      lowerPath.contains(".sh")) {
                fileExtensionRisk = 1.0;
            }
        }
        features.put("file_extension_risk", fileExtensionRisk);
        
        return features;
    }
    
    /**
     * Extract client-based features
     */
    private Map<String, Double> extractClientFeatures(TrafficEvent event) {
        Map<String, Double> features = new HashMap<>();
        
        String userAgent = event.getUserAgent();
        String clientIp = event.getClientIp();
        String asn = event.getAsn();
        String ja3 = event.getJa3Fingerprint();
        
        features.put("user_agent_anomaly", calculateUserAgentAnomaly(userAgent));
        features.put("user_agent_length", userAgent != null ? (double) userAgent.length() : 0.0);
        features.put("is_private_ip", isPrivateIP(clientIp) ? 1.0 : 0.0);
        features.put("asn_reputation", calculateASNReputation(asn));
        features.put("ja3_present", (ja3 != null && !ja3.isEmpty()) ? 1.0 : 0.0);
        features.put("ja3_suspicion", calculateJA3Suspicion(ja3));
        
        return features;
    }
    
    /**
     * Extract temporal features
     */
    private Map<String, Double> extractTemporalFeatures(TrafficEvent event) {
        Map<String, Double> features = new HashMap<>();
        
        Instant timestamp = event.getTimestamp();
        
        if (timestamp != null) {
            int hour = timestamp.atZone(java.time.ZoneOffset.UTC).getHour();
            features.put("hour_of_day", (double) hour);
            
            int dayOfWeek = timestamp.atZone(java.time.ZoneOffset.UTC).getDayOfWeek().getValue();
            features.put("day_of_week", (double) dayOfWeek);
            
            features.put("is_weekend", (dayOfWeek == 6 || dayOfWeek == 7) ? 1.0 : 0.0);
        } else {
            features.put("hour_of_day", 0.0);
            features.put("day_of_week", 0.0);
            features.put("is_weekend", 0.0);
        }
        
        return features;
    }
    
    /**
     * Extract header-based features
     */
    private Map<String, Double> extractHeaderFeatures(TrafficEvent event) {
        Map<String, Double> features = new HashMap<>();
        
        Map<String, String> headers = event.getHeaders();
        
        if (headers != null) {
            features.put("header_count", (double) headers.size());
            
            double missingHeaders = 0.0;
            String[] commonHeaders = {"accept", "accept-language", "accept-encoding", "user-agent"};
            for (String header : commonHeaders) {
                if (!headers.containsKey(header.toLowerCase())) {
                    missingHeaders += 1.0;
                }
            }
            features.put("missing_common_headers", missingHeaders);
            
            double suspiciousHeadersCount = 0.0;
            for (String header : headers.keySet()) {
                if (SUSPICIOUS_HEADERS.contains(header.toLowerCase())) {
                    suspiciousHeadersCount += 1.0;
                }
            }
            features.put("suspicious_headers_count", suspiciousHeadersCount);
            
            double contentLengthAnomaly = 0.0;
            String contentLength = headers.get("content-length");
            String method = event.getRequestMethod();
            
            if ("GET".equals(method) && contentLength != null) {
                contentLengthAnomaly = 1.0;
            } else if (("POST".equals(method) || "PUT".equals(method)) && contentLength == null) {
                contentLengthAnomaly = 1.0;
            }
            features.put("content_length_anomaly", contentLengthAnomaly);
            
        } else {
            features.put("header_count", 0.0);
            features.put("missing_common_headers", 4.0);
            features.put("suspicious_headers_count", 0.0);
            features.put("content_length_anomaly", 0.0);
        }
        
        return features;
    }
    
    /**
     * Calculate User-Agent anomaly score
     */
    private double calculateUserAgentAnomaly(String userAgent) {
        if (userAgent == null || userAgent.isEmpty()) {
            return 0.8; // Missing User-Agent is suspicious
        }
        
        double anomalyScore = 0.0;
        
        // Check for malicious patterns
        for (Pattern pattern : MALICIOUS_USER_AGENT_PATTERNS) {
            if (pattern.matcher(userAgent).find()) {
                anomalyScore = Math.max(anomalyScore, 0.9);
            }
        }
        
        // Check length anomalies
        if (userAgent.length() < 10) {
            anomalyScore = Math.max(anomalyScore, 0.6);
        } else if (userAgent.length() > 1000) {
            anomalyScore = Math.max(anomalyScore, 0.4);
        }
        
        // Check for common browser indicators
        boolean hasBrowserIndicator = userAgent.contains("Mozilla") || 
                                    userAgent.contains("Chrome") || 
                                    userAgent.contains("Safari") || 
                                    userAgent.contains("Firefox") || 
                                    userAgent.contains("Edge");
        
        if (!hasBrowserIndicator) {
            anomalyScore = Math.max(anomalyScore, 0.3);
        }
        
        return anomalyScore;
    }
    
    /**
     * Check if IP address is private
     */
    private boolean isPrivateIP(String ip) {
        if (ip == null) return false;
        
        return ip.startsWith("192.168.") || 
               ip.startsWith("10.") || 
               ip.startsWith("172.16.") || 
               ip.startsWith("172.17.") || 
               ip.startsWith("172.18.") || 
               ip.startsWith("172.19.") || 
               ip.startsWith("172.2") || 
               ip.startsWith("172.30.") || 
               ip.startsWith("172.31.") || 
               ip.equals("127.0.0.1");
    }
    
    /**
     * Calculate ASN reputation score (simplified)
     */
    private double calculateASNReputation(String asn) {
        if (asn == null || asn.isEmpty()) {
            return 0.0;
        }
        
        // Simplified ASN reputation - in real implementation, 
        // this would query a threat intelligence database
        Set<String> knownBadASNs = Set.of("AS12345", "AS67890", "AS99999");
        
        if (knownBadASNs.contains(asn)) {
            return 0.9; // High threat
        }
        
        // Default neutral reputation
        return 0.1;
    }
    
    /**
     * Calculate JA3 suspicion score (simplified)
     */
    private double calculateJA3Suspicion(String ja3) {
        if (ja3 == null || ja3.isEmpty()) {
            return 0.0;
        }
        
        // Simplified JA3 analysis - in real implementation,
        // this would check against known malicious JA3 fingerprints
        Set<String> knownMaliciousJA3 = Set.of(
            "769,47-53-5-10-49161-49162-49171-49172-50-56-19-4,0-10-11,23-24-25,0", // Metasploit
            "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-21,29-23-24,0" // Nmap
        );
        
        if (knownMaliciousJA3.contains(ja3)) {
            return 1.0; // Definitely malicious
        }
        
        // Check for suspicious patterns in JA3
        if (ja3.contains("NULL") || ja3.contains("RC4") || ja3.contains("MD5")) {
            return 0.7; // Weak crypto
        }
        
        return 0.0; // Normal
    }
}