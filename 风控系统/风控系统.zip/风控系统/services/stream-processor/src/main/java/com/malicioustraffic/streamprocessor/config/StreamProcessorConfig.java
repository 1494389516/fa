package com.malicioustraffic.streamprocessor.config;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.contrib.streaming.state.EmbeddedRocksDBStateBackend;
import org.apache.flink.runtime.state.StateBackend;
import org.apache.flink.runtime.state.hashmap.HashMapStateBackend;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.restartstrategy.RestartStrategies.RestartStrategyConfiguration;
import org.apache.flink.api.common.time.Time;

import java.io.Serializable;
import java.util.Properties;

/**
 * Configuration class for Stream Processor
 */
public class StreamProcessorConfig implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Flink Configuration
    private final int parallelism;
    private final long checkpointInterval;
    private final long watermarkInterval;
    private final String stateBackendType;
    private final RestartStrategyConfiguration restartStrategy;
    
    // Kafka Configuration
    private final String kafkaBrokers;
    private final String inputTopic;
    private final String outputTopic;
    private final String consumerGroupId;
    private final Properties kafkaConsumerProperties;
    private final Properties kafkaProducerProperties;
    
    // Database Configuration
    private final String jdbcUrl;
    private final String jdbcUsername;
    private final String jdbcPassword;
    private final String jdbcDriverClass;
    
    // Processing Configuration
    private final int windowSizeSeconds;
    private final int slidingIntervalSeconds;
    private final double threatThreshold;
    private final int maxOutOfOrdernessSeconds;
    
    // Metrics Configuration
    private final boolean metricsEnabled;
    private final String metricsReporterType;
    private final int metricsReportInterval;

    // Threat Analysis Configuration
    private final ThreatAnalysisConfig threatAnalysisConfig;
    
    private StreamProcessorConfig(Builder builder) {
        this.parallelism = builder.parallelism;
        this.checkpointInterval = builder.checkpointInterval;
        this.watermarkInterval = builder.watermarkInterval;
        this.stateBackendType = builder.stateBackendType;
        this.restartStrategy = builder.restartStrategy;
        
        this.kafkaBrokers = builder.kafkaBrokers;
        this.inputTopic = builder.inputTopic;
        this.outputTopic = builder.outputTopic;
        this.consumerGroupId = builder.consumerGroupId;
        this.kafkaConsumerProperties = builder.kafkaConsumerProperties;
        this.kafkaProducerProperties = builder.kafkaProducerProperties;
        
        this.jdbcUrl = builder.jdbcUrl;
        this.jdbcUsername = builder.jdbcUsername;
        this.jdbcPassword = builder.jdbcPassword;
        this.jdbcDriverClass = builder.jdbcDriverClass;
        
        this.windowSizeSeconds = builder.windowSizeSeconds;
        this.slidingIntervalSeconds = builder.slidingIntervalSeconds;
        this.threatThreshold = builder.threatThreshold;
        this.maxOutOfOrdernessSeconds = builder.maxOutOfOrdernessSeconds;
        
        this.metricsEnabled = builder.metricsEnabled;
        this.metricsReporterType = builder.metricsReporterType;
        this.metricsReportInterval = builder.metricsReportInterval;
        this.threatAnalysisConfig = builder.threatAnalysisConfig;
    }
    
    /**
     * Load configuration from environment-specific files, with fallbacks and environment variable overrides.
     */
    public static StreamProcessorConfig load(ParameterTool params) {
        String env = System.getenv().getOrDefault("APP_ENV", "dev");
        
        // 1. Load environment-specific config (e.g., application.prod.conf)
        // 2. Fallback to base application.conf
        // 3. Allow environment variables to override all
        Config config = ConfigFactory.parseResources("application." + env + ".conf")
                .withFallback(ConfigFactory.load("application.conf"))
                .withFallback(ConfigFactory.systemEnvironment());

        return new Builder()
            // Flink Configuration
            .parallelism(config.getInt("flink.parallelism"))
            .checkpointInterval(config.getLong("flink.checkpoint.interval"))
            .watermarkInterval(config.getLong("flink.watermark.interval"))
            .stateBackendType(config.getString("flink.state.backend"))
            
            // Kafka Configuration
            .kafkaBrokers(config.getString("kafka.brokers"))
            .inputTopic(config.getString("kafka.input.topic"))
            .outputTopic(config.getString("kafka.output.topic"))
            .consumerGroupId(config.getString("kafka.consumer.group.id"))
            
            // Database Configuration
            .jdbcUrl(config.getString("database.url"))
            .jdbcUsername(config.getString("database.username"))
            .jdbcPassword(config.getString("database.password"))
            .jdbcDriverClass(config.getString("database.driver"))
            
            // Processing Configuration
            .windowSizeSeconds(config.getInt("processing.window.size"))
            .slidingIntervalSeconds(config.getInt("processing.sliding.interval"))
            .threatThreshold(config.getDouble("processing.threat.threshold"))
            .maxOutOfOrdernessSeconds(config.getInt("processing.max.out.of.orderness"))
            
            // Metrics Configuration
            .metricsEnabled(config.getBoolean("metrics.enabled"))
            .metricsReporterType(config.getString("metrics.reporter"))
            .metricsReportInterval(config.getInt("metrics.report.interval"))

            // Threat Analysis Configuration
            .threatAnalysisConfig(new ThreatAnalysisConfig(config.getConfig("processing.threat-analysis")))
            
            .build();
    }
    
    // Getters
    public int getParallelism() { return parallelism; }
    public long getCheckpointInterval() { return checkpointInterval; }
    public long getWatermarkInterval() { return watermarkInterval; }
    public String getStateBackendType() { return stateBackendType; }
    public RestartStrategyConfiguration getRestartStrategy() { return restartStrategy; }
    
    public String getKafkaBrokers() { return kafkaBrokers; }
    public String getInputTopic() { return inputTopic; }
    public String getOutputTopic() { return outputTopic; }
    public String getConsumerGroupId() { return consumerGroupId; }
    public Properties getKafkaConsumerProperties() { return kafkaConsumerProperties; }
    public Properties getKafkaProducerProperties() { return kafkaProducerProperties; }
    
    public String getJdbcUrl() { return jdbcUrl; }
    public String getJdbcUsername() { return jdbcUsername; }
    public String getJdbcPassword() { return jdbcPassword; }
    public String getJdbcDriverClass() { return jdbcDriverClass; }
    
    public int getWindowSizeSeconds() { return windowSizeSeconds; }
    public int getSlidingIntervalSeconds() { return slidingIntervalSeconds; }
    public double getThreatThreshold() { return threatThreshold; }
    public int getMaxOutOfOrdernessSeconds() { return maxOutOfOrdernessSeconds; }
    
    public boolean isMetricsEnabled() { return metricsEnabled; }
    public String getMetricsReporterType() { return metricsReporterType; }
    public int getMetricsReportInterval() { return metricsReportInterval; }
    public ThreatAnalysisConfig getThreatAnalysisConfig() { return threatAnalysisConfig; }
    
    /**
     * Get state backend based on configuration
     */
    public StateBackend getStateBackend() {
        switch (stateBackendType.toLowerCase()) {
            case "rocksdb":
                return new EmbeddedRocksDBStateBackend(true);
            case "hashmap":
            default:
                return new HashMapStateBackend();
        }
    }
    
    /**
     * Get restart strategy based on configuration
     */
    public RestartStrategyConfiguration getRestartStrategy() {
        return RestartStrategies.fixedDelayRestart(
            3, // number of restart attempts
            Time.seconds(30) // delay between restarts
        );
    }
    
    @Override
    public String toString() {
        return "StreamProcessorConfig{" +
                "parallelism=" + parallelism +
                ", checkpointInterval=" + checkpointInterval +
                ", kafkaBrokers='" + kafkaBrokers + '\'' +
                ", inputTopic='" + inputTopic + '\'' +
                ", outputTopic='" + outputTopic + '\'' +
                ", windowSizeSeconds=" + windowSizeSeconds +
                ", threatThreshold=" + threatThreshold +
                '}';
    }
    
    /**
     * Builder class for StreamProcessorConfig
     */
    public static class Builder {
        private int parallelism = 4;
        private long checkpointInterval = 60000; // 1 minute
        private long watermarkInterval = 5000; // 5 seconds
        private String stateBackendType = "hashmap";
        private RestartStrategyConfiguration restartStrategy;
        
        private String kafkaBrokers = "localhost:9092";
        private String inputTopic = "traffic-events";
        private String outputTopic = "threat-scores";
        private String consumerGroupId = "stream-processor";
        private Properties kafkaConsumerProperties = new Properties();
        private Properties kafkaProducerProperties = new Properties();
        
        private String jdbcUrl = "jdbc:postgresql://localhost:5432/malicious_traffic";
        private String jdbcUsername = "admin";
        private String jdbcPassword = "password";
        private String jdbcDriverClass = "org.postgresql.Driver";
        
        private int windowSizeSeconds = 300; // 5 minutes
        private int slidingIntervalSeconds = 60; // 1 minute
        private double threatThreshold = 0.5;
        private int maxOutOfOrdernessSeconds = 30;
        
        private boolean metricsEnabled = true;
        private String metricsReporterType = "prometheus";
        private int metricsReportInterval = 30;
        private ThreatAnalysisConfig threatAnalysisConfig;
        
        public Builder parallelism(int parallelism) {
            this.parallelism = parallelism;
            return this;
        }
        
        public Builder checkpointInterval(long checkpointInterval) {
            this.checkpointInterval = checkpointInterval;
            return this;
        }
        
        public Builder watermarkInterval(long watermarkInterval) {
            this.watermarkInterval = watermarkInterval;
            return this;
        }
        
        public Builder stateBackendType(String stateBackendType) {
            this.stateBackendType = stateBackendType;
            return this;
        }
        
        public Builder kafkaBrokers(String kafkaBrokers) {
            this.kafkaBrokers = kafkaBrokers;
            return this;
        }
        
        public Builder inputTopic(String inputTopic) {
            this.inputTopic = inputTopic;
            return this;
        }
        
        public Builder outputTopic(String outputTopic) {
            this.outputTopic = outputTopic;
            return this;
        }
        
        public Builder consumerGroupId(String consumerGroupId) {
            this.consumerGroupId = consumerGroupId;
            return this;
        }
        
        public Builder jdbcUrl(String jdbcUrl) {
            this.jdbcUrl = jdbcUrl;
            return this;
        }
        
        public Builder jdbcUsername(String jdbcUsername) {
            this.jdbcUsername = jdbcUsername;
            return this;
        }
        
        public Builder jdbcPassword(String jdbcPassword) {
            this.jdbcPassword = jdbcPassword;
            return this;
        }
        
        public Builder jdbcDriverClass(String jdbcDriverClass) {
            this.jdbcDriverClass = jdbcDriverClass;
            return this;
        }
        
        public Builder windowSizeSeconds(int windowSizeSeconds) {
            this.windowSizeSeconds = windowSizeSeconds;
            return this;
        }
        
        public Builder slidingIntervalSeconds(int slidingIntervalSeconds) {
            this.slidingIntervalSeconds = slidingIntervalSeconds;
            return this;
        }
        
        public Builder threatThreshold(double threatThreshold) {
            this.threatThreshold = threatThreshold;
            return this;
        }
        
        public Builder maxOutOfOrdernessSeconds(int maxOutOfOrdernessSeconds) {
            this.maxOutOfOrdernessSeconds = maxOutOfOrdernessSeconds;
            return this;
        }
        
        public Builder metricsEnabled(boolean metricsEnabled) {
            this.metricsEnabled = metricsEnabled;
            return this;
        }
        
        public Builder metricsReporterType(String metricsReporterType) {
            this.metricsReporterType = metricsReporterType;
            return this;
        }
        
        public Builder metricsReportInterval(int metricsReportInterval) {
            this.metricsReportInterval = metricsReportInterval;
            return this;
        }

        public Builder threatAnalysisConfig(ThreatAnalysisConfig threatAnalysisConfig) {
            this.threatAnalysisConfig = threatAnalysisConfig;
            return this;
        }
        
        public StreamProcessorConfig build() {
            // Initialize Kafka properties
            initializeKafkaProperties();
            
            // Set restart strategy
            this.restartStrategy = RestartStrategies.fixedDelayRestart(3, Time.seconds(30));
            
            return new StreamProcessorConfig(this);
        }
        
        private void initializeKafkaProperties() {
            // Consumer properties
            kafkaConsumerProperties.setProperty("bootstrap.servers", kafkaBrokers);
            kafkaConsumerProperties.setProperty("group.id", consumerGroupId);
            kafkaConsumerProperties.setProperty("auto.offset.reset", "latest");
            kafkaConsumerProperties.setProperty("enable.auto.commit", "false");
            kafkaConsumerProperties.setProperty("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            kafkaConsumerProperties.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            
            // Producer properties
            kafkaProducerProperties.setProperty("bootstrap.servers", kafkaBrokers);
            kafkaProducerProperties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            kafkaProducerProperties.setProperty("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            kafkaProducerProperties.setProperty("acks", "all");
            kafkaProducerProperties.setProperty("retries", "3");
            kafkaProducerProperties.setProperty("batch.size", "16384");
            kafkaProducerProperties.setProperty("linger.ms", "1");
            kafkaProducerProperties.setProperty("buffer.memory", "33554432");
        }
    }

    /**
     * Configuration for threat analysis logic.
     */
    public static class ThreatAnalysisConfig implements Serializable {
        private static final long serialVersionUID = 1L;

        public final double requestFrequencyWeight;
        public final double pathDiversityWeight;
        public final double timePatternWeight;
        public final double errorRateWeight;
        public final double featureAvgWeight;

        public ThreatAnalysisConfig(Config config) {
            this.requestFrequencyWeight = config.getDouble("weights.request-frequency");
            this.pathDiversityWeight = config.getDouble("weights.path-diversity");
            this.timePatternWeight = config.getDouble("weights.time-pattern");
            this.errorRateWeight = config.getDouble("weights.error-rate");
            this.featureAvgWeight = config.getDouble("weights.feature-avg");
        }
    }
}
package com.malicioustraffic.streamprocessor.config;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.contrib.streaming.state.EmbeddedRocksDBStateBackend;
import org.apache.flink.runtime.state.StateBackend;
import org.apache.flink.runtime.state.hashmap.HashMapStateBackend;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.restartstrategy.RestartStrategies.RestartStrategyConfiguration;
import org.apache.flink.api.common.time.Time;

import java.io.Serializable;
import java.util.Properties;

/**
 * Configuration class for Stream Processor
 */
public class StreamProcessorConfig implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Flink Configuration
    private final int parallelism;
    private final long checkpointInterval;
    private final long watermarkInterval;
    private final String stateBackendType;
    private final RestartStrategyConfiguration restartStrategy;
    
    // Kafka Configuration
    private final String kafkaBrokers;
    private final String inputTopic;
    private final String outputTopic;
    private final String consumerGroupId;
    private final Properties kafkaConsumerProperties;
    private final Properties kafkaProducerProperties;
    
    // Database Configuration
    private final String jdbcUrl;
    private final String jdbcUsername;
    private final String jdbcPassword;
    private final String jdbcDriverClass;
    
    // Processing Configuration
    private final int windowSizeSeconds;
    private final int slidingIntervalSeconds;
    private final double threatThreshold;
    private final int maxOutOfOrdernessSeconds;
    
    // Metrics Configuration
    private final boolean metricsEnabled;
    private final String metricsReporterType;
    private final int metricsReportInterval;
    
    private StreamProcessorConfig(Builder builder) {
        this.parallelism = builder.parallelism;
        this.checkpointInterval = builder.checkpointInterval;
        this.watermarkInterval = builder.watermarkInterval;
        this.stateBackendType = builder.stateBackendType;
        this.restartStrategy = builder.restartStrategy;
        
        this.kafkaBrokers = builder.kafkaBrokers;
        this.inputTopic = builder.inputTopic;
        this.outputTopic = builder.outputTopic;
        this.consumerGroupId = builder.consumerGroupId;
        this.kafkaConsumerProperties = builder.kafkaConsumerProperties;
        this.kafkaProducerProperties = builder.kafkaProducerProperties;
        
        this.jdbcUrl = builder.jdbcUrl;
        this.jdbcUsername = builder.jdbcUsername;
        this.jdbcPassword = builder.jdbcPassword;
        this.jdbcDriverClass = builder.jdbcDriverClass;
        
        this.windowSizeSeconds = builder.windowSizeSeconds;
        this.slidingIntervalSeconds = builder.slidingIntervalSeconds;
        this.threatThreshold = builder.threatThreshold;
        this.maxOutOfOrdernessSeconds = builder.maxOutOfOrdernessSeconds;
        
        this.metricsEnabled = builder.metricsEnabled;
        this.metricsReporterType = builder.metricsReporterType;
        this.metricsReportInterval = builder.metricsReportInterval;
    }
    
    /**
     * Load configuration from environment-specific files, with fallbacks and environment variable overrides.
     */
    public static StreamProcessorConfig load(ParameterTool params) {
        String env = System.getenv().getOrDefault("APP_ENV", "dev");
        
        // 1. Load environment-specific config (e.g., application.prod.conf)
        // 2. Fallback to base application.conf
        // 3. Allow environment variables to override all
        Config config = ConfigFactory.parseResources("application." + env + ".conf")
                .withFallback(ConfigFactory.load("application.conf"))
                .withFallback(ConfigFactory.systemEnvironment());

        return new Builder()
            // Flink Configuration
            .parallelism(config.getInt("flink.parallelism"))
            .checkpointInterval(config.getLong("flink.checkpoint.interval"))
            .watermarkInterval(config.getLong("flink.watermark.interval"))
            .stateBackendType(config.getString("flink.state.backend"))
            
            // Kafka Configuration
            .kafkaBrokers(config.getString("kafka.brokers"))
            .inputTopic(config.getString("kafka.input.topic"))
            .outputTopic(config.getString("kafka.output.topic"))
            .consumerGroupId(config.getString("kafka.consumer.group.id"))
            
            // Database Configuration
            .jdbcUrl(config.getString("database.url"))
            .jdbcUsername(config.getString("database.username"))
            .jdbcPassword(config.getString("database.password"))
            .jdbcDriverClass(config.getString("database.driver"))
            
            // Processing Configuration
            .windowSizeSeconds(config.getInt("processing.window.size"))
            .slidingIntervalSeconds(config.getInt("processing.sliding.interval"))
            .threatThreshold(config.getDouble("processing.threat.threshold"))
            .maxOutOfOrdernessSeconds(config.getInt("processing.max.out.of.orderness"))
            
            // Metrics Configuration
            .metricsEnabled(config.getBoolean("metrics.enabled"))
            .metricsReporterType(config.getString("metrics.reporter"))
            .metricsReportInterval(config.getInt("metrics.report.interval"))
            
            .build();
    }
    
    // Getters
    public int getParallelism() { return parallelism; }
    public long getCheckpointInterval() { return checkpointInterval; }
    public long getWatermarkInterval() { return watermarkInterval; }
    public String getStateBackendType() { return stateBackendType; }
    public RestartStrategyConfiguration getRestartStrategy() { return restartStrategy; }
    
    public String getKafkaBrokers() { return kafkaBrokers; }
    public String getInputTopic() { return inputTopic; }
    public String getOutputTopic() { return outputTopic; }
    public String getConsumerGroupId() { return consumerGroupId; }
    public Properties getKafkaConsumerProperties() { return kafkaConsumerProperties; }
    public Properties getKafkaProducerProperties() { return kafkaProducerProperties; }
    
    public String getJdbcUrl() { return jdbcUrl; }
    public String getJdbcUsername() { return jdbcUsername; }
    public String getJdbcPassword() { return jdbcPassword; }
    public String getJdbcDriverClass() { return jdbcDriverClass; }
    
    public int getWindowSizeSeconds() { return windowSizeSeconds; }
    public int getSlidingIntervalSeconds() { return slidingIntervalSeconds; }
    public double getThreatThreshold() { return threatThreshold; }
    public int getMaxOutOfOrdernessSeconds() { return maxOutOfOrdernessSeconds; }
    
    public boolean isMetricsEnabled() { return metricsEnabled; }
    public String getMetricsReporterType() { return metricsReporterType; }
    public int getMetricsReportInterval() { return metricsReportInterval; }
    
    /**
     * Get state backend based on configuration
     */
    public StateBackend getStateBackend() {
        switch (stateBackendType.toLowerCase()) {
            case "rocksdb":
                return new EmbeddedRocksDBStateBackend(true);
            case "hashmap":
            default:
                return new HashMapStateBackend();
        }
    }
    
    /**
     * Get restart strategy based on configuration
     */
    public RestartStrategyConfiguration getRestartStrategy() {
        return RestartStrategies.fixedDelayRestart(
            3, // number of restart attempts
            Time.seconds(30) // delay between restarts
        );
    }
    
    @Override
    public String toString() {
        return "StreamProcessorConfig{" +
                "parallelism=" + parallelism +
                ", checkpointInterval=" + checkpointInterval +
                ", kafkaBrokers='" + kafkaBrokers + '\'' +
                ", inputTopic='" + inputTopic + '\'' +
                ", outputTopic='" + outputTopic + '\'' +
                ", windowSizeSeconds=" + windowSizeSeconds +
                ", threatThreshold=" + threatThreshold +
                '}';
    }
    
    /**
     * Builder class for StreamProcessorConfig
     */
    public static class Builder {
        private int parallelism = 4;
        private long checkpointInterval = 60000; // 1 minute
        private long watermarkInterval = 5000; // 5 seconds
        private String stateBackendType = "hashmap";
        private RestartStrategyConfiguration restartStrategy;
        
        private String kafkaBrokers = "localhost:9092";
        private String inputTopic = "traffic-events";
        private String outputTopic = "threat-scores";
        private String consumerGroupId = "stream-processor";
        private Properties kafkaConsumerProperties = new Properties();
        private Properties kafkaProducerProperties = new Properties();
        
        private String jdbcUrl = "jdbc:postgresql://localhost:5432/malicious_traffic";
        private String jdbcUsername = "admin";
        private String jdbcPassword = "password";
        private String jdbcDriverClass = "org.postgresql.Driver";
        
        private int windowSizeSeconds = 300; // 5 minutes
        private int slidingIntervalSeconds = 60; // 1 minute
        private double threatThreshold = 0.5;
        private int maxOutOfOrdernessSeconds = 30;
        
        private boolean metricsEnabled = true;
        private String metricsReporterType = "prometheus";
        private int metricsReportInterval = 30;
        
        public Builder parallelism(int parallelism) {
            this.parallelism = parallelism;
            return this;
        }
        
        public Builder checkpointInterval(long checkpointInterval) {
            this.checkpointInterval = checkpointInterval;
            return this;
        }
        
        public Builder watermarkInterval(long watermarkInterval) {
            this.watermarkInterval = watermarkInterval;
            return this;
        }
        
        public Builder stateBackendType(String stateBackendType) {
            this.stateBackendType = stateBackendType;
            return this;
        }
        
        public Builder kafkaBrokers(String kafkaBrokers) {
            this.kafkaBrokers = kafkaBrokers;
            return this;
        }
        
        public Builder inputTopic(String inputTopic) {
            this.inputTopic = inputTopic;
            return this;
        }
        
        public Builder outputTopic(String outputTopic) {
            this.outputTopic = outputTopic;
            return this;
        }
        
        public Builder consumerGroupId(String consumerGroupId) {
            this.consumerGroupId = consumerGroupId;
            return this;
        }
        
        public Builder jdbcUrl(String jdbcUrl) {
            this.jdbcUrl = jdbcUrl;
            return this;
        }
        
        public Builder jdbcUsername(String jdbcUsername) {
            this.jdbcUsername = jdbcUsername;
            return this;
        }
        
        public Builder jdbcPassword(String jdbcPassword) {
            this.jdbcPassword = jdbcPassword;
            return this;
        }
        
        public Builder jdbcDriverClass(String jdbcDriverClass) {
            this.jdbcDriverClass = jdbcDriverClass;
            return this;
        }
        
        public Builder windowSizeSeconds(int windowSizeSeconds) {
            this.windowSizeSeconds = windowSizeSeconds;
            return this;
        }
        
        public Builder slidingIntervalSeconds(int slidingIntervalSeconds) {
            this.slidingIntervalSeconds = slidingIntervalSeconds;
            return this;
        }
        
        public Builder threatThreshold(double threatThreshold) {
            this.threatThreshold = threatThreshold;
            return this;
        }
        
        public Builder maxOutOfOrdernessSeconds(int maxOutOfOrdernessSeconds) {
            this.maxOutOfOrdernessSeconds = maxOutOfOrdernessSeconds;
            return this;
        }
        
        public Builder metricsEnabled(boolean metricsEnabled) {
            this.metricsEnabled = metricsEnabled;
            return this;
        }
        
        public Builder metricsReporterType(String metricsReporterType) {
            this.metricsReporterType = metricsReporterType;
            return this;
        }
        
        public Builder metricsReportInterval(int metricsReportInterval) {
            this.metricsReportInterval = metricsReportInterval;
            return this;
        }
        
        public StreamProcessorConfig build() {
            // Initialize Kafka properties
            initializeKafkaProperties();
            
            // Set restart strategy
            this.restartStrategy = RestartStrategies.fixedDelayRestart(3, Time.seconds(30));
            
            return new StreamProcessorConfig(this);
        }
        
        private void initializeKafkaProperties() {
            // Consumer properties
            kafkaConsumerProperties.setProperty("bootstrap.servers", kafkaBrokers);
            kafkaConsumerProperties.setProperty("group.id", consumerGroupId);
            kafkaConsumerProperties.setProperty("auto.offset.reset", "latest");
            kafkaConsumerProperties.setProperty("enable.auto.commit", "false");
            kafkaConsumerProperties.setProperty("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            kafkaConsumerProperties.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            
            // Producer properties
            kafkaProducerProperties.setProperty("bootstrap.servers", kafkaBrokers);
            kafkaProducerProperties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            kafkaProducerProperties.setProperty("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            kafkaProducerProperties.setProperty("acks", "all");
            kafkaProducerProperties.setProperty("retries", "3");
            kafkaProducerProperties.setProperty("batch.size", "16384");
            kafkaProducerProperties.setProperty("linger.ms", "1");
            kafkaProducerProperties.setProperty("buffer.memory", "33554432");
        }
    }
}