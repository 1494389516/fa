package com.malicioustraffic.streamprocessor.function;

import com.malicioustraffic.streamprocessor.model.TrafficEvent;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.time.Instant;
import java.util.*;

/**
 * Traffic Aggregation Function
 * Aggregates traffic events within time windows for statistical analysis
 */
public class TrafficAggregationFunction implements AggregateFunction<TrafficEvent, TrafficAggregationFunction.TrafficAccumulator, TrafficAggregationFunction.TrafficAggregate> {
    
    private static final Logger logger = LoggerFactory.getLogger(TrafficAggregationFunction.class);
    private static final long serialVersionUID = 1L;
    
    @Override
    public TrafficAccumulator createAccumulator() {
        return new TrafficAccumulator();
    }
    
    @Override
    public TrafficAccumulator add(TrafficEvent event, TrafficAccumulator accumulator) {
        accumulator.addEvent(event);
        return accumulator;
    }
    
    @Override
    public TrafficAggregate getResult(TrafficAccumulator accumulator) {
        return accumulator.getAggregate();
    }
    
    @Override
    public TrafficAccumulator merge(TrafficAccumulator acc1, TrafficAccumulator acc2) {
        acc1.merge(acc2);
        return acc1;
    }
    
    /**
     * Accumulator for traffic events
     */
    public static class TrafficAccumulator implements Serializable {
        
        private static final long serialVersionUID = 1L;
        
        private int eventCount;
        private String clientKey;
        private String clientIp;
        private Set<String> uniquePaths;
        private Set<String> uniqueUserAgents;
        private Set<String> uniqueJA3;
        private Set<String> uniqueASNs;
        private Map<String, Integer> methodCounts;
        private Map<Integer, Integer> responseCodeCounts;
        private Map<String, Integer> pathCounts;
        private List<Long> requestTimestamps;
        private List<Double> threatScores;
        private List<List<Double>> allFeatures;
        
        // Statistical measures
        private long totalResponseSize;
        private long totalProcessingTime;
        private long minTimestamp;
        private long maxTimestamp;
        
        public TrafficAccumulator() {
            this.eventCount = 0;
            this.uniquePaths = new HashSet<>();
            this.uniqueUserAgents = new HashSet<>();
            this.uniqueJA3 = new HashSet<>();
            this.uniqueASNs = new HashSet<>();
            this.methodCounts = new HashMap<>();
            this.responseCodeCounts = new HashMap<>();
            this.pathCounts = new HashMap<>();
            this.requestTimestamps = new ArrayList<>();
            this.threatScores = new ArrayList<>();
            this.allFeatures = new ArrayList<>();
            this.totalResponseSize = 0;
            this.totalProcessingTime = 0;
            this.minTimestamp = Long.MAX_VALUE;
            this.maxTimestamp = Long.MIN_VALUE;
        }
        
        public void addEvent(TrafficEvent event) {
            eventCount++;
            
            // Set client information from first event
            if (clientKey == null) {
                clientKey = event.getClientKey();
                clientIp = event.getClientIp();
            }
            
            // Collect unique values
            if (event.getRequestPath() != null) {
                uniquePaths.add(event.getRequestPath());
                pathCounts.merge(event.getRequestPath(), 1, Integer::sum);
            }
            
            if (event.getUserAgent() != null) {
                uniqueUserAgents.add(event.getUserAgent());
            }
            
            if (event.getJa3Fingerprint() != null) {
                uniqueJA3.add(event.getJa3Fingerprint());
            }
            
            if (event.getAsn() != null) {
                uniqueASNs.add(event.getAsn());
            }
            
            // Count methods and response codes
            if (event.getRequestMethod() != null) {
                methodCounts.merge(event.getRequestMethod(), 1, Integer::sum);
            }
            
            if (event.getResponseCode() != null) {
                responseCodeCounts.merge(event.getResponseCode(), 1, Integer::sum);
            }
            
            // Collect timestamps
            if (event.getTimestamp() != null) {
                long timestamp = event.getTimestamp().toEpochMilli();
                requestTimestamps.add(timestamp);
                minTimestamp = Math.min(minTimestamp, timestamp);
                maxTimestamp = Math.max(maxTimestamp, timestamp);
            }
            
            // Collect threat scores
            if (event.getThreatScore() != null) {
                threatScores.add(event.getThreatScore());
            }
            
            // Collect features
            if (event.hasFeatures()) {
                allFeatures.add(new ArrayList<>(event.getFeatures()));
            }
            
            // Accumulate response metrics
            if (event.getResponseSize() != null) {
                totalResponseSize += event.getResponseSize();
            }
            
            if (event.getProcessingTime() != null) {
                totalProcessingTime += event.getProcessingTime();
            }
        }
        
        public void merge(TrafficAccumulator other) {
            this.eventCount += other.eventCount;
            this.uniquePaths.addAll(other.uniquePaths);
            this.uniqueUserAgents.addAll(other.uniqueUserAgents);
            this.uniqueJA3.addAll(other.uniqueJA3);
            this.uniqueASNs.addAll(other.uniqueASNs);
            
            // Merge counts
            other.methodCounts.forEach((method, count) -> 
                this.methodCounts.merge(method, count, Integer::sum));
            other.responseCodeCounts.forEach((code, count) -> 
                this.responseCodeCounts.merge(code, count, Integer::sum));
            other.pathCounts.forEach((path, count) -> 
                this.pathCounts.merge(path, count, Integer::sum));
            
            this.requestTimestamps.addAll(other.requestTimestamps);
            this.threatScores.addAll(other.threatScores);
            this.allFeatures.addAll(other.allFeatures);
            
            this.totalResponseSize += other.totalResponseSize;
            this.totalProcessingTime += other.totalProcessingTime;
            this.minTimestamp = Math.min(this.minTimestamp, other.minTimestamp);
            this.maxTimestamp = Math.max(this.maxTimestamp, other.maxTimestamp);
        }
        
        public TrafficAggregate getAggregate() {
            TrafficAggregate aggregate = new TrafficAggregate();
            
            // Basic counts
            aggregate.eventCount = this.eventCount;
            aggregate.clientKey = this.clientKey;
            aggregate.clientIp = this.clientIp;
            aggregate.uniquePathCount = this.uniquePaths.size();
            aggregate.uniqueUserAgentCount = this.uniqueUserAgents.size();
            aggregate.uniqueJA3Count = this.uniqueJA3.size();
            aggregate.uniqueASNCount = this.uniqueASNs.size();
            
            // Time window information
            if (minTimestamp != Long.MAX_VALUE && maxTimestamp != Long.MIN_VALUE) {
                aggregate.windowStartTime = Instant.ofEpochMilli(minTimestamp);
                aggregate.windowEndTime = Instant.ofEpochMilli(maxTimestamp);
                aggregate.windowDurationMs = maxTimestamp - minTimestamp;
            }
            
            // Request frequency
            if (aggregate.windowDurationMs > 0) {
                aggregate.requestsPerSecond = (double) eventCount / (aggregate.windowDurationMs / 1000.0);
                aggregate.requestsPerMinute = (double) eventCount / (aggregate.windowDurationMs / 60000.0);
            }
            
            // Path diversity metrics
            aggregate.pathDiversity = eventCount > 0 ? (double) uniquePaths.size() / eventCount : 0.0;
            aggregate.mostFrequentPath = getMostFrequentPath();
            aggregate.pathConcentration = calculatePathConcentration();
            
            // Method distribution
            aggregate.methodDistribution = new HashMap<>(methodCounts);
            aggregate.dominantMethod = getDominantMethod();
            
            // Response code distribution
            aggregate.responseCodeDistribution = new HashMap<>(responseCodeCounts);
            aggregate.errorRate = calculateErrorRate();
            aggregate.successRate = calculateSuccessRate();
            
            // Threat analysis
            if (!threatScores.isEmpty()) {
                aggregate.avgThreatScore = threatScores.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
                aggregate.maxThreatScore = threatScores.stream().mapToDouble(Double::doubleValue).max().orElse(0.0);
                aggregate.minThreatScore = threatScores.stream().mapToDouble(Double::doubleValue).min().orElse(0.0);
            }
            
            // Feature aggregation
            if (!allFeatures.isEmpty()) {
                aggregate.avgFeatures = calculateAverageFeatures();
                aggregate.featureVariance = calculateFeatureVariance(aggregate.avgFeatures);
            }
            
            // Timing analysis
            aggregate.requestIntervals = calculateRequestIntervals();
            aggregate.avgRequestInterval = aggregate.requestIntervals.stream()
                .mapToLong(Long::longValue).average().orElse(0.0);
            aggregate.requestIntervalVariance = calculateIntervalVariance(aggregate.avgRequestInterval);
            
            // Response metrics
            aggregate.avgResponseSize = eventCount > 0 ? (double) totalResponseSize / eventCount : 0.0;
            aggregate.avgProcessingTime = eventCount > 0 ? (double) totalProcessingTime / eventCount : 0.0;
            
            // Behavioral patterns
            aggregate.burstiness = calculateBurstiness();
            aggregate.regularity = calculateRegularity();
            
            return aggregate;
        }
        
        private Tuple2<String, Integer> getMostFrequentPath() {
            return pathCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(entry -> Tuple2.of(entry.getKey(), entry.getValue()))
                .orElse(Tuple2.of("", 0));
        }
        
        private double calculatePathConcentration() {
            if (pathCounts.isEmpty()) return 0.0;
            
            int maxCount = pathCounts.values().stream().mapToInt(Integer::intValue).max().orElse(0);
            return eventCount > 0 ? (double) maxCount / eventCount : 0.0;
        }
        
        private String getDominantMethod() {
            return methodCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("");
        }
        
        private double calculateErrorRate() {
            int errorCount = responseCodeCounts.entrySet().stream()
                .filter(entry -> entry.getKey() >= 400)
                .mapToInt(Map.Entry::getValue)
                .sum();
            return eventCount > 0 ? (double) errorCount / eventCount : 0.0;
        }
        
        private double calculateSuccessRate() {
            int successCount = responseCodeCounts.entrySet().stream()
                .filter(entry -> entry.getKey() >= 200 && entry.getKey() < 300)
                .mapToInt(Map.Entry::getValue)
                .sum();
            return eventCount > 0 ? (double) successCount / eventCount : 0.0;
        }
        
        private List<Double> calculateAverageFeatures() {
            if (allFeatures.isEmpty()) return new ArrayList<>();
            
            int featureCount = allFeatures.get(0).size();
            List<Double> avgFeatures = new ArrayList<>(featureCount);
            
            for (int i = 0; i < featureCount; i++) {
                final int index = i;
                double avg = allFeatures.stream()
                    .filter(features -> features.size() > index)
                    .mapToDouble(features -> features.get(index))
                    .average()
                    .orElse(0.0);
                avgFeatures.add(avg);
            }
            
            return avgFeatures;
        }
        
        private List<Double> calculateFeatureVariance(List<Double> avgFeatures) {
            if (allFeatures.isEmpty() || avgFeatures.isEmpty()) return new ArrayList<>();
            
            List<Double> variances = new ArrayList<>();
            
            for (int i = 0; i < avgFeatures.size(); i++) {
                final int index = i;
                final double avg = avgFeatures.get(i);
                
                double variance = allFeatures.stream()
                    .filter(features -> features.size() > index)
                    .mapToDouble(features -> Math.pow(features.get(index) - avg, 2))
                    .average()
                    .orElse(0.0);
                
                variances.add(variance);
            }
            
            return variances;
        }
        
        private List<Long> calculateRequestIntervals() {
            if (requestTimestamps.size() < 2) return new ArrayList<>();
            
            List<Long> sortedTimestamps = new ArrayList<>(requestTimestamps);
            sortedTimestamps.sort(Long::compareTo);
            
            List<Long> intervals = new ArrayList<>();
            for (int i = 1; i < sortedTimestamps.size(); i++) {
                intervals.add(sortedTimestamps.get(i) - sortedTimestamps.get(i - 1));
            }
            
            return intervals;
        }
        
        private double calculateIntervalVariance(double avgInterval) {
            List<Long> intervals = calculateRequestIntervals();
            if (intervals.isEmpty()) return 0.0;
            
            return intervals.stream()
                .mapToDouble(interval -> Math.pow(interval - avgInterval, 2))
                .average()
                .orElse(0.0);
        }
        
        private double calculateBurstiness() {
            List<Long> intervals = calculateRequestIntervals();
            if (intervals.size() < 3) return 0.0;
            
            // Calculate burstiness using coefficient of variation
            double mean = intervals.stream().mapToLong(Long::longValue).average().orElse(0.0);
            double variance = intervals.stream()
                .mapToDouble(interval -> Math.pow(interval - mean, 2))
                .average()
                .orElse(0.0);
            
            double stdDev = Math.sqrt(variance);
            return mean > 0 ? stdDev / mean : 0.0;
        }
        
        private double calculateRegularity() {
            // Regularity is inverse of burstiness
            double burstiness = calculateBurstiness();
            return burstiness > 0 ? 1.0 / (1.0 + burstiness) : 1.0;
        }
    }
    
    /**
     * Traffic Aggregate result
     */
    public static class TrafficAggregate implements Serializable {
        
        private static final long serialVersionUID = 1L;
        
        // Basic information
        public int eventCount;
        public String clientKey;
        public String clientIp;
        public Instant windowStartTime;
        public Instant windowEndTime;
        public long windowDurationMs;
        
        // Frequency metrics
        public double requestsPerSecond;
        public double requestsPerMinute;
        
        // Diversity metrics
        public int uniquePathCount;
        public int uniqueUserAgentCount;
        public int uniqueJA3Count;
        public int uniqueASNCount;
        public double pathDiversity;
        public Tuple2<String, Integer> mostFrequentPath;
        public double pathConcentration;
        
        // Method and response metrics
        public Map<String, Integer> methodDistribution;
        public String dominantMethod;
        public Map<Integer, Integer> responseCodeDistribution;
        public double errorRate;
        public double successRate;
        
        // Threat metrics
        public double avgThreatScore;
        public double maxThreatScore;
        public double minThreatScore;
        
        // Feature metrics
        public List<Double> avgFeatures;
        public List<Double> featureVariance;
        
        // Timing metrics
        public List<Long> requestIntervals;
        public double avgRequestInterval;
        public double requestIntervalVariance;
        
        // Response metrics
        public double avgResponseSize;
        public double avgProcessingTime;
        
        // Behavioral metrics
        public double burstiness;
        public double regularity;
        
        @Override
        public String toString() {
            return "TrafficAggregate{" +
                    "eventCount=" + eventCount +
                    ", clientKey='" + clientKey + '\'' +
                    ", requestsPerMinute=" + requestsPerMinute +
                    ", pathDiversity=" + pathDiversity +
                    ", errorRate=" + errorRate +
                    ", avgThreatScore=" + avgThreatScore +
                    '}';
        }
    }
}